<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OurOfferings extends Model
{
    
	protected $table = 'OurOfferings';
     protected $fillable = ['titles', 'image'];
     //hii//
}
