<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Color extends Model
{
    protected $table = "lens_color";
    
    public $timestamps = false;
}
