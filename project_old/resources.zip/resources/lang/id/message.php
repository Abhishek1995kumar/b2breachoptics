<?php
return [
 
 'greeting' => 'Hello world. Ini menggunakan Bahasa Indonesia.',
];