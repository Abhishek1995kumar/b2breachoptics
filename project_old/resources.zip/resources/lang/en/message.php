


<?php
return [
 
 'greeting' => 'Hello world. This is using english.',
];