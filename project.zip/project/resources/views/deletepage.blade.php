@extends('includes.newmaster')
@section('content')


@stop

@section('footer')
@stop