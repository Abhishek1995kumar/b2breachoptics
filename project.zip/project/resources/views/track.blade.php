@extends('includes.newmaster')

@section('content')

<h1>track page here</h1>





@stop

@section('footer')
<script>

</script>
@stop