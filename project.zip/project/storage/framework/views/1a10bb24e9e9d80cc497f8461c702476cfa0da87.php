<?php $__env->startSection('content'); ?>


    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="container" style="background-color:#02D0B7;background-image: linear-gradient(to right, #5FE2E5 , #5EEEAF);">

            <div style="margin: 0% 0px 0% 0px;">
                <div class="text-left" style="color:white ;padding: 25px;">
                    <h1><?php echo e($language->search_result); ?>: <?php echo e($search); ?></h1>
                </div>
            </div>

        </div>
    </section>
    <div class="section-padding product-filter-wrapper wow fadeInUp">
            <div class="container">
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                            <div class="single-product-carousel-item text-center">
                                <div class="image_latest_product_shubh">
                                    <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace('/','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" alt="Product Image" /> </a>
                                </div>
                                <div class="product-carousel-text">
                                    <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace('/','-',strtolower($product->title))); ?>">
                                        <h4 class="product-title"><?php echo e($product->title); ?></h4>
                                    </a>
                                    <!--<div class="product-review">-->
                                    <!--    <i class="fa fa-star"></i>-->
                                    <!--</div>-->
                                    <div class="product-price">
                                        <span style="font-size: 25px; font-weight : bold"><del class="offer-pricenewone" ><i  title ="Add to My site"class=" fa fa-share-alt" style="font-size:15px"></i></del></span>
                                        <?php if($product->previous_price != ""): ?>
                                            <!--<span class="original-price">₹<?php echo e(\App\Product::Cost($product->id)); ?></span>-->
                                            <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->previous_price); ?></span>
                                        <?php endif; ?>
                                        <!--<del class="offer-price">₹<?php echo e($product->previous_price); ?></del>-->
                                        
                                        <?php if(Auth::guard('profile')->check()): ?>
                                            <?php if(Auth::guard('profile')->user()->costpriceshow == 'Yes'): ?>
                                                <del class="offer-pricenew" data="<?php echo e($product->id); ?>"><a data-toggle="modal" data-target="#view_<?php echo e($product->id); ?>" > <i class="fa fa-eye" aria-hidden="true"></i> </a></del>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <!--<?php if($product->previous_price != ""): ?>-->
                                        <!--    <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Product::Cost($product->id)); ?></span>-->
                                        <!--<?php else: ?>-->
                                        <!--<?php endif; ?>-->
                                        <!--<del class="offer-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->previous_price); ?></del>-->
                                    </div>
                                        
                                    <div class="product-meta-area">
                                        <form class="addtocart-form">
                                            <?php echo e(csrf_field()); ?>

                                            <?php if(Session::has('uniqueid')): ?>
                                                <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                            <?php else: ?>
                                                <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                            <?php endif; ?>
                                                          
                                            <input type="hidden" id="price" name="price" value="<?php echo e(\App\Product::Cost($product->id)); ?>">
                                                            
                                            <input type="hidden" id="main_price" name="main_price" value="<?php echo e($product->costprice); ?>">
            
                                            <input type="hidden" id="rangenameone" name="rangenameone" value="<?php echo e($product->ranegnameone); ?>">
                                            <input type="hidden" id="rangenametwo" name="rangenametwo" value="<?php echo e($product->rangenametwo); ?>">
                                            <input type="hidden" id="rangenamethree" name="rangenamethree" value="<?php echo e($product->rangenamethree); ?>">
            
                                            <input type="hidden" id="discount_one" name="discount_one" value="<?php echo e($product->discount_one); ?>">
            
                                            <input type="hidden" id="discount_two" name="discount_two" value="<?php echo e($product->discount_two); ?>">
            
                                            <input type="hidden" id="discount_three" name="discount_three" value="<?php echo e($product->discount_three); ?>">
            
                                            <input type="hidden" name="category" value="<?php echo e($product->category[0]); ?>">
                                            <input type="hidden" name="title" value="<?php echo e($product->title); ?>">
                                            <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                            <input type="hidden" value="<?php echo e($product->feature_image); ?>" name="productImage" id="productImage">
                                            
                                            <?php if($product->category != ''): ?>
                                                <?php if($product->category != 72): ?>
                                                    <?php if($product->category == 53 || $product->category == 63 || $product->category == 82): ?>
                                                        <input type="hidden" id="colormain" name="maincolor" value="<?php echo e($product->framecolor); ?>">
                                                        <input type="hidden" id="attrColorData" name="cartcolor" value="<?php echo e($product->framecolor); ?>">
                                                    <?php else: ?>
                                                        <input type="hidden" id="colormain" name="maincolor" value="<?php echo e($product->color); ?>">
                                                        <input type="hidden" id="attrColorData" name="cartcolor" value="<?php echo e($product->color); ?>">
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($product->category == 82): ?>
                                                    <input type="hidden" name="precat" value="<?php echo e($product->premiumtype); ?>">
                                                <?php endif; ?>
                                            <?php endif; ?>
            
                                            <input type="hidden" id="cost" name="cost" value="<?php echo e($product->costprice); ?>">
                                            <input type="hidden" id="productstock" name="productstock" value="<?php echo e($product->stock); ?>">
                                            <input type="hidden" id="quantity" name="quantity" value="1">
                                            <input type="hidden" id="size" name="size" value="<?php echo e($product->productdimension); ?>">
                                            <input type="hidden" id="productAttrId" name="productAttrId" value="">
            
            
                                            <!--<?php if($product->category == 72): ?>-->
                                            <!--    <?php if($product->stock != 0 || $product->stock === null ): ?>-->
                                            <!--        <div class="cartButton">-->
                                            <!--            <button type="button" class="btn btn-primary" style="border:none; cursor:pointer;"><a href="<?php echo e(url('/productshoww')); ?>/<?php echo e($product->id); ?>/<?php echo e($product->lenscolor); ?>" id="presButton" style="text-decoration:none; color:#fff;"><i class="fa fa-cart-plus "></i>Add Prescription</a></button>-->
                                            <!--        </div>-->
                                            <!--    <?php else: ?>-->
                                            <!--        <div class="cartButton">-->
                                            <!--            <button style="margin-left: 0px;" type="button" class="btn btn-primary" disabled><i class="fa fa-cart-plus "></i>Add Prescription</button>-->
                                            <!--        </div>-->
                                            <!--    <?php endif; ?>-->
                                            <!--<?php else: ?>-->
                                            <!--    <div class="col-sm-12">-->
                                            <!--        <?php if($product->stock != 0 || $product->stock === null ): ?>-->
                                            <!--            <div class="cartButton">-->
                                            <!--                <button style="margin-left: 0px;" type="button"  onclick="addCartProduct()" class="addTo-cart to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>-->
                                            <!--            </div>-->
                                            <!--        <?php else: ?>-->
                                            <!--            <div class="cartButton">-->
                                            <!--                <button style="margin-left: 0px;" type="button" class="addTo-cart to-cart" disabled><i class="fa fa-cart-plus "></i><?php echo e($language->out_of_stock); ?></button>-->
                                            <!--            </div>-->
                                            <!--        <?php endif; ?>-->
                                            <!--    </div>-->
                                            <!--<?php endif; ?>-->
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="view_<?php echo e($product->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                              <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLongTitle">Product Cost Price</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                    <?php if($product->costprice == ''): ?>
                                      <h5>Product Cost Price:- 0</h5>
                                    <?php else: ?>
                                    <h5>Product Cost Price:- <?php echo e($product->costprice); ?></h5>
                                    <?php endif; ?>
                                  </div>
                                  <div class="modal-footer text-center">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                  </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h3><?php echo e($language->no_result); ?></h3>
                    <?php endif; ?>
                </div>
            </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.newmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>