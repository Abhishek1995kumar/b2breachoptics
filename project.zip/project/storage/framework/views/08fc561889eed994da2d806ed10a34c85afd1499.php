<!DOCTYPE html>
<html>
<head>
	<title>PickUp Slip</title>
</head>
<body>

<h1><?php echo e($order->orderid); ?></h1>
</body>
</html>