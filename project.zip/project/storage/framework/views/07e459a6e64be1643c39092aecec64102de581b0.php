
<style>
    .go-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    #color_name {
        width: 21.8rem;
        border-radius: 0.2rem;
    }
    .input-group {
        width: 100%;
        position: relative;
        display: table;
        border-collapse: separate;
    }
</style>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row" id="main">
            <!-- Page Heading -->
            <div class="go-title">
                <h3>Edit Shape</h3>
                <div class="backbtn">
                    <a href="<?php echo e(url('admin/productsetting')); ?>" class="btn btn-success text-center" value="Back">Back</a>
                </div>
            </div>
            <div class="go-line"></div>
            <!-- Page Content -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <div id="response"></div>
                    <form method="POST" action="" id="shape_edit" class="form-horizontal form-label-left">
                        <?php echo e(csrf_field()); ?>

                        <div class="item form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="shape-input">Shape Name<span class="required">*</span></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="input-group">
                                    <input type="text" id="shape-input" name="name" placeholder="Shape Name" class="form-control" required value="<?php echo e($shape->name); ?>"/>
                                </div>
                            </div>
                        </div>
                        <div class="ln_solid"></div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-3">
                                <button type="submit" class="btn btn-success btn-block">Edit Shape</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php $__env->startSection('footer'); ?>
<script>
    $("#shape_edit").on("submit", function(e) {
        e.preventDefault();
        let url = "<?php echo e(route('admin.shape.edit', $shape->id)); ?>"; // Update with the correct route
        // console.log(url);
        let formData = new FormData(this);
        $.ajax({
            method: 'POST', // Use PUT method for update
            url: url,
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            async: false,
            dataType: 'JSON',
            success: function(resp) {
                if (resp.status == 'success') {
                    Swal.fire({
                        icon: 'success',
                        text: resp.msg,
                        imageAlt: 'Custom image',
                    }).then((result) => {
                        window.location = "<?php echo e(url('admin/productsetting')); ?>"; // Redirect to the product setting page
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        text: resp.msg,
                        imageAlt: 'Custom image',
                    });
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.includes.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>