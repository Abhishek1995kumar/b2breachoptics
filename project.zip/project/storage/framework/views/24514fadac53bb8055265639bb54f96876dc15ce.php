<?php $__env->startSection('content'); ?>
<style type="text/css">
    /*body {
    overflow-x: hidden; 
    }*/
  /*  .container1{
        height: 100%;
        width: 100%;
        padding-left: 20px;
        padding-right: 20px;
    }*/



.flex-container {
  display: flex;
  flex-wrap: nowrap;
  height: 50%;padding-top: 17px;
 
}

/*.flex-container > div {
  background-color: #f1f1f1;
  width: 24%;
  height:80%;
  margin: 10px;
  padding: 5px;
  text-align: center;
  line-height: 75px;
  font-size: 30px;
  border-radius: 30px;
}*/

.flex-container > div {
  background-color: #f1f1f1;
  width: 24%;
  height:80%;
  margin: 8px;
  margin-right: 16px;
  padding: 18px;
  text-align: justify;
  line-height: 75px;
  font-size: 30px;
  border-radius: -7px;
  padding-left: 25px;
  padding-top: 31px;
}


    .responsive {
        width: 249%;
        height: 40%;
    }

    .test{
        position: absolute; top: 40%; width: 100%; user-select: none; -ms-user-select: none; -moz-user-select: none;
    }

    @media  screen and (min-width:480px) and (max-width:600px ){
        .demo{
           height: 100%;
           width: 100%;
        }

        .responsive{
            height: 50%;
            width: 60%;
        }

        .test{
            position: absolute;
            top:30%;
            width: 100%;
            height: 270px;
            user-select: none; -ms-user-select: none; -moz-user-select: none;
        }
        .test h4{
            font-size: 8px;
        }

        .test img{
            border-radius: 30px;
        }
    }

@media  screen and (min-width:400px) and (max-width:480px ){
        .demo{
           height: 100%;
           width: 100%;
        }

        .product-price {
        font-size: 15px;
        font-weight: 400;
        margin-left: -81px;
        }

        .product-title {
        font-size: 16px;
        height: 30px;
        margin-right: 83px;
        }
        
        .responsive{
            height: 70%;
            width: 70%;
        }

         #top-bar-shubhnew{
            display: none;
            }

        .test{
            position: absolute;
            top:30%;
            width: 100%;
            height: 230px;
            user-select: none; -ms-user-select: none; -moz-user-select: none;
        }
        .test h4{
            font-size: 6px;
        }

        .test img{
            border-radius: 10px;
        }

        .owl-carousel .owl-item img {
                        display: block;
                        width: 100%;
                        margin-left: -40px;
                        -webkit-transform-style: preserve-3d;
                        /* box-shadow: 5px 5px 10px #aaaaaa; */
                    }
    }


   @media  screen and (min-width: 300px) and (max-width: 400px) { 

                .owl-carousel .owl-item img {
                        display: block;
                        width: 100%;
                        margin-left: -43px;
                        -webkit-transform-style: preserve-3d;
                        /* box-shadow: 5px 5px 10px #aaaaaa; */
                    }

            .product-carousel-text {
                /* margin-top: 220px; */
                margin-top: -15px;
                margin-right: 80px;
                /* height: 150px; */
                height: 85px;
                text-align: center;
                position: relative;
            }

            #top-bar-shubh{
                margin: 0;
                z-index: 9999;
                /* background-color: #e90505; */
                background-image: linear-gradient(
                315deg, #e90505 100%, white 0%);

                height: 37px;
                color: #ffffff;
                font-size: 13px;
                font-weight: 200;
                padding-left: 20px;
                 /*font-family: 'Mada', sans-serif;*/
            }

            .header-top-entry .title {
            padding: 0 26px;
            }

            .open-cart-popup{
                display: none;
            }

            #logo img {
            display: none;
            width: 60%;
            padding-top: 5px;
            }

            #latest{
            margin-top: -84px;
            }

            #top-bar-shubhnew{
            display: none;
            }


        .section-padding.product-carousel-wrapper .owl-carousel .owl-controls .owl-nav .owl-prev, .section-padding.blog-area-wrapper .owl-carousel .owl-controls .owl-nav .owl-prev, .section-padding.logo-carousel-wrapper .owl-carousel .owl-controls .owl-nav .owl-prev {
        left: 10px;
        padding-bottom: -39px;
        margin-top: -60px;
        }

        .section-title h2 {
        padding-left: 0px;
        font-size: 15px;
        margin-top: 10px;
        }


        .section-padding.product-carousel-wrapper .owl-carousel .owl-controls .owl-nav .owl-next, .section-padding.blog-area-wrapper .owl-carousel .owl-controls .owl-nav .owl-next, .section-padding.logo-carousel-wrapper .owl-carousel .owl-controls .owl-nav .owl-next {
            margin-top: -60px;
            right: 0px;
        }


        .test{
            position: absolute;
            top:18%;
            width: 100%;
            height: 200px;
            user-select: none; -ms-user-select: none; -moz-user-select: none;
        }
        .test h4{
            font-size: 5px;
        }

        .test img{
            border-radius: 10px;
        }

            .responsive{
            height: 50%;
            width: 50%;
        }


   }


    @media  screen and (min-width:600px) and (max-width:800px ){
        .demo{
           height: 100%;
           width: 100%;
        }

        .responsive{
            height: 75%;
            width: 70%;
        }

        .test{
            position: absolute;
            top:30%;
            width: 100%;
            height: 380px;
            user-select: none; -ms-user-select: none; -moz-user-select: none;
        }
        .test h4{
            font-size: 10px;
        }

        .test img{
            border-radius: 30px;
        }
    }

/*for mobile latest
    #latest{
        margin-top: 146px;
    }
    @media  screen and (min-width:400px) and (max-width:550px ){
            #latest{
            margin-top: -100px;
            }
        #top-bar-shubhnew{
            margin: 0;
            z-index: 9999;
            /* background-color: #e90505; */
            background-image: linear-gradient(white, white, white);
            /* background-image: linear-gradient(
            180deg, red, yellow); */
            height: 37px;
            color: #ffffff;
            font-size: 2px;
            font-weight: 200;
            padding-left: 0%;
            border-bottom: 2px solid #ffedeb;
            border-top: 2px solid #ffedeb;
        }

        .single-product-carousel-item{
            /*background-color: orange; */*/
            text-align: center;
            vertical-align: middle;
            display: table-cell;
            /* border: 2px solid black; */
            /* margin-right: 2px; */
            /*padding-left: 106px;*/
        }

     @media  screen and (max-width: 768px){
        .text-center.pranali{
            padding-left: 44px;
            height: 45px;
            margin-right: 300px;
            margin-left: -265px;
            padding-left: 474px;
            margin-top: -47px;
            padding-right: 169px;
        }

        .image_div_shubh 
        {
            text-align: center;
            vertical-align: middle;
        }

        .single-product-item {
            cursor: pointer;
            height: 50px;
            /* width: 50px; */
            width: 170px;
            display: inline-block;
            background-color: #fff;
        }

     }

     @media  screen and (max-width: 768px){
        .text-center.sociallinks{
            margin-top: -52px;
            margin-right: -44px;
        }
     }
     @media  screen and (max-width: 768px){
        .text-center.joinus{
            text-align: left;
            padding-left: 30px;
        }
     }

     @media  screen and (max-width: 1024px)
     {

            .home-wrapper {
                background-color: white;
                padding-bottom: 0px;
            }
     }

    }

/*end of for mobile latest


    @media  screen and (min-width:400px) and (max-width:550px ){
        .demo{
           height: 100%;
           width: 100%;
        }

        .responsive{
            height: 75%;
            width: 70%;
        }

        .test{
            position: absolute;
            top:30%;
            width: 100%;
            height: 230px;
            user-select: none; -ms-user-select: none; -moz-user-select: none;
        }
        .test h4{
            font-size: 6px;
        }

        .test img{
            border-radius: 15px;
        }
    }



    @media  screen and (min-width: 480px) {
       /* .leftsidebar {width: 200px; float: left;}
        .main {margin-left: 216px;}*/
     /*   .boxline{
                height: 50px;
                width: 100%;
                background-color: white;
                margin-left: 127px;
        }*/
        
}



</style>

 <div class="home-wrapper">

    <!--start newslider as per client -->
    <div class="col-lg-12">

          <div id="myCarousel" class="carousel slide demo"  data-ride="carousel">
                    <div class="carousel-inner">
                            <?php $__currentLoopData = $mainslider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="item <?php echo e($key == 0 ? 'active':''); ?>">
                                <a href="<?php echo e($banner->link); ?>">
                                    <img style="border-radius: 25px; width: 100%;" src="<?php echo e(url('/assets')); ?>/images/sliders/<?php echo e($banner->image); ?>">
                                </a>
                              </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                             <!-- <div class="item active">
                                <img src="https://images-na.ssl-images-amazon.com/images/G/01/AmazonExports/Fuji/2021/June/Fuji_TallHero_Gamers_en_US_1x._CB667161802_.jpg" alt="Los Angeles" style="width:100%; height: 100%;">
                              </div>

                              <div class="item">
                                <img src="https://images-na.ssl-images-amazon.com/images/G/01/AmazonExports/Fuji/2020/May/Hero/Fuji_TallHero_45M_v2_1x._CB432458380_.jpg" alt="Chicago" style="width:100%; height: 100%; ">
                              </div>
                            
                              <div class="item">
                                <img src="https://images-na.ssl-images-amazon.com/images/G/01/AmazonExports/Fuji/2020/May/Hero/Fuji_TallHero_Toys_en_US_1x._CB431858161_.jpg" alt="New York" style="width:100%; height: 100%;">
                             </div>
 -->

                                     <!-- <div style="position: absolute; top: 31%; user-select: none; -ms-user-select: none; -moz-user-select: none;">

                                        
                                            <div class="boxline">
                                                <div class="text-center">
                                                <h5 style="padding-top: 17px;">You are on Reachoptic.com You can also shop on Reachoptic India for millions of products with fast local delivery. Click here to go to reachoptic.com</h5>                                                    
                                                </div>
                                            </div>
                                    
                                    </div> -->

                                <!-- <div class="test">
                                    <div class="flex-container">
                                         <?php $__currentLoopData = $smallbox; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div> 
                                            
                                             <h4><?php echo e($banner->title); ?></h4>
                                            <a href="<?php echo e($banner->link); ?>">

                                                <img src="<?php echo e(url('/assets')); ?>/images/sliders/<?php echo e($banner->image); ?>" class="responsive" style="border-radius: 20px;">
                                            </a>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div> -->



                    </div>
             </div>
    </div>
</div>
<!-- end newslider as per client -->

       <!--  <?php if($pagesettings[0]->category_status): ?> -->
        <!-- Starting of featured product area
        <div class="section-padding featured-categories padding-bottom-0 wow fadeInUp">
            <div class="container">
                <div class="product-featured-full-div">-->
                   <!--  <div class="row margin-bottom-0">
                        <div class="col-md-12">
                            <div class="section-title">
                                <h2><?php echo e($language->top_category); ?></h2>
                                
                            </div>
                        </div>
                    </div> -->
                    <!-- <div class="row featured-list">
                        <div class="featured-categories-wrapper">
                            <div class="col-md-6 col-sm-12">
                                <div class="single-featured-area">
                                    <a href="<?php echo e(url('/category')); ?>/<?php echo e($fcategory->slug); ?>">
                                        <img class="featured-img" src="<?php echo e(url('/assets')); ?>/images/categories/<?php echo e($fcategory->feature_image); ?>" alt="">
                                        <div class="product-feature-content">
                                            <h3><?php echo e($fcategory->name); ?></h3>
                                            <?php if(\App\Product::where('status','1')->whereRaw('FIND_IN_SET(?,category)', [$fcategory->id])->count()>1): ?>
                                                <p><?php echo e(\App\Product::where('status','1')->whereRaw('FIND_IN_SET(?,category)', [$fcategory->id])->count()); ?> products</p>
                                            <?php else: ?>
                                                <p><?php echo e(\App\Product::where('status','1')->whereRaw('FIND_IN_SET(?,category)', [$fcategory->id])->count()); ?> product</p>
                                            <?php endif; ?>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <?php $__currentLoopData = $fcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 col-sm-6">
                                <div class="single-featured-area">
                                    <a href="<?php echo e(url('/category')); ?>/<?php echo e($fcat->slug); ?>">
                                        <img class="featured-img" src="<?php echo e(url('/assets')); ?>/images/categories/<?php echo e($fcat->feature_image); ?>" alt="">
                                        <div class="product-feature-content">
                                            <h4><?php echo e($fcat->name); ?></h4>
                                            <?php if(\App\Product::where('status','1')->whereRaw('FIND_IN_SET(?,category)', [$fcat->id])->count()>1): ?>
                                                <p><?php echo e(\App\Product::where('status','1')->whereRaw('FIND_IN_SET(?,category)', [$fcat->id])->count()); ?> products</p>
                                            <?php else: ?>
                                                <p><?php echo e(\App\Product::where('status','1')->whereRaw('FIND_IN_SET(?,category)', [$fcat->id])->count()); ?> product</p>
                                            <?php endif; ?>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div> -->
                <!--</div>-->
           <!--  </div>
        </div> -->
        <!-- Ending of featured product area -->
        <!-- <?php endif; ?> -->

        <!--<?php if($pagesettings[0]->sbanner_status): ?>-->
        <!-- Starting of product-imageBlog area -->
        <!--<div class="section-padding product-imageBlog-section padding-top-0 padding-bottom-0 wow fadeInUp">-->
        <!--    <div class="container">-->
        <!--        <div class="row">-->
        <!--            <div class="col-md-12">-->
                        <!--<div class="product-imgBlog-fullDiv">-->
        <!--                    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
        <!--                    <div class="col-md-4">-->
        <!--                        <a href="<?php echo e($banner->link); ?>" target="_blank">-->
        <!--                            <img src="<?php echo e(url('/assets')); ?>/images/brands/<?php echo e($banner->image); ?>" alt="">-->
        <!--                        </a>-->
        <!--                    </div>-->
        <!--                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                        <!--</div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->
        <!-- Ending of product-imageBlog area -->
        <!--<?php endif; ?>-->
        
        
        <!---LATEST ARRIVALS--->
        <?php if($pagesettings[0]->latestpro_status): ?>
        <!-- starting of new project area -->
        <div class="section-padding product-carousel-wrapper padding-bottom-0 wow fadeInUp" id="latest">
            <div class="container-fluid">
            <!-- pranali's code for 4 banner -->
                </div>
                    <div class="flex-container">
                         <?php $__currentLoopData = $smallbox; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>  
                             <h4><?php echo e($banner->title); ?></h4>
                            <a href="<?php echo e($banner->link); ?>">
                                <img src="<?php echo e(url('assets/images/sliders')); ?>/<?php echo e($banner->image); ?>" class="responsive" >
                            </a>
                        </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
                    </div>

                    <!-- end of pranali's code for 4 banner -->

                <!--<div class="product-carousel-full-div">-->
                    <div class="row margin-bottom-0">
                        <div class="col-md-12">
                            <div class="section-title padding-bottom-0">
                                <h2 class="margin-bottom-0" style="margin-top: 30px;"><?php echo e($language->latest_products); ?></h2>
                                <!--<hr>-->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <!--<div class="col-md-12">-->
                            <div class="col-md-4 product-carousel-list">
                                <?php $__currentLoopData = $new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-product-carousel-item text-center margin-left-0" style="padding-left: 106px">
                                        <div class="image_latest_product_shubh">
                                        <!--<a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" alt="Product Image" /> </a>-->
                                        <?php  $gallery = $product->gallery_images->toArray();  ?>
                                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php if(!empty($gallery)): ?><?php echo e(url('/assets/images/gallery')); ?>/<?php echo e($gallery[0]['image']); ?><?php endif; ?>" src="assets/images/subscription-form/subscibe_image.jpg" alt="Product Image" /> </a>
                                        <a class="img-top" href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" alt="Product Image" /> </a>
                                        </div>
                                        <div class="product-carousel-text">
                                            <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>">
                                                <h4 class="product-title"><?php echo e($product->title); ?></h4>
                                            </a>
                                            <!--<div class="ratings">-->
                                            <!--    <div class="empty-stars"></div>-->
                                            <!--    <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($product->id)); ?>%"></div>-->
                                            <!--</div>-->
                                            <div class="product-price">
                                                <?php if($product->previous_price != ""): ?>
                                                    <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Product::Cost($product->id)); ?></span>
                                                <?php else: ?>
                                                <?php endif; ?>
                                                <del class="offer-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->previous_price); ?></del>
                                            </div>
                                            <!--<div class="product-meta-area">-->
                                            <!--    <form class="addtocart-form">-->
                                            <!--        <?php echo e(csrf_field()); ?>-->
                                            <!--        <?php if(Session::has('uniqueid')): ?>-->
                                            <!--            <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">-->
                                            <!--        <?php else: ?>-->
                                            <!--            <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">-->
                                            <!--        <?php endif; ?>-->
                                            <!--        <input type="hidden" name="title" value="<?php echo e($product->title); ?>">-->
                                            <!--        <input type="hidden" name="product" value="<?php echo e($product->id); ?>">-->
                                            <!--        <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($product->id)); ?>">-->
                                            <!--        <input type="hidden" id="quantity" name="quantity" value="1">-->
                                            <!--        <?php if($product->stock != 0 || $product->stock === null ): ?>-->
                                            <!--            <button type="button" class="addTo-cart to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>-->
                                            <!--        <?php else: ?>-->
                                            <!--            <button type="button" class="addTo-cart  to-cart" disabled><i class="fa fa-cart-plus"></i><?php echo e($language->out_of_stock); ?></button>-->
                                            <!--        <?php endif; ?>-->
                                            <!--    </form>-->
                                                <!--<a  href="javascript:;" class="wish-list" onclick="getQuickView(<?php echo e($product->id); ?>)" data-toggle="modal" data-target="#myModal">-->
                                                <!--    <i class="fa fa-eye"></i>-->
                                                <!--</a>-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <!--</div>-->
                    </div>
                <!--</div>-->
            </div>
        </div>
        <!-- Ending of new project area -->
        <?php endif; ?>
        
        <!--TRENDING PRODUCTS-->
        <?php if($pagesettings[0]->featuredpro_status): ?>
        <!-- starting of featured project area -->
        <div class="section-padding product-carousel-wrapper padding-top-0 padding-bottom-0 wow fadeInUp">
            <div class="container-fluid">
                <!--<div class="product-carousel-full-div">-->
                    <div class="row margin-bottom-0">
                        <div class="col-md-12">
                            <div class="section-title">
                                <h2 class="margin-bottom-0"><?php echo e($language->featured_products); ?></h2>
                                <!--<hr>-->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <!--<div class="col-md-12">-->
                            <div class="product-carousel-list">
                                <?php $__currentLoopData = $tranding; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-product-carousel-item text-center" style="padding-left: 106px;">
                                        <div class="image_latest_product_shubh">
                                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" alt="Product Image" /> </a>
                                        <?php  $gallery = $product->gallery_images->toArray();  ?>
                                        <a class="img-top" href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php if(!empty($gallery)): ?><?php echo e(url('/assets/images/gallery')); ?>/<?php echo e($gallery[0]['image']); ?><?php endif; ?>" src="assets/images/subscription-form/subscibe_image.jpg" alt="Product Image" style="margin: 0px; margin-left: 0px;" /> </a>
                                        </div>
                                        <div class="product-carousel-text">
                                            <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>">
                                                <h3 class="product-title"><?php echo e($product->title); ?></h3>
                                            </a>
                                            <!--<div class="ratings">-->
                                            <!--    <div class="empty-stars"></div>-->
                                            <!--    <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($product->id)); ?>%"></div>-->
                                            <!--</div>-->
                                            <div class="product-price">
                                                <?php if($product->previous_price != ""): ?>
                                                    <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Product::Cost($product->id)); ?></span>
                                                <?php else: ?>
                                                <?php endif; ?>
                                                <del class="offer-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->previous_price); ?></del>
                                            </div>
                                            <!--<div class="product-meta-area">-->
                                            <!--    <form class="addtocart-form">-->
                                            <!--        <?php echo e(csrf_field()); ?>-->
                                            <!--        <?php if(Session::has('uniqueid')): ?>-->
                                            <!--            <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">-->
                                            <!--        <?php else: ?>-->
                                            <!--            <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">-->
                                            <!--        <?php endif; ?>-->
                                            <!--        <input type="hidden" name="title" value="<?php echo e($product->title); ?>">-->
                                            <!--        <input type="hidden" name="product" value="<?php echo e($product->id); ?>">-->
                                            <!--        <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($product->id)); ?>">-->
                                            <!--        <input type="hidden" id="quantity" name="quantity" value="1">-->
                                            <!--        <?php if($product->stock != 0 || $product->stock === null ): ?>-->
                                            <!--            <button type="button" class="addTo-cart to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>-->
                                            <!--        <?php else: ?>-->
                                            <!--            <button type="button" class="addTo-cart  to-cart" disabled><i class="fa fa-cart-plus"></i><?php echo e($language->out_of_stock); ?></button>-->
                                            <!--        <?php endif; ?>-->
                                            <!--    </form>-->
                                                <!--<a  href="javascript:;" class="wish-list" onclick="getQuickView(<?php echo e($product->id); ?>)" data-toggle="modal" data-target="#myModal">-->
                                                <!--    <i class="fa fa-eye"></i>-->
                                                <!--</a>-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <!--</div>-->
                    </div>
                <!--</div>-->
            </div>
        </div>
        <!-- Ending of featured project area -->
        <?php endif; ?>
        
        <?php if($pagesettings[0]->popularpro_status): ?>
        <!-- starting of best seller area -->
        <div class="section-padding product-carousel-wrapper padding-bottom-0 wow fadeInUp">
            <div class="container">
                <!--<div class="product-carousel-full-div">-->
                    <div class="row margin-bottom-0">
                        <div class="col-md-12">
                            <div class="section-title">
                                <h2><?php echo e($language->popular_products); ?></h2>
                                <!--<hr>-->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="product-carousel-list">
                                <?php $__currentLoopData = $tops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-product-carousel-item text-center">
                                        <div class="image_latest_product_shubh">
                                            <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" alt="Product Image" /> </a>
                                        </div>
                                        <div class="product-carousel-text">
                                            <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>">
                                                <h4 class="product-title"><?php echo e($product->title); ?></h4>
                                            </a>
                                            <div class="ratings">
                                                <div class="empty-stars"></div>
                                                <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($product->id)); ?>%"></div>
                                            </div>
                                            <div class="product-price">
                                                <?php if($product->previous_price != ""): ?>
                                                    <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Product::Cost($product->id)); ?></span>
                                                <?php else: ?>
                                                <?php endif; ?>
                                                <del class="offer-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->previous_price); ?></del>
                                            </div>
                                            <div class="product-meta-area">
                                                <form class="addtocart-form">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php if(Session::has('uniqueid')): ?>
                                                        <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                                    <?php else: ?>
                                                        <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                                    <?php endif; ?>
                                                    <input type="hidden" name="title" value="<?php echo e($product->title); ?>">
                                                    <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                                    <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($product->id)); ?>">
                                                    <input type="hidden" id="quantity" name="quantity" value="1">
                                                    <?php if($product->stock != 0 || $product->stock === null ): ?>
                                                        <button type="button" class="addTo-cart to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>
                                                    <?php else: ?>
                                                        <button type="button" class="addTo-cart  to-cart" disabled><i class="fa fa-cart-plus"></i><?php echo e($language->out_of_stock); ?></button>
                                                    <?php endif; ?>
                                                </form>
                                                <a  href="javascript:;" class="wish-list" onclick="getQuickView(<?php echo e($product->id); ?>)" data-toggle="modal" data-target="#myModal">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <!--</div>-->
                </div>
            </div>
        </div>
        <!-- Ending of best seller area -->
        <?php endif; ?>
        
        
        <!--Advertisement full banner-->
       <!--  <?php if($pagesettings[0]->lbanner_status): ?> -->
        <!-- Starting of Breadcroumb area -->
        <!-- <div class="breadcroumb-section text-center  wow fadeInUp">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <a href="<?php echo e($pagesettings[0]->banner_link); ?>" target="_blank">
                            <img height="700px" width="1500px" id="advertisement-full-banner-shubh" style="width: 100%;" src="<?php echo e(url('/assets/images')); ?>/<?php echo e($pagesettings[0]->large_banner); ?>" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- Ending of Breadcroumb area -->
        <!-- <?php endif; ?> -->

         <!--Advertisement full banner-->
        <?php if($pagesettings[0]->lbanner_status): ?>
        <!-- Starting of New Home Slider area -->
    <div class="container" style="width: 100%; max-height: 100%;">
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
          <!--   <ol class="carousel-indicators">
              <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
              <li data-target="#myCarousel" data-slide-to="1"></li>
              <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol> -->

            <!-- Wrapper for slides -->
            
            <div class="carousel-inner">
                <?php $__currentLoopData = $newsliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="item <?php echo e($key == 0 ? 'active':''); ?>">
                    <a href="<?php echo e($banner->link); ?>" target="_blank">
                        <img style="border-radius: 25px; " src="<?php echo e(url('/assets')); ?>/images/sliders/<?php echo e($banner->image); ?>" class="img-responsive" alt="Responsive image">
                    </a>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            

            <!-- Left and right controls -->
            
        </div>
    </div>

        <!-- Ending of New Home Slider area -->
        <?php endif; ?>




        
        <!--Advertisement small banner-->
        <?php if($pagesettings[0]->sbanner_status): ?>
         <!--Starting of product-imageBlog area -->
        <div class="section-padding product-imageBlog-section padding-bottom-0 wow fadeInUp">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 padding-left-0">
                        <!--<div class="product-imgBlog-fullDiv">-->
                            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <a href="<?php echo e($banner->link); ?>" target="_blank">
                                    <img height="400" width = "400" id="small-ads-image-shubh" src="<?php echo e(url('/assets')); ?>/images/brands/<?php echo e($banner->image); ?>" class="img-responsive" alt="Responsive image">
                                </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--</div>-->
                    </div>
                </div>
            </div>
        </div>
         <!--Ending of product-imageBlog area -->
        <?php endif; ?>
        
        
        <!--<?php if($pagesettings[0]->subscribe_status): ?>-->
        <!-- Starting of product subscribe form area -->
        <!--<div class="container-fluid">-->
        <!--    <div class="row">-->
        <!--        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">-->
        <!--            <div class="product-subscribe-section text-center wow fadeInUp">-->
        <!--                <img src="<?php echo e(url('/assets/images')); ?>/<?php echo e($settings[0]->background); ?>" alt="">-->
        <!--                <div class="product-subscribe-form">-->
        <!--                    <div class="row">-->
        <!--                        <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2  col-xs-10 col-xs-offset-1">-->
                                    <!--<div class="product-subscribe-form-content">
                                        <div class="product-subscribe-icon">
                                            <i class="fa fa-envelope-o"></i>
                                        </div>
                                        <h1><?php echo e($language->subscription); ?></h1>
                                        
                                        <p id="resp"></p>
                                        <form id="subform" action="<?php echo e(action('FrontEndController@subscribe')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="email" id="email" placeholder="Enter Email" name="email" required>

                                            <input id="subs"  type="button" class="btn subscribe-btn" value="<?php echo e($language->subscribe); ?>">
                                        </form>
                                    </div>
                                </div>
                            </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->

        <!-- Ending of product subscribe form area -->
        <!--<?php endif; ?>-->


        <?php if($pagesettings[0]->blogs_status): ?>
        <!-- Starting of blog area -->
        <div class="section-padding blog-area-wrapper padding-bottom-0 wow fadeInUp">
            <div class="container">
                <div class="blog-area-fullDiv">
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="section-title text-center">
                                <h2><?php echo e($languages->blog_title); ?></h2>
                                <p><?php echo e($languages->blog_text); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="blog-area-slider">
                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-blog-box">
                                    <div class="blog-thumb-wrapper">
                                        <img src="<?php echo e(url('/assets')); ?>/images/blog/<?php echo e($blog->featured_image); ?>" alt="Blog Image">
                                    </div>
                                    <div class="blog-text">
                                        <p class="blog-meta"><?php echo e(date('d M Y',strtotime($blog->created_at))); ?></p>
                                        <h4><?php echo e($blog->title); ?></h4>
                                        <p><?php echo e(substr(strip_tags($blog->details),0,125)); ?></p>
                                        <a href="<?php echo e(url('/blog')); ?>/<?php echo e($blog->id); ?>" class="blog-more-btn"><?php echo e($language->view_details); ?></a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ending of blog area -->
        <?php endif; ?>
        <?php if($pagesettings[0]->testimonial_status): ?>
        <!-- Starting of customer review carousel area -->
        <div class="customer-review-carousel-wrapper text-center wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="customer-review-carousel-image">
                            <img src="<?php echo e(url('/assets/images')); ?>/<?php echo e($settings[0]->background); ?>" alt="">

                            <div class="review-carousel-table">
                                <div class="review-carousel-table-cell">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-12">
                                                <div class="section-title text-center">
                                                    <h2><?php echo e($languages->testimonial_title); ?></h2>
                                                    <p><?php echo e($languages->testimonial_text); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-8 col-sm-offset-2">
                                                <div class="testimonial-section animated fadeInRight">
                                                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="single-testimonial-area">
                                                        <div class="testimonial-text">
                                                            <p><?php echo e($testimonial->review); ?></p>
                                                        </div>
                                                        <div class="testimonial-author">
                                                            <img src="<?php echo e(url('/assets/images/cusavatar.png')); ?>" alt="Author">
                                                            <h4><strong><?php echo e($testimonial->client); ?></strong> <br> <?php echo e($testimonial->designation); ?></h4>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ending of customer review carousel area -->
        <?php endif; ?>
        
        
        
        <?php if($pagesettings[0]->brands_status): ?>
         <!--Starting of brandLogo-carousel-wrapper area -->
        <div class="section-padding logo-carousel-wrapper padding-bottom-0 wow fadeInUp">
            <div class="container-fluid">
                <div class="row">
                    <!--<div class="col-md-12">-->
                        <div class="logo-carousel">
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-logo-item">
                                <div class="logo-item-inner">
                                   <img src="<?php echo e(url('/assets/images/brands')); ?>/<?php echo e($brand->image); ?>" alt="">
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    <!--</div>-->
                </div>
            </div>
        </div>
         <!--Ending of brandLogo-carousel-wrapper area -->
        <?php endif; ?>
        
        <!-- Pranali's Code For Bottom Slider -->
        <?php if($pagesettings[0]->subscribe_status): ?>

            <div class="section-padding padding-bottom-0 wow fadeInUp">
                <div class="container-fluid">
                    <div class="row" >
                        <div class="col-md-4" >
                            <a href="<?php echo e($banner->link); ?>" target="_blank">
                                <img style="max-height : 388px; width: 100%; margin-left: 0px;"  id="subscription_form_image" src="<?php echo e(url('/assets/images')); ?>/<?php echo e($settings[0]->background); ?>"  class="img-responsive" alt="Responsive image">
                            </a>
                        </div>
                        <div class="col-md-8" >
                            <div id="myCarousel" class="carousel slide" data-ride="carousel">
                                <div class="carousel-inner">
                                  <?php $__currentLoopData = $bottomslider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <div class="item <?php echo e($key == 0 ? 'active':''); ?>">
                                        <a href="<?php echo e($banner->link); ?>">
                                            <img  id="bottomslider"style="border-radius: 25px; width: 100%; height: 380px;" src="<?php echo e(url('/assets')); ?>/images/sliders/<?php echo e($banner->image); ?>">
                                        </a>
                                      </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php endif; ?>
    <!-- End of Pranali's Code For Bottom Slider -->

        <br><br>
        <!-- pranali's Code For Subscribe For -->

        <div class="row" style="background: #C0C0C0; height: 55px; margin-right: 0px;">
            <div class="col-md-4" style="padding-top: 18px;" >
                <div class="text-center joinus">

                     <h5 style="align-content: center;">BE IN TOUCH WITH US:</h5> 
                </div>
            </div>
            <div class="col-md-5" style="padding-top: 4px;">

                <div class="text-center pranali"> 

                    <form id="subform" action="<?php echo e(action('FrontEndController@subscribe')); ?>" method="post">
                         <?php echo e(csrf_field()); ?>

                         <div class="input-group">  
                           <input type="email" name="email" id="email" class="form-control" style="height: 47px; margin-right: 238px;" placeholder="Enter Email" >
                           
                             
                              <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">JOIN US</button>
                                
                              </span>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-3">
                <div class="text-center sociallinks ">
                    <div class="footer-social-links" style="padding-top: 12px; padding-right: 45px;" >
                            <li>
                                <a href="https://www.facebook.com/login/?next=https%3A%2F%2Fwww.facebook.com%2Febangladesh "style="border: none;" ><img src="https://img.icons8.com/ios/50/000000/facebook-new.png"/></a>
                            
                            </li>                        
                            <li>
                                <a href="https://www.instagram.com/"style="border: none;"><img src="https://img.icons8.com/fluency-systems-regular/48/000000/instagram-new--v1.png"/></a>   
                            </li>
                            
                            <li>
                                <a href="https://twitter.com/" style="border: none;" >
                                    <img src="https://img.icons8.com/ios/48/000000/twitter-circled--v1.png"/>
                                </a>
                            </li>
                    </div> 
                </div>
            </div>
       </div>
<br>
<!-- End Of pranali's Code For Subscribe For  -->







        <!-- <?php if($pagesettings[0]->subscribe_status): ?> -->
        <!-- Starting of product subscribe form area -->
        <!-- <div class="section-padding padding-bottom-0 wow fadeInUp">
            <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="col-lg-4 col-md-4 col-xs-12  padding-right-0 padding-left-5">
                        <a href="<?php echo e($banner->link); ?>" target="_blank">
                            <img style="max-height : 400px; width: 100%; margin-left: 0px;"  id="subscription_form_image" src="<?php echo e(url('/assets/images')); ?>/<?php echo e($settings[0]->background); ?>"  class="img-responsive" alt="Responsive image">
                        </a>
                    </div>
                    <div class="col-md-8 col-xs-12 padding-right-0 padding-left-0" style="border : 1px solid black; max-height : 390px; max-width:960px; border-radius : 20px; position : relative;padding: 20px; margin-bottom: 10px; margin-left: 3px;">
                        <div class="product-subscribe-form-content-shubh">
                                <div class="subscription-title-shubh">
                                    <h4 id="subscription-heading-shubh">Subscribe for exclusive Reach newsletter</h4>  
                                    <p id="subscription-paragraph-shubh">To receive 
                                    early bird promotional offers and new product arrivals updates</p>
                                </div>
                                <div class="padding-right-0">
                                    
                                    <p id="resp"></p>
                                    <form id="subform" action="<?php echo e(action('FrontEndController@subscribe')); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <input id="email" placeholder="Enter your email address" type="email" name="email" required/>
                                       
                                        <input id="subs"  type="submit" class="subscribe-button" value="<?php echo e($language->subscribe); ?>">
                                    </form>
                                </div>
                            </div>
                        
                    </div>
                </div>
            </div>
            </div>
        </div> -->

        <!-- Ending of product subscribe form area -->
        <!-- <?php endif; ?> -->
        
        <!--<?php if($pagesettings[0]->brands_status): ?>-->
        <!-- Starting of brandLogo-carousel-wrapper area -->
        <!--<div class="section-padding logo-carousel-wrapper  wow fadeInUp">-->
        <!--    <div class="container-fluid">-->
        <!--        <div class="row">-->
                    <!--<div class="col-md-12">-->
        <!--                <div class="logo-carousel">-->
        <!--                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
        <!--                    <div class="single-logo-item">-->
        <!--                        <div class="logo-item-inner">-->
        <!--                            <img src="<?php echo e(url('/assets/images/brands')); ?>/<?php echo e($brand->image); ?>" alt="">-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->

        <!--                </div>-->
                    <!--</div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->
        <!-- Ending of brandLogo-carousel-wrapper area -->
        <!--<?php endif; ?>-->

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script>
// Wrap every letter in a span
// Wrap every letter in a span
var textWrapper = document.querySelector('.ml10 .letters');
textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

anime.timeline({loop: true})
  .add({
    targets: '.ml10 .letter',
    rotateY: [-90, 0],
    duration: 1300,
    delay: (el, i) => 45 * i
  }).add({
    targets: '.ml10',
    opacity: 0,
    duration: 1000,
    easing: "easeOutExpo",
    delay: 1000
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.newmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>