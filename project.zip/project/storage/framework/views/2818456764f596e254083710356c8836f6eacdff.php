<!DOCTYPE html>
<html>
<head>
	<title>Acknoeledgement Slip</title>
</head>
<body>

<h1><?php echo e($order->order_number_new); ?></h1>

</body>
</html>