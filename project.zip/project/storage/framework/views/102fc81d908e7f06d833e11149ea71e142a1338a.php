<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script
    src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet"
    href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet"
    href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">
<style type="text/css">
    .content-box {
        background-color: #fafafb;
        box-shadow: 1px 4px 8px rgba(0,0,0,.15);
        transition: all .3s ease-in-out;
        padding: 10px;
        padding-bottom: 0;
        margin-top: 40px;
        margin-bottom: 10px;
        height: 250px;
    }
.content-box .finbyz-icon {
    height: 100px;
    width: 100px;
    display: inline;
}

</style>

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row" id="main">
                <!-- Page Heading -->
                <div class="go-title">
                   <!--  <div class="pull-right">
                        <a href="<?php echo url('vendor/withdrawmoney'); ?>" class="btn btn-primary btn-add"><i class="fa fa-download"></i> Withdraw Now</a>
                    </div> -->
                    <h3>Payment Overview</h3>
                    <div class="go-line"></div>
                </div>
                <!-- Page Content -->
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div id="response">
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                        </div>


                    <div class="container">
                        <div class="row">   
                            <div class="col-md-4 text-center" style="opacity: 1;">
                               <div class="content-box">
                                <h4 class="content-box-title text-left"><b>Order Value</b></h4>
                                <p class="content-box-sub text-left" >COD<a style="padding-left: 30%;"  id="showmenu"> ₹ <?php echo e($CODtotal); ?></a></p>
                                <p class="content-box-sub text-left" >E-Payment <a  style="padding-left: 19%;" id="showmenu2"> ₹ <?php echo e($Onlinetotal); ?></a></p>
                                <hr>
                                <p class="content-box-sub text-left">Total  <a style="padding-left: 30%;">₹ <?php echo e($OrderTotalCost); ?></a></p>
                                <small class="text-left">When Order Receive Outstanding Amount Will Reflect Here</small>
                               </div>
                            </div>

                            <div class="col-md-4" style="opacity: 1;">
                                <div class="content-box">
                                <h4 class="content-box-title"><b>Cancel Order</b></h4>
                                <p class="content-box-sub text-left">Cancel COD <a style="padding-left: 30%;" id="showmenu3" >₹ <?php echo e($CancelCODOrdertotal); ?></a> </p>
                                <p class="content-box-sub text-left">Cancel E-Payment <a style="padding-left: 19%;" id="showmenu4" >₹ <?php echo e($CanceOnlineOrdertotal); ?></a> </p>
                                <hr>
                                <p class="content-box-sub text-left">Total - <a style="padding-left: 42%">₹ <?php echo e($CancelOrderTotalCost); ?></a></p>
                                <small>Order Cancelled Before Dispatch Will Reflect here</small>
                                </div>
                            </div>

                            <div class="col-md-4" style="opacity: 1;">
                                <div class="content-box">
                                <h4 class="content-box-title"><b>Return Order</a></b></h4>
                                <p class="content-box-sub text-left">Return COD - <a id="showmenu5" style="padding-left: 30%;">₹ <?php echo e($ReturnCODOrdertotal); ?></a> </p>
                                <p class="content-box-sub text-left">Return E-Payment - <a id="showmenu6" style="padding-left: 19%;">₹ <?php echo e($ReturnOnlineOrdertotal); ?></a> </p>
                                <hr>
                                <p class="content-box-sub text-left">Total - <a style="padding-left: 44%;">₹ <?php echo e($ReturnOrderTotalCost); ?></a></p>
                                <small>Order Cancelled After Dispatch Will Reflect here</small>
                                </div>
                            </div>

                            <div class="col-md-4" style="opacity: 1;">
                                <div class="content-box">
                                <h4 class="content-box-title"><b>Today's Settlement ( <?php echo e($todayDate); ?> <?php echo e($todayMonth); ?> )</a></b></h4>
                                <p class="content-box-sub text-left">COD - <a id="showmenu7" style="padding-left: 30%;">₹ <?php echo e($completedCODOrdertotal); ?></a> </p>
                                <p class="content-box-sub text-left">E-Payment - <a id="showmenu8" style="padding-left: 19%;">₹ <?php echo e($completedOnlineOrdertotal); ?></a> </p>
                                <hr>
                                <p class="content-box-sub text-left">Total - <a style="padding-left: 31%">₹ <?php echo e($completedOrderTotalCost); ?></a></p>
                                <small>Payment Has Been Scheduled For Today's Settlement</small>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- COD Pendings Orders List -->
                    <br><br>
                    <div class="demo1" style="display: none;">
                        <h3 id="tpost"><b>Orders Payment Method: COD</b><a style="padding-left: 100px;">Total Amount:₹ <?php echo e($CODtotal); ?></a></h3><hr>
                        <table class="table" id="table">
                            <thead>
                                <tr>
                                    <th class="text-center">ORDER ID</th>
                                    <th class="text-center">ORDER DATE</th>
                                    <th class="text-center">DISCRIPTION</th>
                                    <th class="text-center">AMOUNT</th>
                                    <th class="text-center">ORDER DETAILS</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $CODlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($row->order_number_new); ?></td>
                                    <td class="text-center"><?php echo e($row->created_at); ?></td>
                                    <td class="text-center">SELL</td>
                                    <td class="text-center">₹ <?php echo e($row->cost); ?></td>
                                    <td class="text-center"><a href="<?php echo e(url('admin/orderpayment/view/')); ?>/<?php echo e($row->id); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        
                    </div>
                   
                    <!-- End COD Pendings Orders List -->

                    <!-- Online Pendings Orders List -->
                    <br><br>
                   <div class="demo2" style="display: none;">
                        <hr>
                        <h3 id="tpostone"><b> Orders Payment Method: E-Payment </b><a style="padding-left: 100px;">Total Amount: ₹ <?php echo e($Onlinetotal); ?></a></h3><hr>

                        <table class="table" id="tableone">
                            <thead>
                                <tr>
                                    <th class="text-center">ORDER ID</th>
                                    <th class="text-center">ORDER DATE</th>
                                    <th class="text-center">DISCRIPTION</th>
                                    <th class="text-center">AMOUNT</th>
                                    <th class="text-center">ORDER DETAILS</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $Onlinelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($row->order_number_new); ?></td>
                                    <td class="text-center"><?php echo e($row->created_at); ?></td>
                                    <td class="text-center">SELL</td>
                                    <td class="text-center">₹ <?php echo e($row->cost); ?></td>
                                    <td class="text-center"><a href="<?php echo e(url('admin/orderpayment/view/')); ?>/<?php echo e($row->id); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                            </tbody>
                        </table>  
                   </div> 
                    <!-- End Online Pendings Orders List -->

                    <!-- Cancel COD Orders List  -->

                    <br><br>
                <div class="demo3" style="display: none;">
                    <hr>
                    <h3 id="tposttwo"><b>Cancel Orders Payment Method:COD</b><a style="padding-left: 100px;">Total Amount: ₹ <?php echo e($CancelCODOrdertotal); ?></a></h3><hr>

                    <table class="table" id="tabletwo">
                        <thead>
                                <tr>
                                    <th class="text-center">ORDER ID</th>
                                    <th class="text-center">ORDER DATE</th>
                                    <th class="text-center">DISCRIPTION</th>
                                    <th class="text-center">AMOUNT</th>
                                    <th class="text-center">ORDER DETAILS</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $CancelCODOrderlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($row->order_number_new); ?></td>
                                    <td class="text-center"><?php echo e($row->created_at); ?></td>
                                    <td class="text-center">Cancel</td>
                                    <td class="text-center">-₹ <?php echo e($row->cost); ?></td>
                                    <td class="text-center"><a href="<?php echo e(url('admin/cancelpayment/view')); ?>/<?php echo e($row->id); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                            </tbody>
                    </table>   
                </div>
                    <!-- End Online Pendings Orders List -->

                    <!-- Cancel online Orders List -->

                    <br><br>
                <div class="demo4" style="display: none;">
                    <hr>
                    <h3 id="tpostthree"><b>Cancel Orders Payment Method:E-Payment</b><a style="padding-left: 100px;">Total Amount: ₹ <?php echo e($CanceOnlineOrdertotal); ?></a></h3><hr>

                    <table class="table" id="tablethree">
                        <thead>
                                <tr>
                                    <th class="text-center">ORDER ID</th>
                                    <th class="text-center">ORDER DATE</th>
                                    <th class="text-center">DISCRIPTION</th>
                                    <th class="text-center">AMOUNT</th>
                                    <th class="text-center">ORDER DETAILS</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $CancelOnlineOrderlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($row->order_number_new); ?></td>
                                    <td class="text-center"><?php echo e($row->created_at); ?></td>
                                    <td class="text-center">Cancel</td>
                                    <td class="text-center">-₹ <?php echo e($row->cost); ?></td>
                                    <td class="text-center"><a href="<?php echo e(url('admin/cancelpayment/view')); ?>/<?php echo e($row->id); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                            </tbody>
                    </table>
                </div>
                    <!-- END Cancel online Orders List-->


                    <!-- return COD Orders List -->

                    <br><br>
                <div class="demo5" style="display: none;">
                    <hr>
                    <h3 id="tpostfour"><b>Return Orders Payment Method:COD</b><a style="padding-left: 100px;">Total Amount: ₹ <?php echo e($ReturnCODOrdertotal); ?></a></h3><hr>

                    <table class="table" id="tablethree">
                        <thead>
                                <tr>
                                    <th class="text-center">ORDER ID</th>
                                    <th class="text-center">ORDER DATE</th>
                                    <th class="text-center">DISCRIPTION</th>
                                    <th class="text-center">AMOUNT</th>
                                    <th class="text-center">ORDER DETAILS</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $ReturnCODOrderlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($row->order_number_new); ?></td>
                                    <td class="text-center"><?php echo e($row->created_at); ?></td>
                                    <td class="text-center">Return</td>
                                    <td class="text-center">-₹ <?php echo e($row->cost); ?></td>
                                    <td class="text-center"><a href="<?php echo e(url('admin/returnpayment/view')); ?>/<?php echo e($row->id); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                            </tbody>
                    </table>
                </div>
                    <!--end return COD Orders List-->


                    <!-- return online Orders List -->

                    <br><br>
                <div class="demo6" style="display: none;">
                    <hr>
                    <h3 id="tpostfive"><b> Return Orders Payment Method:E-Payment</b><a style="padding-left: 100px;">Total Amount: ₹ <?php echo e($ReturnOnlineOrdertotal); ?></a></h3><hr>

                    <table class="table" id="tablethree">
                        <thead>
                                <tr>
                                    <th class="text-center">ORDER ID</th>
                                    <th class="text-center">ORDER DATE</th>
                                    <th class="text-center">DISCRIPTION</th>
                                    <th class="text-center">AMOUNT</th>
                                    <th class="text-center">ORDER DETAILS</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $ReturnOnlineOrderlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($row->order_number_new); ?></td>
                                    <td class="text-center"><?php echo e($row->created_at); ?></td>
                                    <td class="text-center">Return</td>
                                    <td class="text-center">-₹ <?php echo e($row->cost); ?></td>
                                    <td class="text-center"><a href="<?php echo e(url('admin/returnpayment/view')); ?>/<?php echo e($row->id); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                            </tbody>
                    </table>
                </div>
                    <!-- End return online Orders List-->


                     <!-- completed COD Orders List -->

                    <br><br>
                <div class="demo7" style="display: none;">
                    <hr>
                    <h3 id="tpostsix"><b>Completed Orders Payment Method:COD</b><a style="padding-left: 100px;">Total Amount: ₹ <?php echo e($completedCODOrdertotal); ?></a></h3><hr>

                    <table class="table" id="tablethree">
                        <thead>
                                <tr>
                                    <th class="text-center">ORDER ID</th>
                                    <th class="text-center">ORDER DATE</th>
                                    <th class="text-center">DISCRIPTION</th>
                                    <th class="text-center">AMOUNT</th>
                                    <th class="text-center">UTR NUMBER</th>
                                    <th class="text-center">ORDER DETAILS</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $completedCODOrderlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($row->order_number_new); ?></td>
                                    <td class="text-center"><?php echo e($row->created_at); ?></td>
                                    <td class="text-center">SALE</td>
                                    <td class="text-center">₹ <?php echo e($row->cost); ?></td>
                                    <td class="text-center">123456789</td>
                                    <td class="text-center"><a href="<?php echo e(url('admin/todaypayment/view')); ?>/<?php echo e($row->id); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                            </tbody>
                    </table>
                </div>
                    <!--end completed COD Orders List-->


                    <!-- completed online Orders List -->

                    <br><br>
                <div class="demo8" style="display: none;">
                    <hr>
                    <h3 id="tpostseven"><b>Completed Orders Payment Method:E-Payment</b><a style="padding-left: 100px;">Total Amount: ₹ <?php echo e($completedOnlineOrdertotal); ?></a></h3><hr>

                    <table class="table" id="tablethree">
                        <thead>
                                <tr>
                                    <th class="text-center">ORDER ID</th>
                                    <th class="text-center">ORDER DATE</th>
                                    <th class="text-center">DISCRIPTION</th>
                                    <th class="text-center">AMOUNT</th>
                                    <th class="text-center">UTR NUMBER</th>
                                    <th class="text-center">ORDER DETAILS</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $completedOnlineOrderlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($row->order_number_new); ?></td>
                                    <td class="text-center"><?php echo e($row->created_at); ?></td>
                                    <td class="text-center">SALE</td>
                                    <td class="text-center">₹ <?php echo e($row->cost); ?></td>
                                    <td class="text-center">123456789</td>
                                    <td class="text-center"><a href="<?php echo e(url('admin/todaypayment/view')); ?>/<?php echo e($row->id); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                            </tbody>
                    </table>
                </div>
                    <!-- End completed online Orders List-->

               
                
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<script>
  $(document).ready(function() {
    $('#table').DataTable();
});

  $(document).ready(function() {
    $('#tableone').DataTable();
} );

  $(document).ready(function() {
    $('#tabletwo').DataTable();
} );

  $(document).ready(function() {
    $('#tablethree').DataTable();
} );

$(document).ready(function() {
        $('#showmenu').click(function() {
        $(".demo1").css("display", "block");
        $(".demo2").css("display", "none");
        $(".demo3").css("display", "none");
        $(".demo4").css("display", "none");
        $(".demo5").css("display", "none");
        $(".demo6").css("display", "none");
        $(".demo7").css("display", "none");
        $(".demo8").css("display", "none");
               
        });
      });
  
$(document).ready(function() {
        $('#showmenu2').click(function() {
        $(".demo1").css("display", "none");
        $(".demo2").css("display", "block");
        $(".demo3").css("display", "none");
        $(".demo4").css("display", "none");
        $(".demo5").css("display", "none");
        $(".demo6").css("display", "none");
        $(".demo7").css("display", "none");
        $(".demo8").css("display", "none");
        });
    });

$(document).ready(function() {
        $('#showmenu3').click(function() {
        $(".demo1").css("display", "none");
        $(".demo2").css("display", "none");
        $(".demo3").css("display", "block");
        $(".demo4").css("display", "none");
        $(".demo5").css("display", "none");
        $(".demo6").css("display", "none");
        $(".demo7").css("display", "none");
        $(".demo8").css("display", "none");
        });
    });

$(document).ready(function() {
        $('#showmenu4').click(function() {
        $(".demo1").css("display", "none");
        $(".demo2").css("display", "none");
        $(".demo3").css("display", "none");
        $(".demo4").css("display", "block");
        $(".demo5").css("display", "none");
        $(".demo6").css("display", "none");
        $(".demo7").css("display", "none");
        $(".demo8").css("display", "none");

        });
    });

$(document).ready(function() {
        $('#showmenu5').click(function() {
        $(".demo1").css("display", "none");
        $(".demo2").css("display", "none");
        $(".demo3").css("display", "none");
        $(".demo4").css("display", "none");
        $(".demo5").css("display", "block");
        $(".demo6").css("display", "none");
        $(".demo7").css("display", "none");
        $(".demo8").css("display", "none");
        });
    });

$(document).ready(function() {
        $('#showmenu6').click(function() {
        $(".demo1").css("display", "none");
        $(".demo2").css("display", "none");
        $(".demo3").css("display", "none");
        $(".demo4").css("display", "none");
        $(".demo5").css("display", "none");
        $(".demo6").css("display", "block");
        $(".demo7").css("display", "none");
        $(".demo8").css("display", "none");
        });
    });

$(document).ready(function() {
        $('#showmenu7').click(function() {
        $(".demo1").css("display", "none");
        $(".demo2").css("display", "none");
        $(".demo3").css("display", "none");
        $(".demo4").css("display", "none");
        $(".demo5").css("display", "none");
        $(".demo6").css("display", "none");
        $(".demo7").css("display", "block");
        $(".demo8").css("display", "none");
        });
    });

$(document).ready(function() {
        $('#showmenu8').click(function() {
        $(".demo1").css("display", "none");
        $(".demo2").css("display", "none");
        $(".demo3").css("display", "none");
        $(".demo4").css("display", "none");
        $(".demo5").css("display", "none");
        $(".demo6").css("display", "none");
        $(".demo7").css("display", "none");
        $(".demo8").css("display", "block");
        });
    });



 </script>
<?php echo $__env->make('admin.includes.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>