<!-- popup for show all Information -->

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-center" style="font-size: 25px; color: #1B1212;" id="exampleModalLabel">Technical Information</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row content" style="width: 102%">
                    <?php if($productdata->category[0] == 53): ?> 
                        <div class="col-md-6">
                            <table width="100" class="table" style="table-layout: fixed;" border='0'>
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Shape</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->shape ==''): ?> NA <?php else: ?> <?php echo e($productdata->shape); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Color</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="frameColor"><?php if($productdata->framecolor ==''): ?> NA <?php else: ?>  <?php echo e($productdata->framecolor); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Gender</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->gender ==''): ?> NA <?php else: ?> <?php echo e($productdata->gender); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Brand Name </td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->brandname ==''): ?> NA <?php else: ?>  <?php echo e($productdata->brandname); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Model No</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->modelno==''): ?> NA <?php else: ?>  <?php echo e($productdata->modelno); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Seller Name</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->sellername ==''): ?> NA <?php else: ?> <?php echo e($productdata->sellername); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Product Sku</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="productsku_info"><?php if($productdata->productsku ==''): ?> NA <?php else: ?>  <?php echo e($productdata->productsku); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Material</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->framematerial==''): ?> NA <?php else: ?> <?php echo e($productdata->framematerial); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Manufacturer</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->manufracturer==''): ?> NA <?php else: ?> <?php echo e($productdata->manufracturer); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Country Of Origin</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->countryoforigin==''): ?> NA <?php else: ?>  <?php echo e($productdata->countryoforigin); ?><?php endif; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
            
                        <div class="col-md-5">
                            <table width="100" class="table" border='0'> 
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Width</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->framewidth==''): ?> NA <?php else: ?>  <?php echo e($productdata->framewidth); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Height</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->height==''): ?> NA <?php else: ?> <?php echo e($productdata->height); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Temple Material</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->templematerial==''): ?> NA <?php else: ?> <?php echo e($productdata->templematerial); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Temple Color</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->templecolor==''): ?> NA <?php else: ?>  <?php echo e($productdata->templecolor); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Type</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->frametype==''): ?> NA <?php else: ?>  <?php echo e($productdata->frametype); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Dimensions </td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="frameDimension"><?php if($productdata->productdimension==''): ?> NA <?php else: ?>  <?php echo e($productdata->productdimension); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Warrenty Type</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->warrentytype==''): ?> NA <?php else: ?> <?php echo e($productdata->warrentytype); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Weight</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->weight==''): ?> NA <?php else: ?> <?php echo e($productdata->weight); ?><?php endif; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
        
                    <?php elseif($productdata->category[0] == 58): ?>
                        <div class="col-md-6">
                            <table width="100" class="table" style="table-layout: fixed;" border='0'>
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Brand Name </td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->brandname==''): ?> NA <?php else: ?> <?php echo e($productdata->brandname); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Product Sku</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="productsku_info"><?php if($productdata->productsku==''): ?> NA <?php else: ?>  <?php echo e($productdata->productsku); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Lens Material</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->lensmaterialtype==''): ?> NA <?php else: ?>  <?php echo e($productdata->lensmaterialtype); ?><?php endif; ?></td>
                                    </tr>
                                    <?php if($productdata->visioneffect != 'Single Vision'): ?>
                                        <tr style="border:none;">
                                            <td style="width: 40%; border:none;">Add Power</td>
                                            <td style="width: 5%; text-align: center;border:none;"> : </td>
                                            <td style="width: 54%;border:none;word-wrap: break-word;"><?php if($productdata->addpowerlens  ==''): ?> NA <?php else: ?>  <?php echo e(str_replace(',',', ', $productdata->addpowerlens)); ?><?php endif; ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Lens Color</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="lensColor"><?php if($productdata->color==''): ?> NA <?php else: ?> <?php echo e($productdata->color); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Lens index</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->lensindex==''): ?> NA <?php else: ?>  <?php echo e($productdata->lensindex); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Coating</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->coating==''): ?> NA <?php else: ?> <?php echo e(str_replace(',',', ', $productdata->coating)); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Lens Technology</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->lenstechnology==''): ?> NA <?php else: ?> <?php echo e($productdata->lenstechnology); ?><?php endif; ?></td>
                                    </tr>
                                    <?php if($productdata->category[0] == 58): ?>
                                        <tr style="border:none;">
                                            <td style="width: 40%; border:none;">Lens Dia</td>
                                            <td style="width: 5%; text-align: center;border:none;"> : </td>
                                            <td style="width: 54%;border:none;"><?php if($productdata->diameterlens ==''): ?> NA <?php else: ?>  <?php echo e(str_replace(',',', ', $productdata->diameterlens)); ?><?php endif; ?></td>
                                        </tr>
                                        <tr style="border:none;">
                                            <td style="width: 40%; border:none;">Sphere</td>
                                            <td style="width: 5%; text-align: center;border:none;"> : </td>
                                            <td style="width: 54%;border:none;word-wrap: break-word;" ><?php if($productdata->sphere  ==''): ?> NA <?php else: ?>  <?php echo e(str_replace(',',', ', $productdata->sphere)); ?><?php endif; ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table width="100" class="table" style="table-layout: fixed;"  border='0'>
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Focal Length</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->focallength==''): ?> NA <?php else: ?>  <?php echo e($productdata->focallength); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Manufacturer</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->manufracturer==''): ?> NA <?php else: ?>  <?php echo e($productdata->manufracturer); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Weight</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->weight==''): ?> NA <?php else: ?> <?php echo e($productdata->weight); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Country Of Origin</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->countryoforigin==''): ?> NA <?php else: ?>  <?php echo e($productdata->countryoforigin); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Gravity</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->gravity==''): ?> NA <?php else: ?>  <?php echo e($productdata->gravity); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Coating Color</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->coatingcolor==''): ?> NA <?php else: ?>  <?php echo e($productdata->coatingcolor); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Abbe Value</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->abbevalue==''): ?> NA <?php else: ?>  <?php echo e($productdata->abbevalue); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Lens Type</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->visioneffect==''): ?> NA <?php else: ?>  <?php echo e($productdata->visioneffect); ?><?php endif; ?></td>
                                    </tr>
                                <?php if($productdata->category[0] == 58): ?>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Axis</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;word-wrap: break-word;"><?php if($productdata->axisnlens  ==''): ?> NA <?php else: ?>  <?php echo e(str_replace(',',', ', $productdata->axisnlens)); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Cylinder</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;word-wrap: break-word;"><?php if($productdata->cylinderlens  ==''): ?> NA <?php else: ?>  <?php echo e(str_replace(',',', ', $productdata->cylinderlens)); ?><?php endif; ?></td>
                                    </tr>
                                <?php else: ?>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Add Power</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;word-wrap: break-word;"><?php if($productdata->addpower ==''): ?> NA <?php else: ?>  <?php echo e(str_replace(',',', ', $productdata->addpower)); ?><?php endif; ?></td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php elseif($productdata->category[0] == 63): ?> 
                        <div class="col-md-5">
                            <table width="100" class="table" style="table-layout: fixed;" border='0'>
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Shape</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->shape ==''): ?> NA <?php else: ?> <?php echo e($productdata->shape); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Color </td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="frameColor"><?php if($productdata->framecolor ==''): ?> NA <?php else: ?>  <?php echo e($productdata->framecolor); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Gender</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->gender ==''): ?> NA <?php else: ?> <?php echo e($productdata->gender); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Brand Name</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->brandname ==''): ?> NA <?php else: ?>  <?php echo e($productdata->brandname); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Model No</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->modelno ==''): ?> NA <?php else: ?>  <?php echo e($productdata->modelno); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Product Sku</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="productsku_info"><?php if($productdata->productsku ==''): ?> NA <?php else: ?>  <?php echo e($productdata->productsku); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Material</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->framematerial ==''): ?> NA <?php else: ?> <?php echo e($productdata->framematerial); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Seller Name</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->sellername ==''): ?> NA <?php else: ?>  <?php echo e($productdata->sellername); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Type</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->frametype ==''): ?> NA <?php else: ?> <?php echo e($productdata->frametype); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Manufacturer</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->manufracturer ==''): ?> NA <?php else: ?>  <?php echo e($productdata->manufracturer); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Warrenty Type</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->warrentytype ==''): ?> NA <?php else: ?> <?php echo e($productdata->warrentytype); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Dimension</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="frameDimension"><?php if($productdata->productdimension ==''): ?> NA <?php else: ?>  <?php echo e($productdata->productdimension); ?><?php endif; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
        
                        <div class="col-md-5">
                            <table width="100" class="table" border='0' style="table-layout: fixed;">
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Width</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->framewidth ==''): ?> NA <?php else: ?>  <?php echo e($productdata->framewidth); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Temple Material</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->templematerial==''): ?> NA <?php else: ?> <?php echo e($productdata->templematerial); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Temple Color</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->templecolor ==''): ?> NA <?php else: ?>  <?php echo e($productdata->templecolor); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Lens Material</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->lensmaterialtype ==''): ?> NA <?php else: ?>  <?php echo e($productdata->lensmaterialtype); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Lens Technology</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->lenstechnology ==''): ?> NA <?php else: ?>  <?php echo e($productdata->lenstechnology); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Weight</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->weight ==''): ?> NA <?php else: ?>  <?php echo e($productdata->weight); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Country Of Origin</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->countryoforigin ==''): ?> NA <?php else: ?>  <?php echo e($productdata->countryoforigin); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Height</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->height ==''): ?> NA <?php else: ?>  <?php echo e($productdata->height); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Lens Technology</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->lenstechnology ==''): ?> NA <?php else: ?>  <?php echo e($productdata->lenstechnology); ?><?php endif; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php elseif($productdata->category[0] == 72): ?> 
                        <div class="col-md-5">
                            <table width="100" class="table" border='0' style="table-layout: fixed;">
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Brand Name</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->brandname ==''): ?> NA <?php else: ?>  <?php echo e($productdata->brandname); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Product Sku</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="productsku_info"><?php if($productdata->productsku ==''): ?> NA <?php else: ?>  <?php echo e($productdata->productsku); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Model No</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->modelno ==''): ?> NA <?php else: ?>  <?php echo e($productdata->modelno); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Contact Lense Type</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->lenstype ==''): ?> NA <?php else: ?>  <?php echo e($productdata->lenstype); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Contact Lens Material</td>
                                        <td style="width: 3%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->contactlensmaterialtype==''): ?> NA <?php else: ?> <?php echo e($productdata->contactlensmaterialtype); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Diameter</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->diameter ==''): ?> NA <?php else: ?>  <?php echo e(str_replace(',',', ', $productdata->diameter)); ?><?php endif; ?></td>
                                    </tr>
                                    <?php if($productdata->powermin != ''): ?>
                                        <tr style="border:none;">
                                            <td style="width: 25%; border:none;">Sphere <?php echo "(" ?> <i class="fa fa-minus"> <?php echo ")" ?></i></td>
                                            <td style="width: 2%; text-align: center;border:none;"> : </td>
                                            <td style="width: 35%;border:none; word-wrap: break-word; overflow-wrap: break-word;"><?php echo e(str_replace(',',', ', $productdata->powermin)); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($productdata->powermax!=''): ?>
                                        <tr style="border:none;">
                                            <td style="width: 25%; border:none;">Sphere <?php echo "(" ?> <i class="fa fa-plus"> <?php echo ")" ?></i></td>
                                            <td style="width: 3%; text-align: center;border:none;"> : </td>
                                            <td style="width: 35%; border:none; word-wrap: break-word; overflow-wrap: break-word;"><?php echo e(str_replace(',',', ', $productdata->powermax)); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                        <tr style="border:none;">
                                            <td style="width: 40%; border:none;">Centerthikness</td>
                                            <td style="width: 5%; text-align: center;border:none;"> : </td>
                                            <td style="width: 54%;border:none;"><?php if($productdata->centerthiknessnew ==''): ?> NA <?php else: ?> <?php echo e($productdata->centerthiknessnew); ?><?php endif; ?></td>
                                        </tr>
                                    <?php if($productdata->cylindernew !=''): ?>
                                        <tr style="border:none;">
                                            <td style="width: 40%; border:none;">Cylinder</td>
                                            <td style="width: 3%; text-align: center;border:none;"> : </td>
                                            <td style="width: 54%;border:none; word-wrap: break-word; overflow-wrap: break-word;"><?php echo e(str_replace(',',', ', $productdata->cylindernew)); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                
                                    <?php if($productdata->axisnew !=''): ?>
                                        <tr style="border:none;">
                                            <td style="width: 40%; border:none;">Axis</td>
                                            <td style="width: 3%; text-align: center;border:none;"> : </td>
                                            <td style="width: 54%;border:none; word-wrap: break-word; overflow-wrap: break-word;"><?php echo e(str_replace(',',', ', $productdata->axisnew)); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                
                                    <?php if($productdata->addpower !=''): ?>
                                        <tr style="border:none;">
                                            <td style="width: 40%; border:none;">Add Power</td>
                                            <td style="width: 5%; text-align: center;border:none;"> : </td>
                                            <td style="width: 54%;border:none;"><?php echo e(str_replace(',',', ', $productdata->addpower)); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
        
                        <div class="col-md-5">
                            <table width="100" class="table" border='0' style="table-layout: fixed;">
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 35%; border:none;">Base Curve</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->basecurve ==''): ?> NA <?php else: ?> <?php echo e(str_replace(',',', ', $productdata->basecurve)); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 35%; border:none;">water content</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->watercontent ==''): ?> NA <?php else: ?>  <?php echo e($productdata->watercontent); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 35%; border:none;">Disposability</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->disposability ==''): ?> NA <?php else: ?>  <?php echo e($productdata->disposability); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 35%; border:none;">Usages Duration</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->usagesduration ==''): ?> NA <?php else: ?>  <?php echo e($productdata->usagesduration); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 35%; border:none;">Packaging</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->packaging ==''): ?> NA <?php else: ?> <?php echo e($productdata->packaging); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <input class="getColor" type="hidden" value="<?php echo e($productdata->lenscolor); ?>" disabled>
                                        <td style="width: 35%; border:none;">Contact Lens Color</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="contactLensColor"><?php if($productdata->lenscolor ==''): ?> NA <?php else: ?> <?php echo e($productdata->lenscolor); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 35%; border:none;">Manufacturer</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->manufracturer ==''): ?> NA <?php else: ?>  <?php echo e($productdata->manufracturer); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 35%; border:none;">Country Of Origin</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->countryoforigin ==''): ?> NA <?php else: ?> <?php echo e($productdata->countryoforigin); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 35%; border:none;">Product Weight</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php echo e($productdata->weight); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php elseif($productdata->category[0] == 87): ?>
                        <div class="col-md-5">
                            <table width="100" class="table" border='0' style="table-layout: fixed;">
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Brand Name</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->brandname ==''): ?> NA <?php else: ?>  <?php echo e($productdata->brandname); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Product Sku</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="productsku_info"><?php if($productdata->productsku ==''): ?> NA <?php else: ?>  <?php echo e($productdata->productsku); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Net Quantity</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->netquntity ==''): ?> NA <?php else: ?>  <?php echo e($productdata->netquntity); ?><?php endif; ?></td>
                                    </tr>
                                        <!--<table width="100" class="table" border='0'>-->
                                        <!--<tbody>-->
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Shelf Life</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->shelflife ==''): ?> NA <?php else: ?>  <?php echo e($productdata->shelflife); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Form</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->form ==''): ?> NA <?php else: ?>  <?php echo e($productdata->form); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Product Color</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="productColor"><?php if($productdata->productcolor ==''): ?> NA <?php else: ?>  <?php echo e($productdata->productcolor); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Weight</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->weight==''): ?> NA <?php else: ?>  <?php echo e($productdata->weight); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Country Of Origin</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->countryoforigin ==''): ?> NA <?php else: ?>  <?php echo e($productdata->countryoforigin); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Seller Name</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->sellername ==''): ?> NA <?php else: ?>  <?php echo e($productdata->sellername); ?><?php endif; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
            
                        <div class="col-md-5">
                            <table width="100" class="table" border='0' style="table-layout: fixed;">
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Dimension</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->productdimension ==''): ?> NA <?php else: ?>  <?php echo e($productdata->productdimension); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Material</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->material ==''): ?> NA <?php else: ?>  <?php echo e($productdata->material); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Manufacturer</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->manufracturer ==''): ?> NA <?php else: ?>  <?php echo e($productdata->manufracturer); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Warrenty Type</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->warrentytype ==''): ?> NA <?php else: ?>  <?php echo e($productdata->warrentytype); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Packtype</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->packtype ==''): ?> NA <?php else: ?>  <?php echo e($productdata->packtype); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Usages</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->usages ==''): ?> NA <?php else: ?>  <?php echo e($productdata->usages); ?><?php endif; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php elseif($productdata->category[0] == 82): ?>
                        <div class="col-md-5">
                            <table width="100" class="table" border='0' style="table-layout: fixed;">
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Shape</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->shape ==''): ?> NA <?php else: ?>  <?php echo e($productdata->shape); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Color </td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="frameColor"><?php if($productdata->framecolor ==''): ?> NA <?php else: ?> <?php echo e($productdata->framecolor); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Gender</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->gender ==''): ?> NA <?php else: ?>  <?php echo e($productdata->gender); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Brand Name</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->brandname ==''): ?> NA <?php else: ?> <?php echo e($productdata->brandname); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Model No</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->modelno ==''): ?> NA <?php else: ?> <?php echo e($productdata->modelno); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Product Sku</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="productsku_info"><?php if($productdata->productsku ==''): ?> NA <?php else: ?>  <?php echo e($productdata->productsku); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Material</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->framematerial ==''): ?> NA <?php else: ?> <?php echo e($productdata->framematerial); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Dimension</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="frameDimension"><?php if($productdata->productdimension ==''): ?> NA <?php else: ?>  <?php echo e($productdata->productdimension); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Weight</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->weight ==''): ?> NA <?php else: ?>  <?php echo e($productdata->weight); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Country Of Origin</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->countryoforigin==''): ?> NA <?php else: ?>  <?php echo e($productdata->countryoforigin); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Warrenty Type</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->warrentytype ==''): ?> NA <?php else: ?>  <?php echo e($productdata->warrentytype); ?><?php endif; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
        
                        <div class="col-md-5">
                            <table width="100" class="table" border='0' style="table-layout: fixed;">
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Width</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->framewidth ==''): ?> NA <?php else: ?>  <?php echo e($productdata->framewidth); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Height</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->height ==''): ?> NA <?php else: ?>  <?php echo e($productdata->height); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Temple Material</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->templematerial ==''): ?> NA <?php else: ?> <?php echo e($productdata->templematerial); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Temple Color</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->templecolor==''): ?> NA <?php else: ?>  <?php echo e($productdata->templecolor); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Lens Material</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->lensmaterialtype ==''): ?> NA <?php else: ?> <?php echo e($productdata->lensmaterialtype); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Lens Color</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->color ==''): ?> NA <?php else: ?> <?php echo e($productdata->color); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Conditions </td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->conditionsnew ==''): ?> NA <?php else: ?>  <?php echo e($productdata->conditionsnew); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Lens Technology</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->lenstechnology ==''): ?> NA <?php else: ?> <?php echo e($productdata->lenstechnology); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Manufacturer</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->manufracturer ==''): ?> NA <?php else: ?>  <?php echo e($productdata->manufracturer); ?><?php endif; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php elseif($productdata->category[0] == 445): ?>
                        <div class="col-md-5">
                            <table width="100" class="table" border='0' style="table-layout: fixed;">
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Brand Name</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->brandname ==''): ?> NA <?php else: ?>  <?php echo e($productdata->brandname); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Product Sku</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="productsku_info"><?php if($productdata->productsku ==''): ?> NA <?php else: ?>  <?php echo e($productdata->productsku); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Net Quantity</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->netquntity ==''): ?> NA <?php else: ?>  <?php echo e($productdata->netquntity); ?><?php endif; ?></td>
                                    </tr>
                                        <!--<table width="100" class="table" border='0'>-->
                                        <!--<tbody>-->
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Shelf Life</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->shelflife ==''): ?> NA <?php else: ?>  <?php echo e($productdata->shelflife); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Form</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->form ==''): ?> NA <?php else: ?>  <?php echo e($productdata->form); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Product Color</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;" class="productColor"><?php if($productdata->productcolor ==''): ?> NA <?php else: ?>  <?php echo e($productdata->productcolor); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Weight</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->weight==''): ?> NA <?php else: ?>  <?php echo e($productdata->weight); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Country Of Origin</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->countryoforigin ==''): ?> NA <?php else: ?>  <?php echo e($productdata->countryoforigin); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Seller Name</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->sellername ==''): ?> NA <?php else: ?>  <?php echo e($productdata->sellername); ?><?php endif; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
            
                        <div class="col-md-5">
                            <table width="100" class="table" border='0' style="table-layout: fixed;">
                                <tbody>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Frame Dimension</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->productdimension ==''): ?> NA <?php else: ?>  <?php echo e($productdata->productdimension); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Material</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->material ==''): ?> NA <?php else: ?>  <?php echo e($productdata->material); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Manufacturer</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->manufracturer ==''): ?> NA <?php else: ?>  <?php echo e($productdata->manufracturer); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Warrenty Type</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->warrentytype ==''): ?> NA <?php else: ?>  <?php echo e($productdata->warrentytype); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Packtype</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->packtype ==''): ?> NA <?php else: ?>  <?php echo e($productdata->packtype); ?><?php endif; ?></td>
                                    </tr>
                                    <tr style="border:none;">
                                        <td style="width: 40%; border:none;">Usages</td>
                                        <td style="width: 5%; text-align: center;border:none;"> : </td>
                                        <td style="width: 54%;border:none;"><?php if($productdata->usages ==''): ?> NA <?php else: ?>  <?php echo e($productdata->usages); ?><?php endif; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>