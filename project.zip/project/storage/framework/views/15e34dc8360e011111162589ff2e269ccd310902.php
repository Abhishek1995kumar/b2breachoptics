
<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="text-center">
		<h1 class="text-center">Authentication required</h1>
		<small>We’ve sent a One Time Password (OTP) to the registered mobile number. Please enter it to complete verification</small>
		<form class="form-inline" action="<?php echo e(route('checkOTP')); ?>" method="post">
			<?php echo e(csrf_field()); ?>

				<div class="form-group">
					  <label class="mr-sm-2">Enter Otp:</label>
				  <input type="number" name="otp" class="form-control mb-2 mr-sm-2" placeholder="Enter Otp">
				</div>
				
				<div class="form-group">
					 <button type="submit" class="btn btn-primary mb-2">Submit</button>
				</div>
			 
		</form>
	</div>
	
</div>
<br>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.newmaster', ['normalHeader' => true], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>