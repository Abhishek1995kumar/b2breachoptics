   




<?php $__env->startSection('content'); ?>
    
<style type="text/css">
    #fade {
  display: none;
  position: fixed;
  top: 0%;
  left: 0%;
  width: 100%;
  height: 100%;
  background-color: black;
  z-index: 1001;
  -moz-opacity: 0.8;
  opacity: .80;
  filter: alpha(opacity=80);
}

#light {
  display: none;
  position: absolute;
  top: 30%;
  left: 100%;
  max-width: 800px;
  max-height: 560px;
  margin-left: 300px;
  margin-top: -180px;
  border: 2px solid #FFF;
  background: #FFF;
  z-index: 1002;
  overflow: visible;
}

#boxclose {
  float: right;
  cursor: pointer;
  color: #fff;
  border: 1px solid #AEAEAE;
  border-radius: 3px;
  background: #222222;
  font-size: 31px;
  font-weight: bold;
  display: inline-block;
  line-height: 0px;
  padding: 11px 3px;
  position: absolute;
  right: 2px;
  top: 2px;
  z-index: 1002;
  opacity: 0.9;
}

.boxclose:before {
  content: "×";
}

#fade:hover ~ #boxclose {
  display:none;
}

.test:hover ~ .test2 {
  display: none;
}

/*video 2*/
#fade1 {
  display: none;
  position: fixed;
  top: 0%;
  left: 0%;
  width: 100%;
  height: 100%;
  background-color: black;
  z-index: 1001;
  -moz-opacity: 0.8;
  opacity: .80;
  filter: alpha(opacity=80);
}

#light1 {
  display: none;
  position: absolute;
  top: 30%;
  left: 100%;
  max-width: 800px;
  max-height: 560px;
  margin-left: 300px;
  margin-top: -180px;
  border: 2px solid #FFF;
  background: #FFF;
  z-index: 1002;
  overflow: visible;
}

#boxclose1 {
  float: right;
  cursor: pointer;
  color: #fff;
  border: 1px solid #AEAEAE;
  border-radius: 3px;
  background: #222222;
  font-size: 31px;
  font-weight: bold;
  display: inline-block;
  line-height: 0px;
  padding: 11px 3px;
  position: absolute;
  right: 2px;
  top: 2px;
  z-index: 1002;
  opacity: 0.9;
}

.boxclose1:before {
  content: "×";
}

#fade1:hover ~ #boxclose1 {
  display:none;
}
/*end video 2*/


/*video 3*/
#fade2 {
  display: none;
  position: fixed;
  top: 0%;
  left: 0%;
  width: 100%;
  height: 100%;
  background-color: black;
  z-index: 1001;
  -moz-opacity: 0.8;
  opacity: .80;
  filter: alpha(opacity=80);
}

#light2 {
  display: none;
  position: absolute;
  top: 30%;
  left: 100%;
  max-width: 800px;
  max-height: 560px;
  margin-left: 300px;
  margin-top: -180px;
  border: 2px solid #FFF;
  background: #FFF;
  z-index: 1002;
  overflow: visible;
}

#boxclose2 {
  float: right;
  cursor: pointer;
  color: #fff;
  border: 1px solid #AEAEAE;
  border-radius: 3px;
  background: #222222;
  font-size: 31px;
  font-weight: bold;
  display: inline-block;
  line-height: 0px;
  padding: 11px 3px;
  position: absolute;
  right: 2px;
  top: 2px;
  z-index: 1002;
  opacity: 0.9;
}

.boxclose2:before {
  content: "×";
}

#fade2:hover ~ #boxclose2 {
  display:none;
}
/*end video 3*/


/*media query for mobile responsive*/

#imagepad{
  padding-left: 106px;
}

@media  screen and (max-width: 992px)  {


    .single-product-carousel-item {
        text-align: center;
        vertical-align: middle;
        display: table-cell;
        padding-right: 80px;
    }


    .section-padding.product-carousel-wrapper .owl-carousel .owl-controls .owl-nav .owl-prev, .section-padding.blog-area-wrapper .owl-carousel .owl-controls .owl-nav .owl-prev, .section-padding.logo-carousel-wrapper .owl-carousel .owl-controls .owl-nav .owl-prev {
    left: 10px;
    /* bottom: -50px; */
    top: 150px;
}



.section-padding.product-carousel-wrapper .owl-carousel .owl-controls .owl-nav .owl-next, .section-padding.blog-area-wrapper .owl-carousel .owl-controls .owl-nav .owl-next, .section-padding.logo-carousel-wrapper .owl-carousel .owl-controls .owl-nav .owl-next {
    right: 10px;
    top: 150px;
}

.product-carousel-wrapper{

      padding-top: 240px;

}

.section-title h2 {
    padding-left: 14px;
    font-size: 18px;
}

.product-meta-area{
    padding-left: 111px;
}

#tendingpad{

  padding: 0px;
}

#selectedpad{

  padding:0px;
} 


.single-product-item img {
    padding: 1px 1px;
    width: 30%;
    border: 1px solid #888888;
    margin: auto;
    display: inline-block;
    
}

.tab-div-shubh {
    float: right;
    padding-right: 0px;
    padding-left: 0px;
    margin-left: -140px;
    text-align: center;
    position: relative;
    z-index: 1;
}

.image_div_shubh {
    
    text-align: center;
    vertical-align: middle;
    margin-left: 80px;
    margin-top: -263px;

}

.image_div_shubh img {
    width: 76%;
    position: relative;
    z-index: 5;
}


.tab-content {
    height: 500px;
    width: 100%;
    padding: 5px 0px;
    position: relative;
    z-index: 1;
  }
  
}




/*end of media query for mobile responsive*/
  
   .itemsContainer {
    /*background:red;*/ 
    float:left;
    position:relative
}
/*.itemsContainer:hover .play{display:block}*/
.play{
  position : absolute;
    display:block;
    top:15%; 
    width:40px;
    margin:0 auto; left:0px;
    right:0px;
    z-index:100
}   

</style>

    <div class="home-wrapper">
        <div class="container-fluid">

          <nav class="navbar navbar-default">
            <div class="container-fluid">
              <div class="navbar-header" style="padding-top: 15px;">
                <a href="<?php echo e(url('/home')); ?>" ><?php echo e($language->home); ?></a><?php echo e("/"); ?>

                <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[0])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[0])->first()->name); ?></a><?php echo e("/"); ?>

                <?php if($productdata->category[1] != ""): ?>
                    <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[1])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[1])->first()->name); ?></a><?php echo e("/"); ?>

                <?php endif; ?>
                <?php if($productdata->category[2] != ""): ?>
                    <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[2])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[2])->first()->name); ?></a><?php echo e("/"); ?>

                <?php endif; ?>
                <a style ="color : black;" href="<?php echo e(url('/product')); ?>/<?php echo e($productdata->id); ?>/<?php echo e(str_replace(' ','-',strtolower($productdata->title))); ?>"><?php echo e($productdata->title); ?></a>
              </div>
              <ul class="nav navbar-nav" style="float:right; padding-right:30px"  >
                <li class="active"><a data-toggle="tab" href="#overview-tab-1"><?php echo "Product";?></a></li>
                <li><a data-toggle="tab" href="#overview-tab-2"><?php echo e($language->description); ?></a></li>
                <li><a data-toggle="tab" href="#pricing-tab-3"><?php echo e($language->return_policy); ?></a></li>
                <li><a data-toggle="tab" href="#location-tab-4"><?php echo e($language->reviews); ?>(<?php echo e(\App\Review::where('productid',$productdata->id)->count()); ?>)</a></li>
              </ul>
            </div>
          </nav>



        <!-- <div class="product-top-container-shubh"  style="border-radius: 10px;">
            <div class="breadcrumb-box">
                <a href="<?php echo e(url('/home')); ?>"><?php echo e($language->home); ?></a>
                <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[0])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[0])->first()->name); ?></a>
                <?php if($productdata->category[1] != ""): ?>
                    <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[1])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[1])->first()->name); ?></a>
                <?php endif; ?>
                <?php if($productdata->category[2] != ""): ?>
                    <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[2])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[2])->first()->name); ?></a>
                <?php endif; ?>
                <a style ="color : black;" href="<?php echo e(url('/product')); ?>/<?php echo e($productdata->id); ?>/<?php echo e(str_replace(' ','-',strtolower($productdata->title))); ?>"><?php echo e($productdata->title); ?></a>
            
            
            <div class="tab-div-shubh" style="height : 100%">
                    <ul>
                        <li class="active"><a data-toggle="tab" href="#overview-tab-1"><?php echo "Product";?></a></li>
                        <li><a data-toggle="tab" href="#overview-tab-2"><?php echo e($language->description); ?></a></li>
                        <li><a data-toggle="tab" href="#pricing-tab-3"><?php echo e($language->return_policy); ?></a></li>
                        <li><a data-toggle="tab" href="#location-tab-4"><?php echo e($language->reviews); ?>(<?php echo e(\App\Review::where('productid',$productdata->id)->count()); ?>)</a></li>
                    </ul>
            </div>
            </div>
            
        </div> -->
        </div>
        <div class="product-details-wrapper padding-bottom-0 wow fadeInUp" style="padding-top:20px;">
            <div class="container-fluid">
                <div class="col-sm-1 padding-right-0">
                    <div class="project-image-shubh">
                        <div class="single-product-item">
                            <img id="iconOne" onmouseover="productGallery(this.id)" src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->feature_image); ?>" alt="">
                        </div>
                        <?php $__empty_1 = true; $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galdta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="single-product-item">
                            <img id="galleryimg<?php echo e($galdta->id); ?>" onmouseover="productGallery(this.id)" src="<?php echo e(url('/assets/images/gallery')); ?>/<?php echo e($galdta->image); ?>" alt="">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </div>
                    <!-- video1 -->
                    <div id="light">
                      <a class="boxclose" id="boxclose" onclick="lightbox_close();"></a>
                      <video id="VisaChipCardVideo" width="700" controls>
                          <source src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->video); ?>" type="video/mp4">
                        </video>
                    </div>

                    <div id="fade" onClick="lightbox_close();"></div>

                      <div class="itemsContainer">
                          <div class="image">  <img width="72" height="100" src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->feature_image); ?>" /></div>
                          <div class="play"><a onclick="lightbox_open();"> <img src="<?php echo e(url('/assets/img/playicon2.png')); ?>" />  </a></div>
                      </div>


                    <!-- <div class="video_thumb">
                      <a  onclick="lightbox_open();">
                        <img width="75" height="75" src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->feature_image); ?>" alt="">
                        <i class="fa fa-play-circle-o"  style="font-size:24px;color:black"></i></a>
                    </div> -->
                    <!-- endvideo1 -->

                    <!-- video2 -->
                    <div id="light1">
                      <a class="boxclose1" id="boxclose1" onclick="lightbox_close1();"></a>
                      <video id="VisaChipCardVideo1" width="600" controls>
                          <source src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->video1); ?>" type="video/mp4">
                          <!--Browser does not support <video> tag -->
                        </video>
                    </div>

                    <div id="fade1" onClick="lightbox_close1();"></div>
                  <?php if($productdata->video2 != ''): ?>

                  <div class="itemsContainer">
                          <div class="image">  <img width="72" height="100" src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->feature_image); ?>" /></div>
                          <div class="play"><a onclick="lightbox_open1();"> <img src="<?php echo e(url('/assets/img/playicon2.png')); ?>" />  </a></div>
                  </div>

                    <!-- <div>
                      <a href="#" onclick="lightbox_open1();"><i class="fa fa-play-circle-o" style="font-size:78px;color:black"></i></a>
                    </div> -->
                  <?php endif; ?>
                    <!-- endvideo 2 -->

                    <!-- video3 -->
                      <div id="light2">
                        <a class="boxclose2" id="boxclose1" onclick="lightbox_close2();"></a>
                        <video id="VisaChipCardVideo2" width="600" controls>
                            <source src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->video2); ?>" type="video/mp4">
                            <!--Browser does not support <video> tag -->
                          </video>
                      </div>

                      <div id="fade2" onClick="lightbox_close2();"></div>
                      <?php if($productdata->video2 != ''): ?>

                      <div class="itemsContainer">
                          <div class="image">  <img width="72" height="100" src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->feature_image); ?>" /></div>
                          <div class="play"><a onclick="lightbox_open2();"> <img src="<?php echo e(url('/assets/img/playicon2.png')); ?>" />  </a></div>
                      </div>

                        <!-- <div>
                          <a href="#" onclick="lightbox_open2();"><i class="fa fa-play-circle-o" style="font-size:78px;color:black"></i></a>
                        </div> -->
                      <?php endif; ?>
                    <!-- endvideo3 -->

                    <!-- <video width="72px" height="72px"  src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->video); ?>" controls></video> -->

                </div>
                <div class="col-md-11 padding-right-0 padding-left-0">
                <div class="product-projects-FullDiv-area">
                    <!--<div class="breadcrumb-box">-->
                    <!--    <a href="<?php echo e(url('/')); ?>"><?php echo e($language->home); ?></a>-->
                    <!--    <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[0])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[0])->first()->name); ?></a>-->
                    <!--    <?php if($productdata->category[1] != ""): ?>-->
                    <!--        <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[1])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[1])->first()->name); ?></a>-->
                    <!--    <?php endif; ?>-->
                    <!--    <?php if($productdata->category[2] != ""): ?>-->
                    <!--        <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[2])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[2])->first()->name); ?></a>-->
                    <!--    <?php endif; ?>-->
                    <!--    <a href="<?php echo e(url('/product')); ?>/<?php echo e($productdata->id); ?>/<?php echo e(str_replace(' ','-',strtolower($productdata->title))); ?>"><?php echo e($productdata->title); ?></a>-->
                    <!--</div>-->

                    <div class="row">
                        <div class="col-md-5 col-sm-5 col-xs-12 padding-right-0 padding-left-0 ">
                            <div class="image_div_shubh">
                                <div class="product-review-carousel-img product-zoom">
                                    <img id="imageDiv" src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->feature_image); ?>" alt="">
                                </div>
                                <!--<img id="imageDiv" src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->feature_image); ?>" alt="">-->
                                <!-- <video width="250" style="margin-right: 20px;"  src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->video); ?>" controls></video> -->

                            </div>

                            <!--<div class="product-review-owl-carousel">-->
                            <!--    <div class="single-product-item">-->
                            <!--        <img id="iconOne" onclick="productGallery(this.id)" src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->feature_image); ?>" alt="">-->
                            <!--    </div>-->
                            <!--    <?php $__empty_1 = true; $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galdta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>-->
                            <!--        <div class="single-product-item">-->
                            <!--            <img id="galleryimg<?php echo e($galdta->id); ?>" onclick="productGallery(this.id)" src="<?php echo e(url('/assets/images/gallery')); ?>/<?php echo e($galdta->image); ?>" alt="">-->
                            <!--        </div>-->
                            <!--    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>-->
                            <!--    <?php endif; ?>-->
                            <!--</div>-->
                        </div>
                        <div class="col-md-7 col-sm-7 col-xs-12 padding-right-0">

                            <div class="tab-content">

                                        <div id="overview-tab-1" class="tab-pane active fade in">


                                            <div class="col-md-5 padding-right-0 padding-left-0">

                                            <!--<p><?php echo $productdata->description; ?></p>-->
                                            <h2 class="product-header"><?php echo e($productdata->title); ?></h2>

                                       
                                            <?php if($productdata->owner != "admin"): ?>
                                                <?php if(\App\Vendors::where('id',$productdata->vendorid)->count() != 0): ?>
                                                    <strong class=""><?php echo e($language->vendor); ?>: <a href="<?php echo e(url('/shop')); ?>/<?php echo e($productdata->vendorid); ?>/<?php echo e(str_replace(' ','-',strtolower(\App\Vendors::findOrFail($productdata->vendorid)->shop_name))); ?>" target="_blank"><?php echo e(\App\Vendors::findOrFail($productdata->vendorid)->shop_name); ?></a></strong>
                                                <?php endif; ?>
                                            <?php else: ?>
                                            <?php endif; ?>
                                            <p class="product-status padding-top-10">
                                            <?php if($productdata->stock != 0 || $productdata->stock === null ): ?>
                                                <span class="available">
                                                    <i class="fa fa-check-square-o"></i>
                                                    <span><?php echo e($language->available); ?></span>
                                                </span>
                                            <?php else: ?>
                                                <span class="not-available">
                                                <i class="fa fa-times-circle-o"></i>
                                                <span><?php echo e($language->out_of_stock); ?></span>
                                                <input name="btn" type="submit" class="btn-notify" value="Notify Me">
                                                <!--<button type="" >Notify Me</button>-->
                                                </span>
                                            <?php endif; ?>
                
                                            </p>
                                            <div id="rating_review">
                                                <div class="ratings">
                                                    <div class="empty-stars"></div>
                                                    <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($productdata->id)); ?>%"></div>
                                                </div>
                                                <?php if(\App\Review::reviewCount($productdata->id) > 1): ?>
                                                    <span><?php echo e(\App\Review::reviewCount($productdata->id)); ?> Reviews</span>
                                                <?php else: ?>
                                                    <span><?php echo e(\App\Review::reviewCount($productdata->id)); ?> Review</span>
                                                <?php endif; ?>
                                            </div>
                                            <!--<p class="product-description">-->
                                            <!--    <?php echo e(substr(strip_tags($productdata->description), 0, 600)); ?>...-->
                                            <!--    <a href="">show more</a>-->
                                            <!--</p>-->
                                            <h1 class="product-price">
                                                <?php if($productdata->previous_price != ""): ?>
                                                    <span>
                                                     <span style="font-size: 20px;"><b> MRP :</b> </span><del style="font-size: 15px;"><?php echo e($settings[0]->currency_sign); ?><?php echo e($productdata->previous_price); ?></del>
                                                    </span>
                                                <?php endif; ?>
                                                  <span style="font-size: 25px">
                                                    <b><?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Product::Cost($productdata->id)); ?></b>
                                                  </span> 
                                            </h1>
                
                                            <?php if($productdata->sizes != null): ?>
                                                <div class="product-size" id="product-size">
                                                <p>Size</p>
                                                    <?php $__currentLoopData = explode(',',$productdata->sizes); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span><?php echo e($size); ?></span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            <?php endif; ?>
                                           <!--  <h5>Color</h5><p class="product-size"><?php echo e($productdata->color); ?></p>
                                            <h5>Shape</h5><p class="product-size"><?php echo e($productdata->shape); ?></p> -->
                                            <div class="row">
                                              <h5>Technical Information</h5>
                                              <ul>
                                              <?php if($productdata->category[0] == 53): ?>
                                                <li>Product Id <span style="padding-left: 22%;"><?php echo e($productdata->productsku); ?></span></li>
                                                <li>Model No. <span style="padding-left: 23%;"><?php echo e($productdata->modelno); ?></span></li>
                                                <li>Frame Width <span style="padding-left: 17%;"><?php echo e($productdata->framewidth); ?></span></li>
                                                <li>Frame Dimensions <span style="padding-left: 6%;"><?php echo e($productdata->productdimension); ?></span></li>
                                                <li>Frame Color <span style="padding-left: 19%;"><?php echo e($productdata->color); ?></span></li><br>
                                                <a style="color: #1B1212; font-weight: 500px " data-toggle="modal" data-target="#exampleModal"><b>Show All Inforamation</b></a>
                                              <?php elseif($productdata->category[0] == 72): ?>
                                                <li>Brand Name <span style="padding-left: 18%;"><?php echo e($productdata->brandname); ?></span></li>
                                                <li>Model No. <span style="padding-left: 23%;"><?php echo e($productdata->modelno); ?></span></li>
                                                <li>Product Sku <span style="padding-left: 19%;"><?php echo e($productdata->productsku); ?></span></li>
                                                <li>Usages Duration <span style="padding-left: 12%;"><?php echo e($productdata->usagesduration); ?></span></li>
                                                <li>Diameter <span style="padding-left: 24%;"><?php echo e($productdata->diameter); ?></span></li><br>
                                                <a style="color: #1B1212; font-weight: 500px " data-toggle="modal" data-target="#exampleModal"><b>Show All Inforamation</b></a>
                                              <?php elseif($productdata->category[0] == 63): ?>
                                                <li>Frame Shape <span style="padding-left: 25%;"><?php echo e($productdata->shape); ?></span></li>
                                                <li>Frame Color <span style="padding-left: 27%;"><?php echo e($productdata->color); ?></span></li>
                                                <li>Gender<span style="padding-left: 35%;"><?php echo e($productdata->gender); ?></span></li>
                                                <li>Brand Name<span style="padding-left: 27%;"><?php echo e($productdata->brandname); ?></span></li>
                                                <li>Model No<span style="padding-left: 33%;"><?php echo e($productdata->modelno); ?></span></li><br>
                                                <a style="color: #1B1212; font-weight: 500px " data-toggle="modal" data-target="#exampleModal"><b>Show All Inforamation</b></a>
                                              <?php elseif($productdata->category[0] == 87): ?>
                                                <li>Brand Name <span style="padding-left: 25%;"><?php echo e($productdata->brandname); ?></span></li>
                                                <li>Product Sku <span style="padding-left: 26%;"><?php echo e($productdata->productsku); ?></span></li>
                                                <li> Net Quantity <span style="padding-left: 25%;"><?php echo e($productdata->netquntity); ?></span></li>
                                                <li>Shelf Life <span style="padding-left: 32%;"><?php echo e($productdata->shelflife); ?></span></li>
                                                <li>Form <span style="padding-left: 38%;"><?php echo e($productdata->form); ?></span></li><br>
                                                <a style="color: #1B1212; font-weight: 500px " data-toggle="modal" data-target="#exampleModal"><b>Show All Inforamation</b></a>
                                              <?php elseif($productdata->category[0] == 58): ?>
                                                <li>Brand Name <span style="padding-left: 24%;"><?php echo e($productdata->brandname); ?></span></li>
                                                <li>Product Sku<span style="padding-left: 26%;"><?php echo e($productdata->productsku); ?></span></li>
                                                <li>Lens Material<span style="padding-left: 25%;"><?php echo e($productdata->lensmaterialtype); ?></span></li>
                                                <li>Diameter<span style="padding-left: 31%;"><?php echo e($productdata->diameter); ?></span></li>
                                                <li>Lens Color<span style="padding-left: 30%;"><?php echo e($productdata->lenscolor); ?></span></li><br>
                                                <a style="color: #1B1212; font-weight: 500px " data-toggle="modal" data-target="#exampleModal"><b>Show All Inforamation</b></a>
                                              <?php else: ?>
                                                <li>Frame Shape<span style="padding-left: 24%;"><?php echo e($productdata->shape); ?></span></li>
                                                <li>Frame Color<span style="padding-left: 26%;"><?php echo e($productdata->color); ?></span></li>
                                                <li>Brand Name<span style="padding-left: 25%;"><?php echo e($productdata->brandname); ?></span></li>
                                                <li>Model No<span style="padding-left: 30%;"><?php echo e($productdata->modelno); ?></span></li>
                                                <li>Product Sku<span style="padding-left: 26%;"><?php echo e($productdata->productsku); ?></span></li><br>
                                                <a style="color: #1B1212; font-weight: 500px " data-toggle="modal" data-target="#exampleModal"><b>Show All Inforamation</b></a>

                                              <?php endif; ?>
                                              </ul>
                                                <!-- <table class="table table-bordered">
                                                      <tr>
                                                        <th class="text-center" style="padding: 20px;">Color</th>
                                                        <th class="text-center" style="padding: 20px;">Shape</th>
                                                      </tr>
                                                      <tr>
                                                        <td  class="text-center"><?php echo e($productdata->color); ?></td>
                                                        <td  class="text-center"><?php echo e($productdata->shape); ?></td>
                                                      </tr>
                                                    </table>   -->
                                            </div>
                                            <br>
                                            <div class="row">
                                                <table class="table table-bordered">
                                                      <tr>
                                                        <?php if($productdata->ranegnameone != ''): ?>
                                                        <th class="text-center"><?php echo e($productdata->ranegnameone); ?></th>
                                                        <?php endif; ?>
                                                        <?php if($productdata->rangenametwo != ''): ?>
                                                        <th class="text-center"><?php echo e($productdata->rangenametwo); ?></th>
                                                        <?php endif; ?>
                                                        <?php if($productdata->rangenamethree != ''): ?>
                                                        <th class="text-center"><?php echo e($productdata->rangenamethree); ?></th>
                                                        <?php endif; ?>
                                                      </tr>
                                                      <tr>
                                                        <!-- <input type="hidden" value="<?php echo e($productdata->p40pieces); ?>" id="getValue1">
                                                        <input type="hidden" value="<?php echo e($productdata->p51pieces); ?>" id="getValue2">
                                                        <input type="hidden" value="<?php echo e($productdata->p5000pieces); ?>" id="getValue3"> -->
                                                      <?php if($productdata->p40pieces != ''): ?>
                                                        <td  class="text-center"><?php echo e($settings[0]->currency_sign); ?> <?php echo e($productdata->p40pieces); ?> </td>
                                                      <?php endif; ?>
                                                      <?php if($productdata->p51pieces != ''): ?>
                                                        <td  class="text-center"><?php echo e($settings[0]->currency_sign); ?> <?php echo e($productdata->p51pieces); ?> </td>
                                                      <?php endif; ?>
                                                      <?php if($productdata->p5000pieces != ''): ?>
                                                        <td  class="text-center"><?php echo e($settings[0]->currency_sign); ?> <?php echo e($productdata->p5000pieces); ?> </td>
                                                      <?php endif; ?>
                                                      </tr>
                                                    </table>
                                                
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-5">
                                                    <!-- <span id="pqty">1</span> -->
                                                    <!-- <div class="product-quantity">
                                                        <p><?php echo e($language->quantity); ?></p>
                                                        <span class="quantity-btn" id="qty-minus"><i class="fa fa-minus"></i></span>
                                                        <input type="text" id="pqty" value="1" style="width: 43px; height: 40px; margin-right: 0px;">
                                                        <span class="quantity-btn" id="qty-add"><i class="fa fa-plus"}}></i></span>
                                                    </div> -->

                                                    <div class="form-group">
                                                    <label>Quantity: </label>

                                                    <div class="input-group" style="margin-top: 17px;">
                                                    <div class="input-group-btn">
                                                    <button id="qty-minus" class="btn btn-default" ><span class="glyphicon glyphicon-minus"></span></button>
                                                    </div>
                                                    <input type="text" id="pqty" class="form-control input-number" value="1" />
                                                    <div class="input-group-btn">
                                                    <button id="qty-add" class="btn btn-default"><span class="glyphicon glyphicon-plus"></span></button>
                                                    </div>
                                                    </div>
                                                    </div>

                                                </div>

                                                <div class="col-sm-7">

                                                 <div class="product-meta-area" style="padding-top: 35px;">
                                                <form class="addtocart-form">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php if(Session::has('uniqueid')): ?>
                                                        <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                                    <?php else: ?>
                                                        <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                                    <?php endif; ?>
                                                    
                                                     <input type="hidden" id="price" name="price" value="<?php echo e(\App\Product::Cost($productdata->id)); ?>">
                                                     
                                                     <?php if($productdata->p40pieces != ''): ?>
                                                     <input type="hidden" id="price_1" name="price_1" value="<?php echo e(\App\Product::Costtwopis($productdata->id)); ?>">
                                                     <?php else: ?>
                                                     <input type="hidden" id="price_1" name="price_1" value="<?php echo e(\App\Product::Cost($productdata->id)); ?>">
                                                     <?php endif; ?>

                                                     <?php if($productdata->p51pieces != ''): ?>
                                                     <input type="hidden" id="price_2" name="price_2" value="<?php echo e(\App\Product::Costfiftypis($productdata->id)); ?>">
                                                     <?php else: ?>
                                                     <input type="hidden" id="price_2" name="price_2" value="<?php echo e(\App\Product::Cost($productdata->id)); ?>">
                                                     <?php endif; ?>


                                                     <?php if($productdata->p5000pieces != ''): ?>
                                                     <input type="hidden" id="price_3" name="price_3" value="<?php echo e(\App\Product::Costfivethousandpis($productdata->id)); ?>">
                                                     <?php else: ?>
                                                     <input type="hidden" id="price_3" name="price_3" value="<?php echo e(\App\Product::Cost($productdata->id)); ?>">
                                                     <?php endif; ?>

                                                    <input type="hidden" name="title" value="<?php echo e($productdata->title); ?>">
                                                    <input type="hidden" name="product" value="<?php echo e($productdata->id); ?>">
                                                    <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($productdata->id)); ?>">
                                                    <input type="hidden" id="quantity" name="quantity" value="1">
                                                    <input type="hidden" id="size" name="size" value="">

                                                    <?php if($productdata->stock != 0 || $productdata->stock === null ): ?>
                                                        <button type="button" class="addTo-cart to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>
                                                    <?php else: ?>
                                                        <button type="button" class="addTo-cart to-cart" disabled><i class="fa fa-cart-plus"></i><?php echo e($language->out_of_stock); ?></button>
                                                    <?php endif; ?>
                                                </form>
                                            </div>   
                                                    
                                                </div>
                                                
                                            </div>
                                            
                                            
                                    </div>
                                            
                                             <!-- <div class="col-md-6 col-xs-12">
                                                 <div style="height: 400px; width: 100%; border: 1px solid black; float: left;">
                                                     
                                                 </div>
                                             </div> -->
                                            <div class="col-md-0 padding-left-0">
                                            <!--<p><?php echo $productdata->description; ?></p>-->
                                            <!--<h2 class="product-header"><?php echo e($productdata->title); ?></h2>-->
                                            <!--<?php if($productdata->owner != "admin"): ?>-->
                                            <!--    <?php if(\App\Vendors::where('id',$productdata->vendorid)->count() != 0): ?>-->
                                            <!--        <strong class=""><?php echo e($language->vendor); ?>: <a href="<?php echo e(url('/shop')); ?>/<?php echo e($productdata->vendorid); ?>/<?php echo e(str_replace(' ','-',strtolower(\App\Vendors::findOrFail($productdata->vendorid)->shop_name))); ?>" target="_blank"><?php echo e(\App\Vendors::findOrFail($productdata->vendorid)->shop_name); ?></a></strong>-->
                                            <!--    <?php endif; ?>-->
                                            <!--<?php else: ?>-->
                                            <!--<?php endif; ?>-->
                                            <!--<p class="product-status">-->
                                            <!--<?php if($productdata->stock != 0 || $productdata->stock === null ): ?>-->
                                            <!--    <span class="available">-->
                                            <!--        <i class="fa fa-check-square-o"></i>-->
                                            <!--        <span><?php echo e($language->available); ?></span>-->
                                            <!--    </span>-->
                                            <!--<?php else: ?>-->
                                            <!--    <span class="not-available">-->
                                            <!--    <i class="fa fa-times-circle-o"></i>-->
                                            <!--    <span><?php echo e($language->out_of_stock); ?></span>-->
                                            <!--    </span>-->
                                            <!--<?php endif; ?>-->
                
                                            <!--</p>-->
                                            <!--<div>-->
                                            <!--    <div class="ratings">-->
                                            <!--        <div class="empty-stars"></div>-->
                                            <!--        <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($productdata->id)); ?>%"></div>-->
                                            <!--    </div>-->
                                            <!--    <?php if(\App\Review::reviewCount($productdata->id) > 1): ?>-->
                                            <!--        <span><?php echo e(\App\Review::reviewCount($productdata->id)); ?> Reviews</span>-->
                                            <!--    <?php else: ?>-->
                                            <!--        <span><?php echo e(\App\Review::reviewCount($productdata->id)); ?> Review</span>-->
                                            <!--    <?php endif; ?>-->
                                            <!--</div>-->
                                            <!--<p class="product-description">-->
                                            <!--    <?php echo e(substr(strip_tags($productdata->description), 0, 600)); ?>...-->
                                            <!--    <a href="">show more</a>-->
                                            <!--</p>-->
                                            <!--<h1 class="product-price">-->
                                            <!--    <?php if($productdata->previous_price != ""): ?>-->
                                            <!--        <span>-->
                                            <!--            <del><?php echo e($settings[0]->currency_sign); ?><?php echo e($productdata->previous_price); ?></del>-->
                                            <!--        </span>-->
                                            <!--    <?php endif; ?>-->
                                            <!--        <?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Product::Cost($productdata->id)); ?>-->
                                            <!--</h1>-->
                
                                            <!--<?php if($productdata->sizes != null): ?>-->
                                            <!--    <div class="product-size" id="product-size">-->
                                            <!--    <p>Size</p>-->
                                            <!--        <?php $__currentLoopData = explode(',',$productdata->sizes); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
                                            <!--        <span><?php echo e($size); ?></span>-->
                                            <!--        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                                            <!--    </div>-->
                                            <!--<?php endif; ?>-->
                                            <!--<div class="product-quantity">-->
                                            <!--    <p><?php echo e($language->quantity); ?></p>-->
                                            <!--    <span class="quantity-btn" id="qty-minus"><i class="fa fa-minus"></i></span>-->
                                            <!--    <span id="pqty">1</span>-->
                                            <!--    <span class="quantity-btn" id="qty-add"><i class="fa fa-plus"}}></i></span>-->
                                            <!--</div>-->
                                            <!--<form class="addtocart-form">-->
                                            <!--    <?php echo e(csrf_field()); ?>-->
                                            <!--    <?php if(Session::has('uniqueid')): ?>-->
                                            <!--        <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">-->
                                            <!--    <?php else: ?>-->
                                            <!--        <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">-->
                                            <!--    <?php endif; ?>-->
                                            <!--    <input type="hidden" id="price" name="price" value="<?php echo e(\App\Product::Cost($productdata->id)); ?>">-->
                                            <!--    <input type="hidden" name="title" value="<?php echo e($productdata->title); ?>">-->
                                            <!--    <input type="hidden" name="product" value="<?php echo e($productdata->id); ?>">-->
                                            <!--    <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($productdata->id)); ?>">-->
                                            <!--    <input type="hidden" id="quantity" name="quantity" value="1">-->
                                            <!--    <input type="hidden" id="size" name="size" value="">-->
                                            <!--    <?php if($productdata->stock != 0 || $productdata->stock === null ): ?>-->
                                            <!--        <button type="button" class="product-addCart-btn to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>-->
                                            <!--    <?php else: ?>-->
                                            <!--        <button type="button" class="product-addCart-btn  to-cart" disabled><i class="fa fa-cart-plus"></i><?php echo e($language->out_of_stock); ?></button>-->
                                            <!--    <?php endif; ?>-->
                                            <!--</form>-->
                                            </div>
                                            
                                        </div>
                                        <div id="overview-tab-2" class="tab-pane fade">
                                            <p><?php echo $productdata->description; ?></p>
                                        </div>

                                        <div id="pricing-tab-3" class="tab-pane fade">
                                            <p><?php echo $productdata->policy; ?></p>
                                        </div>

                                        <div id="location-tab-4" class="tab-pane fade">
                                            <p>
                                                <!--<h1><?php echo e($language->write_a_review); ?></h1>-->
                                                <!--<div class="review-star">-->
                                                <!--    <div class='starrr' id='star1'></div>-->
                                                <!--    <div>-->
                                                <!--        <span class='your-choice-was' style='display: none;'>-->
                                                <!--            Your rating is: <span class='choice'></span>.-->
                                                <!--        </span>-->
                                                <!--    </div>-->
                                                <!--</div>-->
                                                <!--<form class="product-review-form" method="POST" action="<?php echo e(route('review.submit')); ?>">-->
                                                <!--    <?php echo e(csrf_field()); ?>-->
                                                <!--    <input type="hidden" name="rating" id="rate" value="5">-->
                                                <!--    <input type="hidden" name="productid" value="<?php echo e($productdata->id); ?>">-->
                                                <!--    <div class="form-group">-->
                                                <!--        <input name="name" type="text" class="form-control" placeholder="<?php echo e($language->name); ?>" required>-->
                                                <!--    </div>-->
                                                <!--    <div class="form-group">-->
                                                <!--        <input name="email" type="email" class="form-control" placeholder="<?php echo e($language->email); ?>" required>-->
                                                <!--    </div>-->
                                                <!--    <div class="form-group">-->
                                                <!--        <textarea name="review" id="" rows="5" placeholder="<?php echo e($language->review_details); ?>" class="form-control" style="resize: vertical;" required></textarea>-->
                                                <!--    </div>-->
                                                <!--    <?php if($errors->has('error')): ?>-->
                                                <!--        <span class="help-block">-->
                                                <!--            <strong><?php echo e($errors->first('password')); ?></strong>-->
                                                <!--        </span>-->
                                                <!--    <?php endif; ?>-->
                                                <!--    <div class="form-group text-center">-->
                                                <!--        <input name="btn" type="submit" class="btn-review" value="<?php echo e($language->submit); ?>">-->
                                                <!--    </div>-->
                                                <!--</form>-->
                                                <!--<hr>-->
                                                <!--<h1><?php echo e($language->reviews); ?>: </h1>-->
                                                <!--<hr>-->
                                                <div class="review-rating-description">
                                                    <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <div class="row">
                                                        <div class="col-md-3 col-sm-3">
                                                            <p><?php echo e($review->name); ?></p>
                                                            <div class="ratings">
                                                                <div class="empty-stars"></div>
                                                                <div class="full-stars" style="width:<?php echo e($review->rating*20); ?>%"></div>
                                                            </div>
                                                            <p><?php echo e($review->review_date); ?></p>
                                                        </div>
                                                        <div class="col-md-9 col-sm-9">
                                                            <p><?php echo e($review->review); ?></p>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <h4><?php echo e($language->no_review); ?></h4>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <!--<hr>-->
                                            </div>
                                        </div>
                            
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>

        <!--<div class="section-padding product-description-wrapper padding-bottom-0 padding-top-0 wow fadeInUp">-->
        <!--    <div class="container">-->
        <!--        <div class="row">-->
        <!--            <div class="col-md-12 col-sm-12 col-xs-12">-->
        <!--                <div class="custom-tab">-->
        <!--                    <div class="row">-->
        <!--                        <div class="col-md-5">-->
        <!--                            <ul class="tab-list">-->
        <!--                                <li class="active"><a data-toggle="tab" href="#overview-tab-1"><?php echo e($language->description); ?></a></li>-->
        <!--                                <li><a data-toggle="tab" href="#pricing-tab-2"><?php echo e($language->return_policy); ?></a></li>-->
        <!--                                <li><a data-toggle="tab" href="#location-tab-3"><?php echo e($language->reviews); ?>(<?php echo e(\App\Review::where('productid',$productdata->id)->count()); ?>)</a></li>-->
        <!--                            </ul>-->
        <!--                        </div>-->

        <!--                        <div class="col-md-7">-->
        <!--                            <?php if(Session::has('message')): ?>-->
        <!--                                <div class="alert alert-success alert-dismissable">-->
        <!--                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>-->
        <!--                                    <?php echo e(Session::get('message')); ?>-->
        <!--                                </div>-->
        <!--                            <?php endif; ?>-->
        <!--                            <div class="tab-content">-->
        <!--                                <div id="overview-tab-1" class="tab-pane active fade in">-->
        <!--                                    <p><?php echo $productdata->description; ?></p>-->
        <!--                                </div>-->

        <!--                                <div id="pricing-tab-2" class="tab-pane fade">-->
        <!--                                    <p><?php echo $productdata->policy; ?></p>-->
        <!--                                </div>-->

        <!--                                <div id="location-tab-3" class="tab-pane fade">-->
        <!--                                    <p>-->
        <!--                                        <h1><?php echo e($language->write_a_review); ?></h1>-->
        <!--                                        <hr>-->
        <!--                                        <div class="review-star">-->
        <!--                                            <div class='starrr' id='star1'></div>-->
        <!--                                            <div>-->
        <!--                                                <span class='your-choice-was' style='display: none;'>-->
        <!--                                                    Your rating is: <span class='choice'></span>.-->
        <!--                                                </span>-->
        <!--                                            </div>-->
        <!--                                        </div>-->
        <!--                                        <form class="product-review-form" method="POST" action="<?php echo e(route('review.submit')); ?>">-->
        <!--                                            <?php echo e(csrf_field()); ?>-->
        <!--                                            <input type="hidden" name="rating" id="rate" value="5">-->
        <!--                                            <input type="hidden" name="productid" value="<?php echo e($productdata->id); ?>">-->
        <!--                                            <div class="form-group">-->
        <!--                                                <input name="name" type="text" class="form-control" placeholder="<?php echo e($language->name); ?>" required>-->
        <!--                                            </div>-->
        <!--                                            <div class="form-group">-->
        <!--                                                <input name="email" type="email" class="form-control" placeholder="<?php echo e($language->email); ?>" required>-->
        <!--                                            </div>-->
        <!--                                            <div class="form-group">-->
        <!--                                                <textarea name="review" id="" rows="5" placeholder="<?php echo e($language->review_details); ?>" class="form-control" style="resize: vertical;" required></textarea>-->
        <!--                                            </div>-->
        <!--                                            <?php if($errors->has('error')): ?>-->
        <!--                                                <span class="help-block">-->
        <!--                                                    <strong><?php echo e($errors->first('password')); ?></strong>-->
        <!--                                                </span>-->
        <!--                                            <?php endif; ?>-->
        <!--                                            <div class="form-group text-center">-->
        <!--                                                <input name="btn" type="submit" class="btn-review" value="<?php echo e($language->submit); ?>">-->
        <!--                                            </div>-->
        <!--                                        </form>-->
        <!--                                        <hr>-->
        <!--                                        <h1><?php echo e($language->reviews); ?>: </h1>-->
        <!--                                        <hr>-->
        <!--                                        <div class="review-rating-description">-->
        <!--                                            <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>-->
        <!--                                            <div class="row">-->
        <!--                                                <div class="col-md-3 col-sm-3">-->
        <!--                                                    <p>cej</p>-->
        <!--                                                    <div class="ratings">-->
        <!--                                                        <div class="empty-stars"></div>-->
        <!--                                                        <div class="full-stars" style="width:<?php echo e($review->rating*20); ?>%"></div>-->
        <!--                                                    </div>-->
        <!--                                                    <p><?php echo e($review->review_date); ?></p>-->
        <!--                                                </div>-->
        <!--                                                <div class="col-md-9 col-sm-9">-->
        <!--                                                    <p><?php echo e($review->review); ?></p>-->
        <!--                                                </div>-->
        <!--                                            </div>-->
        <!--                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>-->
        <!--                                                <div class="row">-->
        <!--                                                    <div class="col-md-12">-->
        <!--                                                        <h4><?php echo e($language->no_review); ?></h4>-->
        <!--                                                    </div>-->
        <!--                                                </div>-->
        <!--                                            <?php endif; ?>-->
        <!--                                        </div>-->
        <!--                                        <hr>-->
        <!--                                    </div>-->
        <!--                                </div>-->
        <!--                            </div>-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->

        <div class="section-padding product-carousel-wrapper wow fadeInUp">
            <div class="container-fluid">
                <!--<div class="product-carousel-full-div">-->
                    <div class="row margin-bottom-0">
                        <div class="col-md-12">
                            <div class="section-title">
                                <h2 class="margin-bottom-0"><?php echo e($language->related_products); ?></h2>
                                <!--<hr>-->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <!--<div class="col-md-12">-->
                            <div class="product-carousel-list">
                                <?php $__currentLoopData = $relateds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-product-carousel-item text-center" id="imagepad" >
                                        <div class="image_latest_product_shubh">
                                            <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" alt="Product Image" /> </a>
                                            <?php  $gallery = $product->gallery_images->toArray();  ?>
                                            <a class="img-top" href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php if(!empty($gallery)): ?><?php echo e(url('/assets/images/gallery')); ?>/<?php echo e($gallery[0]['image']); ?><?php endif; ?>" src1="assets/images/subscription-form/subscibe_image.jpg" alt="Product Image" /> </a>
                                        </div>
                                        <div class="product-carousel-text">
                                            <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>">
                                                <h4 class="product-title"><?php echo e($product->title); ?></h4>
                                            </a>
                                            <!--<div class="ratings">-->
                                            <!--    <div class="empty-stars"></div>-->
                                            <!--    <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($product->id)); ?>%"></div>-->
                                            <!--</div>-->
                                            <div class="product-price">
                                                <?php if($product->previous_price != ""): ?>
                                                    <span class="original-price">₹<?php echo e($product->previous_price); ?></span>
                                                <?php else: ?>
                                                <?php endif; ?>
                                                <del class="offer-price">₹<?php echo e($product->price); ?></del>
                                            </div>
                                            <div class="product-meta-area">
                                                <form class="addtocart-form">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php if(Session::has('uniqueid')): ?>
                                                        <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                                    <?php else: ?>
                                                        <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                                    <?php endif; ?>
                                                    <input type="hidden" name="title" value="<?php echo e($product->title); ?>">
                                                    <input type="hidden" name="product" value="<?php echo e($product->id); ?>">

                                                    <input type="hidden" id="price_1" name="price_1" value="<?php echo e(\App\Product::Costtwopis($productdata->id)); ?>">
                                                     <input type="hidden" id="price_2" name="price_2" value="<?php echo e(\App\Product::Costfiftypis($productdata->id)); ?>">
                                                     <input type="hidden" id="price_3" name="price_3" value="<?php echo e(\App\Product::Costfivethousandpis($productdata->id)); ?>">

                                                    <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($product->id)); ?>">
                                                    <input type="hidden" id="quantity" name="quantity" value="1">
                                                    <!-- <?php if($product->stock != 0 || $product->stock === null ): ?>
                                                        <button type="button" class="addTo-cart to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>
                                                    <?php else: ?>
                                                        <button type="button" class="addTo-cart  to-cart" disabled><i class="fa fa-cart-plus"></i><?php echo e($language->out_of_stock); ?></button>
                                                    <?php endif; ?> -->
                                                </form>
                                                <!--<a  href="javascript:;" class="wish-list" onclick="getQuickView(<?php echo e($product->id); ?>)" data-toggle="modal" data-target="#myModal">-->
                                                <!--    <i class="fa fa-eye"></i>-->
                                                <!--</a>-->
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <!--</div>-->
                    </div>
                <!--</div>-->
            </div>
        </div>

        <!-- tranding products area start -->

             <?php if($pagesettings[0]->featuredpro_status): ?>
        <!-- starting of featured project area -->
        <div class="section-padding product-carousel-wrapper padding-top-0 padding-bottom-0 wow fadeInUp" id="tendingpad">
            <div class="container-fluid">
                <!--<div class="product-carousel-full-div">-->
                    <div class="row margin-bottom-0">
                        <div class="col-md-12">
                            <div class="section-title">
                                <h2 class="margin-bottom-0"><?php echo e($language->featured_products); ?></h2>
                                <!--<hr>-->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <!--<div class="col-md-12">-->
                            <div class="product-carousel-list">
                                <?php $__currentLoopData = $tranding; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-product-carousel-item text-center" id="imagepad" >
                                        <div class="image_latest_product_shubh">
                                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" alt="Product Image" /> </a>
                                        <?php  $gallery = $product->gallery_images->toArray();  ?>
                                        <a class="img-top" href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php if(!empty($gallery)): ?><?php echo e(url('/assets/images/gallery')); ?>/<?php echo e($gallery[0]['image']); ?><?php endif; ?>" src="assets/images/subscription-form/subscibe_image.jpg" alt="Product Image" style="margin: 0px; margin-left: 0px;" /> </a>
                                        </div>
                                        <div class="product-carousel-text">
                                            <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>">
                                                <h3 class="product-title"><?php echo e($product->title); ?></h3>
                                            </a>
                                            <!--<div class="ratings">-->
                                            <!--    <div class="empty-stars"></div>-->
                                            <!--    <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($product->id)); ?>%"></div>-->
                                            <!--</div>-->
                                            <div class="product-price">
                                                <?php if($product->previous_price != ""): ?>
                                                    <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Product::Cost($product->id)); ?></span>
                                                <?php else: ?>
                                                <?php endif; ?>
                                                <del class="offer-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->previous_price); ?></del>
                                            </div>
                                            <!--<div class="product-meta-area">-->
                                            <!--    <form class="addtocart-form">-->
                                            <!--        <?php echo e(csrf_field()); ?>-->
                                            <!--        <?php if(Session::has('uniqueid')): ?>-->
                                            <!--            <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">-->
                                            <!--        <?php else: ?>-->
                                            <!--            <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">-->
                                            <!--        <?php endif; ?>-->
                                            <!--        <input type="hidden" name="title" value="<?php echo e($product->title); ?>">-->
                                            <!--        <input type="hidden" name="product" value="<?php echo e($product->id); ?>">-->
                                            <!--        <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($product->id)); ?>">-->
                                            <!--        <input type="hidden" id="quantity" name="quantity" value="1">-->
                                            <!--        <?php if($product->stock != 0 || $product->stock === null ): ?>-->
                                            <!--            <button type="button" class="addTo-cart to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>-->
                                            <!--        <?php else: ?>-->
                                            <!--            <button type="button" class="addTo-cart  to-cart" disabled><i class="fa fa-cart-plus"></i><?php echo e($language->out_of_stock); ?></button>-->
                                            <!--        <?php endif; ?>-->
                                            <!--    </form>-->
                                                <!--<a  href="javascript:;" class="wish-list" onclick="getQuickView(<?php echo e($product->id); ?>)" data-toggle="modal" data-target="#myModal">-->
                                                <!--    <i class="fa fa-eye"></i>-->
                                                <!--</a>-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <!--</div>-->
                    </div>
                <!--</div>-->
            </div>
        </div>
        <!-- Ending of featured project area -->
        <?php endif; ?>



        <!-- tranding products area end -->
<!-- popup for show all Information -->



<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" style="font-size: 25px; color: #1B1212;" id="exampleModalLabel">Technical Information</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div class="row">
       <?php if($productdata->category[0] == 53): ?> 
          <div class="col-md-6">
           <ul>
             <li style="color: #1B1212;">Frame Shape <span style="padding-left: 24%;color: black;"><?php if($productdata->frameshape ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->frameshape); ?><?php endif; ?></span> </li><br>
             <li style="color: #1B1212;">Frame Color <span style="padding-left: 25%; color: black;"><?php if($productdata->framecolor ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->framecolor); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Gender<span style="padding-left: 34%;color: black;"><?php if($productdata->gender ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->gender); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Brand Name <span style="padding-left: 23%;color: black;"><?php if($productdata->brandname ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->brandname); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Model No<span style="padding-left: 29%;color: black;"><?php if($productdata->modelno ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->modelno); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Product Sku <span style="padding-left: 23%;color: black;"><?php if($productdata->productsku ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->productsku); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Frame Style <span style="padding-left: 24%;color: black;"><?php if($productdata->framestyle ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->framestyle); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Frame Material <span style="padding-left: 19%;color: black;"><?php if($productdata->framematerial ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->framematerial); ?><?php endif; ?></span></li><br>
           </ul>
          </div>
          <div class="col-md-6">
            <ul>
             <li style="color: #1B1212;">Frame Width<span style="padding-left: 27%; color: black;"><?php if($productdata->framewidth ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->framewidth); ?><?php endif; ?></span> </li><br>
             <li style="color: #1B1212;">Height <span style="padding-left: 37%; color: black;"><?php if($productdata->height ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->height); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Temple Material <span style="padding-left: 21%; color: black;"><?php if($productdata->templematerial ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->templematerial); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Temple Color<span style="padding-left: 27%; color: black;"><?php if($productdata->templecolor ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->templecolor); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Conditions <span style="padding-left: 30%; color: black;"><?php if($productdata->conditionsnew ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->conditionsnew); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Frame Type<span style="padding-left: 29%; color: black;"><?php if($productdata->frametype ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->frametype); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Frame Dimensions <span style="padding-left: 16%; color: black;"><?php if($productdata->productdimension ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->productdimension); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Warrenty Type<span style="padding-left: 24%; color: black;"><?php if($productdata->warrentytype ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->warrentytype); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Manufracturer<span style="padding-left: 24%;color: black;"><?php if($productdata->manufracturer ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->manufracturer); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Weight <span style="padding-left: 35%;color: black;"><?php if($productdata->weight ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->weight); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Country Of Origin<span style="padding-left: 19%;color: black;"><?php if($productdata->countryoforigin ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->countryoforigin); ?><?php endif; ?></span></li><br>
            </ul>
          </div>
        <?php elseif($productdata->category[0] == 58): ?>
          <div class="col-md-6">
             <ul>
               <li style="color: #1B1212;">Brand Name <span style="padding-left: 25%;color: black;"><?php if($productdata->brandname ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->brandname); ?><?php endif; ?></span> </li><br>
               <li style="color: #1B1212;">Product Sku <span style="padding-left: 25%; color: black;"><?php if($productdata->productsku ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->productsku); ?><?php endif; ?></span></li><br>
               <li style="color: #1B1212;">Lens Material<span style="padding-left: 24%;color: black;"><?php if($productdata->lensmaterialtype ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->lensmaterialtype); ?><?php endif; ?></span></li><br>
               <li style="color: #1B1212;">Diameter<span style="padding-left: 30%;color: black;"><?php if($productdata->diameter ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->diameter); ?><?php endif; ?></span></li><br>
               <li style="color: #1B1212;">Lens Color<span style="padding-left: 28%;color: black;"><?php if($productdata->lenscolor ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->lenscolor); ?><?php endif; ?></span></li><br>
               <li style="color: #1B1212;">Lens index <span style="padding-left: 26%;color: black;"><?php if($productdata->lensindex ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->lensindex); ?><?php endif; ?></span></li><br>
             </ul>
            </div>
            <div class="col-md-6">
              <ul>
               <li style="color: #1B1212;">Focal Length<span style="padding-left: 29%; color: black;"><?php if($productdata->focallength ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->focallength); ?><?php endif; ?></span> </li><br>
               <li style="color: #1B1212;">Manufracturer<span style="padding-left: 26%; color: black;"><?php if($productdata->manufracturer ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->manufracturer); ?><?php endif; ?></span></li><br>
               <li style="color: #1B1212;">Weight<span style="padding-left: 38%; color: black;"><?php if($productdata->weight ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->weight); ?><?php endif; ?></span></li><br>
               <li style="color: #1B1212;">Country Of Origin<span style="padding-left: 22%; color: black;"><?php if($productdata->countryoforigin ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->countryoforigin); ?><?php endif; ?></span></li><br>
               <li style="color: #1B1212;">Gravity<span style="padding-left: 39%; color: black;"><?php if($productdata->gravity ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->gravity); ?><?php endif; ?></span></li><br>
               <li style="color: #1B1212;">Coating Color<span style="padding-left: 28%; color: black;"><?php if($productdata->coatingcolor ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->coatingcolor); ?><?php endif; ?></span></li><br>
               <li style="color: #1B1212;">Abbe Value<span style="padding-left: 32%; color: black;"><?php if($productdata->abbevalue ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->abbevalue); ?><?php endif; ?></span></li><br>
              </ul>
            </div>
        <?php elseif($productdata->category[0] == 63): ?> 
           <div class="col-md-6">
           <ul>
             <li style="color: #1B1212;">Frame Shape <span style="padding-left: 24%;color: black;"><?php if($productdata->frameshape ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->frameshape); ?><?php endif; ?></span> </li><br>
             <li style="color: #1B1212;">Frame Color <span style="padding-left: 26%; color: black;"><?php if($productdata->framecolor ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->framecolor); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Gender<span style="padding-left: 35%;color: black;"><?php if($productdata->gender ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->gender); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Brand Name <span style="padding-left: 25%;color: black;"><?php if($productdata->brandname ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->brandname); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Model No<span style="padding-left: 31%;color: black;"><?php if($productdata->modelno ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->modelno); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Product Sku <span style="padding-left: 26%;color: black;"><?php if($productdata->productsku ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->productsku); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Frame Style <span style="padding-left: 27%;color: black;"><?php if($productdata->framestyle ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->framestyle); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Frame Material <span style="padding-left: 22%;color: black;"><?php if($productdata->framematerial ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->framematerial); ?><?php endif; ?></span></li><br>
           </ul>
          </div>
          <div class="col-md-6">
            <ul>
             <li style="color: #1B1212;">Frame Width<span style="padding-left: 23%; color: black;"><?php if($productdata->framewidth ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->framewidth); ?><?php endif; ?></span> </li><br>
             <li style="color: #1B1212;">Height <span style="padding-left: 33%; color: black;"><?php if($productdata->height ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->height); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Temple Material <span style="padding-left: 18%; color: black;"><?php if($productdata->templematerial ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->templematerial); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Temple Color<span style="padding-left: 24%; color: black;"><?php if($productdata->templecolor ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->templecolor); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Lens Material <span style="padding-left: 23%; color: black;"><?php if($productdata->lensmaterialtype ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->lensmaterialtype); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Lens Color<span style="padding-left: 29%; color: black;"><?php if($productdata->lenscolor ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->lenscolor); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Conditions <span style="padding-left: 28%; color: black;"><?php if($productdata->conditionsnew ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->conditionsnew); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Lens Technology<span style="padding-left: 19%; color: black;"><?php if($productdata->warrentytype ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->warrentytype); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Frame Type<span style="padding-left: 27%;color: black;"><?php if($productdata->manufracturer ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->manufracturer); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Manufracturer<span style="padding-left: 22%;color: black;"><?php if($productdata->weight ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->weight); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Warrenty Type<span style="padding-left: 22%;color: black;"><?php if($productdata-> warrentytype ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata-> warrentytype); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Frame Dimension<span style="padding-left: 16%;color: black;"><?php if($productdata->productdimension ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->productdimension); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Weight<span style="padding-left: 34%;color: black;"><?php if($productdata->weight ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->weight); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Country Of Origin<span style="padding-left: 17%;color: black;"><?php if($productdata->countryoforigin ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->countryoforigin); ?><?php endif; ?></span></li><br>
            </ul>
          </div> 
        <?php elseif($productdata->category[0] == 87): ?>

          <div class="col-md-6">
           <ul>
             <li style="color: #1B1212;">Brand Name <span style="padding-left: 22%;color: black;"><?php if($productdata->brandname ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->brandname); ?><?php endif; ?></span> </li><br>
             <li style="color: #1B1212;">Product Sku <span style="padding-left: 23%; color: black;"><?php if($productdata->productsku ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->productsku); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;"> Net Quantity<span style="padding-left: 23%;color: black;"><?php if($productdata->netquntity ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->netquntity); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Shelf Life <span style="padding-left: 28%;color: black;"><?php if($productdata->shelflife ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->shelflife); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Form<span style="padding-left: 35%;color: black;"><?php if($productdata->form ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->form); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Product Color <span style="padding-left: 20%;color: black;"><?php if($productdata->productcolor ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->productcolor); ?><?php endif; ?></span></li><br>
           </ul>
          </div>
          <div class="col-md-6">
            <ul>
             <li style="color: #1B1212;">Product Dimension<span style="padding-left: 22%; color: black;"><?php if($productdata->productdimension ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->productdimension); ?><?php endif; ?></span> </li><br>
             <li style="color: #1B1212;">Material <span style="padding-left: 40%; color: black;"><?php if($productdata->material ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->material); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Manufracturer <span style="padding-left: 29%; color: black;"><?php if($productdata->manufracturer ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->manufracturer); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Warrenty Type<span style="padding-left: 30%; color: black;"><?php if($productdata->warrentytype ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->warrentytype); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Weight <span style="padding-left: 41%; color: black;"><?php if($productdata->weight ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->weight); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Country Of Origin<span style="padding-left: 25%; color: black;"><?php if($productdata->countryoforigin ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->countryoforigin); ?><?php endif; ?></span></li><br>
            </ul>
          </div>
        <?php elseif($productdata->category[0] == 72): ?> 

          <div class="col-md-6">
           <ul>
             <li style="color: #1B1212;">Brand Name <span style="padding-left: 24%;color: black;"><?php if($productdata->brandname ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->brandname); ?><?php endif; ?></span> </li><br>
             <li style="color: #1B1212;">Product Sku <span style="padding-left: 25%; color: black;"><?php if($productdata->productsku ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->productsku); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Model No<span style="padding-left: 30%;color: black;"><?php if($productdata->modelno ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->modelno); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Usages Duration <span style="padding-left: 17%;color: black;"><?php if($productdata->usagesduration ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->usagesduration); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Diameter<span style="padding-left: 30%;color: black;"><?php if($productdata->diameter ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->diameter); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Contact Lens Material<span style="padding-left: 9%;color: black;"><?php if($productdata->contactlensmaterialtype ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->contactlensmaterialtype); ?><?php endif; ?></span></li><br>
           </ul>
          </div>
          <div class="col-md-6">
            <ul>
             <li style="color: #1B1212;">Base Curve<span style="padding-left: 28%; color: black;"><?php if($productdata->basecurve ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->basecurve); ?><?php endif; ?></span> </li><br>
             <li style="color: #1B1212;">water content<span style="padding-left: 23%; color: black;"><?php if($productdata->watercontent ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->watercontent); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Power <span style="padding-left: 35%; color: black;"><?php if($productdata->power ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->power); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Disposability<span style="padding-left: 25%; color: black;"><?php if($productdata->disposability ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->disposability); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Packaging<span style="padding-left: 29%; color: black;"><?php if($productdata->packaging ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->packaging); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Lens Color<span style="padding-left: 30%; color: black;"><?php if($productdata->lenscolor ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->lenscolor); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Lens Manufracturer<span style="padding-left: 15%; color: black;"><?php if($productdata->manufracturer ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->manufracturer); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Country Of Origin<span style="padding-left: 19%; color: black;"><?php if($productdata->countryoforigin ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->countryoforigin); ?><?php endif; ?></span></li><br>
            </ul>
          </div>
        <?php elseif($productdata->category[0] == 82): ?>
          <div class="col-md-6">
           <ul>
             <li style="color: #1B1212;">Frame Shape <span style="padding-left: 24%;color: black;"><?php if($productdata->frameshape ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->frameshape); ?><?php endif; ?></span> </li><br>
             <li style="color: #1B1212;">Frame Color <span style="padding-left: 26%; color: black;"><?php if($productdata->framecolor ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->framecolor); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Gender<span style="padding-left: 35%;color: black;"><?php if($productdata->gender ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->gender); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Brand Name <span style="padding-left: 25%;color: black;"><?php if($productdata->brandname ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->brandname); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Model No<span style="padding-left: 31%;color: black;"><?php if($productdata->modelno ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->modelno); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Product Sku <span style="padding-left: 26%;color: black;"><?php if($productdata->productsku ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->productsku); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Frame Style <span style="padding-left: 27%;color: black;"><?php if($productdata->framestyle ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->framestyle); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Frame Material <span style="padding-left: 22%;color: black;"><?php if($productdata->framematerial ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->framematerial); ?><?php endif; ?></span></li><br>
           </ul>
          </div>
          <div class="col-md-6">
            <ul>
             <li style="color: #1B1212;">Frame Width<span style="padding-left: 23%; color: black;"><?php if($productdata->framewidth ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->framewidth); ?><?php endif; ?></span> </li><br>
             <li style="color: #1B1212;">Height <span style="padding-left: 33%; color: black;"><?php if($productdata->height ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->height); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Temple Material <span style="padding-left: 18%; color: black;"><?php if($productdata->templematerial ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->templematerial); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Temple Color<span style="padding-left: 24%; color: black;"><?php if($productdata->templecolor ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->templecolor); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Lens Material <span style="padding-left: 23%; color: black;"><?php if($productdata->lensmaterialtype ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->lensmaterialtype); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Lens Color<span style="padding-left: 29%; color: black;"><?php if($productdata->lenscolor ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->lenscolor); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Conditions <span style="padding-left: 28%; color: black;"><?php if($productdata->conditionsnew ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->conditionsnew); ?><?php endif; ?></span></li><br>
             <li style="color: #1B1212;">Lens Technology<span style="padding-left: 19%; color: black;"><?php if($productdata->warrentytype ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->warrentytype); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Frame Type<span style="padding-left: 27%;color: black;"><?php if($productdata->manufracturer ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->manufracturer); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Manufracturer<span style="padding-left: 22%;color: black;"><?php if($productdata->weight ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->weight); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Warrenty Type<span style="padding-left: 22%;color: black;"><?php if($productdata-> warrentytype ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata-> warrentytype); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Frame Dimension<span style="padding-left: 16%;color: black;"><?php if($productdata->productdimension ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->productdimension); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Weight<span style="padding-left: 34%;color: black;"><?php if($productdata->weight ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->weight); ?><?php endif; ?></span></li><br>
              <li style="color: #1B1212;">Country Of Origin<span style="padding-left: 17%;color: black;"><?php if($productdata->countryoforigin ==''): ?>: NA <?php else: ?>:  <?php echo e($productdata->countryoforigin); ?><?php endif; ?></span></li><br>
            </ul>
          </div> 

        <?php endif; ?>
      </div>
      </div>
      <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div> -->
    </div>
  </div>
</div>



<!-- end popup for show all information -->


        <!-- for selected image slider  start-->

                 <?php if($pagesettings[0]->featuredpro_status): ?>
        <!-- starting of featured project area -->
        <div class="section-padding product-carousel-wrapper padding-top-0 padding-bottom-0 wow fadeInUp" id="selectedpad">
            <div class="container-fluid">
                <!--<div class="product-carousel-full-div">-->
                    <div class="row margin-bottom-0">
                        <div class="col-md-12">
                            <div class="section-title">
                                <h2 class="margin-bottom-0">Selected Product</h2>
                                <!--<hr>-->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <!--<div class="col-md-12">-->
                            <div class="product-carousel-list">
                                <?php $__currentLoopData = $selected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-product-carousel-item text-center" id="imagepad">
                                        <div class="image_latest_product_shubh">
                                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" alt="Product Image" /> </a>
                                        <?php  $gallery = $product->gallery_images->toArray();  ?>
                                        <a class="img-top" href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php if(!empty($gallery)): ?><?php echo e(url('/assets/images/gallery')); ?>/<?php echo e($gallery[0]['image']); ?><?php endif; ?>" src="assets/images/subscription-form/subscibe_image.jpg" alt="Product Image" style="margin: 0px; margin-left: 0px;" /> </a>
                                        </div>
                                        <div class="product-carousel-text">
                                            <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>">
                                                <h3 class="product-title"><?php echo e($product->title); ?></h3>
                                            </a>
                                            <!--<div class="ratings">-->
                                            <!--    <div class="empty-stars"></div>-->
                                            <!--    <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($product->id)); ?>%"></div>-->
                                            <!--</div>-->
                                            <div class="product-price">
                                                <?php if($product->previous_price != ""): ?>
                                                    <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Product::Cost($product->id)); ?></span>
                                                <?php else: ?>
                                                <?php endif; ?>
                                                <del class="offer-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->previous_price); ?></del>
                                            </div>
                                            <!--<div class="product-meta-area">-->
                                            <!--    <form class="addtocart-form">-->
                                            <!--        <?php echo e(csrf_field()); ?>-->
                                            <!--        <?php if(Session::has('uniqueid')): ?>-->
                                            <!--            <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">-->
                                            <!--        <?php else: ?>-->
                                            <!--            <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">-->
                                            <!--        <?php endif; ?>-->
                                            <!--        <input type="hidden" name="title" value="<?php echo e($product->title); ?>">-->
                                            <!--        <input type="hidden" name="product" value="<?php echo e($product->id); ?>">-->
                                            <!--        <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($product->id)); ?>">-->
                                            <!--        <input type="hidden" id="quantity" name="quantity" value="1">-->
                                            <!--        <?php if($product->stock != 0 || $product->stock === null ): ?>-->
                                            <!--            <button type="button" class="addTo-cart to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>-->
                                            <!--        <?php else: ?>-->
                                            <!--            <button type="button" class="addTo-cart  to-cart" disabled><i class="fa fa-cart-plus"></i><?php echo e($language->out_of_stock); ?></button>-->
                                            <!--        <?php endif; ?>-->
                                            <!--    </form>-->
                                                <!--<a  href="javascript:;" class="wish-list" onclick="getQuickView(<?php echo e($product->id); ?>)" data-toggle="modal" data-target="#myModal">-->
                                                <!--    <i class="fa fa-eye"></i>-->
                                                <!--</a>-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <!--</div>-->
                    </div>
                <!--</div>-->
            </div>
        </div>
        <!-- Ending of featured project area -->
        <?php endif; ?>





        <!-- for selected image slider  end -->




    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $('#star1').starrr({
        rating: 5,
        change: function(e, value){
            if (value) {
                $('.your-choice-was').show();
                $('.choice').text(value);
                $('#rate').val(value);
            } else {
                $('.your-choice-was').hide();
            }
        }
    });

    $("#showmore").click(function() {
        $('html, body').animate({
            scrollTop: $("#description").offset().top - 200
        }, 1000);
    });


    $('#star1').starrr({
        rating: 5,
        change: function(e, value){
            if (value) {
                $('.your-choice-was').show();
                $('.choice').text(value);
                $('#rate').val(value);
            } else {
                $('.your-choice-was').hide();
            }
        }
    });
</script>

<script>
function myFunction() {
var popup = document.getElementById("myPopup");
popup.classList.toggle("show");

if (popup.paused){ 
    popup.play(); 
    }
  else{ 
    popup.pause();
    }
 
}
</script>
<!-- video 1 -->

<script type="text/javascript">
    window.document.onkeydown = function(e) {
  if (!e) {
    e = event;
  }
  if (e.keyCode == 27) {
    lightbox_close();
  }
}

function lightbox_open() {
  var lightBoxVideo = document.getElementById("VisaChipCardVideo");
  window.scrollTo(0, 0);
  document.getElementById('light').style.display = 'block';
  document.getElementById('fade').style.display = 'block';
  lightBoxVideo.play();
}

function lightbox_close() {
  var lightBoxVideo = document.getElementById("VisaChipCardVideo");
  document.getElementById('light').style.display = 'none';
  document.getElementById('fade').style.display = 'none';
  lightBoxVideo.pause();
}
</script>
<!--end video 1 -->

<!-- video 2 -->
  
  <script type="text/javascript">
    window.document.onkeydown = function(e) {
  if (!e) {
    e = event;
  }
  if (e.keyCode == 27) {
    lightbox_close1();
  }
}

function lightbox_open1() {
  var lightBoxVideo = document.getElementById("VisaChipCardVideo1");
  window.scrollTo(0, 0);
  document.getElementById('light1').style.display = 'block';
  document.getElementById('fade1').style.display = 'block';
  lightBoxVideo.play();
}

function lightbox_close1() {
  var lightBoxVideo = document.getElementById("VisaChipCardVideo1");
  document.getElementById('light1').style.display = 'none';
  document.getElementById('fade1').style.display = 'none';
  lightBoxVideo.pause();
}
  </script>

<!-- end video 2 -->


<!-- video 3 -->

<script type="text/javascript">
  window.document.onkeydown = function(e) {
  if (!e) {
    e = event;
  }
  if (e.keyCode == 27) {
    lightbox_close2();
  }
}

function lightbox_open2() {
  var lightBoxVideo = document.getElementById("VisaChipCardVideo2");
  window.scrollTo(0, 0);
  document.getElementById('light2').style.display = 'block';
  document.getElementById('fade2').style.display = 'block';
  lightBoxVideo.play();
}

function lightbox_close2() {
  var lightBoxVideo = document.getElementById("VisaChipCardVideo2");
  document.getElementById('light2').style.display = 'none';
  document.getElementById('fade2').style.display = 'none';
  lightBoxVideo.pause();
}
</script>

<!-- end video 3 -->

<!-- <script type="text/javascript">
    $(function () {
    //Loop through all Labels with class 'editable'.
    $(".editable").each(function () {
        //Reference the Label.
        var label = $(this);
 
        //Add a TextBox next to the Label.
        label.after("<input type = 'text' style = 'display:none' />");
 
        //Reference the TextBox.
        var textbox = $(this).next();
 
        //Set the name attribute of the TextBox.
        textbox[0].name = this.id.replace("lbl", "txt");
 
        //Assign the value of Label to TextBox.
        textbox.val(label.html());
 
        //When Label is clicked, hide Label and show TextBox.
        label.click(function () {
            $(this).hide();
            $(this).next().show();
        });
 
        //When focus is lost from TextBox, hide TextBox and show Label.
        textbox.focusout(function () {
            $(this).hide();
            $(this).prev().html($(this).val());
            $(this).prev().show();
        });
    });
});
</script> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.newmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>