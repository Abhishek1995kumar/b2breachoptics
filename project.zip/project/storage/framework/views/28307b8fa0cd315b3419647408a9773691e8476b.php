<!DOCTYPE html>
<html>
<head>
	<title>Invoice</title>
</head>
<body>
<h1><?php echo e($order->id); ?></h1>	
</body>
</html>