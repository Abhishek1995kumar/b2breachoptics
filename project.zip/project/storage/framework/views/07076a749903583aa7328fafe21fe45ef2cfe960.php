<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script
    src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet"
    href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet"
    href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">
<style type="text/css">
	
	.demo {
  padding: 30px;
  min-height: 280px;
}

.tab-content{
  padding: 10px;
}

@nav-link-hover-bg: #eeeeee;
@nav-tabs-border-color: #dddddd;
@border-radius-base: 5px;
@screen-xs-max: 767px;


//css to add hamburger and create dropdown
.nav-tabs.nav-tabs-dropdown,
.nav-tabs-dropdown {
 @media (max-width: @screen-xs-max) {
      border: 1px solid @nav-tabs-border-color;
      border-radius: @border-radius-base;
      overflow: hidden;
      position: relative;

      &::after {
        content: "☰";
        position: absolute;
        top: 8px;
        right: 15px;
        z-index: 2;
        pointer-events: none;
      }

      &.open {
        a {
          position: relative;
          display: block;
        }

        > li.active > a {
          background-color: @nav-link-hover-bg;
        }
      }


    li {
      display: block;
      padding: 0;
      vertical-align: bottom;
    }

    > li > a {
      position: absolute;
      top: 0;
      left: 0;
      margin: 0;
      width: 100%;
      height: 100%;
      display: inline-block;
      border-color: transparent;

      &:focus,
      &:hover,
      &:active {
        border-color: transparent;
      }
    }

    > li.active > a {
      display:block;
      border-color: transparent;
      position: relative;
      z-index: 1;
      background: #fff;

      &:focus,
      &:hover,
      &:active {
        border-color: transparent;
      }
       
    }
  }
}


</style>

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row" id="main">
             
               
                <!-- Page Heading -->
                <div class="go-title">
                    <h3> Cancel Orders</h3>
                    <div class="go-line"></div>
                </div>
                <!-- Page Content -->
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div id="response">
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('error')): ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('error')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-12">
							<div class="demo">
							  <div role="tabpanel">

							  <!-- Nav tabs -->
							  <ul class="nav nav-tabs nav-justified nav-tabs-dropdown" role="tablist">
							    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">REACH CANCELLED ORDER</a></li>
							    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">VENDOR CANCELLED ORDER</a></li>
							  </ul>

							  <!-- Tab panes -->
							  <div class="tab-content">
							    <div role="tabpanel" class="tab-pane active" id="home">
							    	<table class="table" id="tableone">
                                                <thead>
                                                    <tr>
                                                        <th class="text-center" style="font-size: 12px">Order Id</th>
                                                        <th class="text-center" style="font-size: 12px">Product</th>
                                                        <th class="text-center" style="font-size: 12px">SKU</th>
                                                        <th class="text-center" style="font-size: 12px">Date & Time</th>
                                                        <th class="text-center" style="font-size: 12px">Cancel Date</th>
                                                        <th class="text-center" style="font-size: 12px">Qty</th>
                                                        <th class="text-center" style="font-size: 12px">MRP</th>
                                                        <th class="text-center" style="font-size: 12px">Seller</th>
                                                        <th class="text-center" style="font-size: 12px">View</th>
                                                        <th class="text-center" style="font-size: 12px">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $adminordercancel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->orderid); ?></td>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->product_title); ?></td>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->product_sku); ?></td>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->created_at); ?></td>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->canceled_date); ?></td>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->quantity); ?></td>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->cost); ?></td>
                                                        <?php if($row->vendorname == ''): ?>
                                                        <td class="text-center" style="font-size: 15px;">Reach</td>
                                                        <?php else: ?>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->vendorname); ?></td>
                                                        <?php endif; ?>
                                                        <td class="text-center" style="font-size: 15px;"><a href="<?php echo e(url('admin/cancel/order/view/')); ?>/<?php echo e($row->id); ?>"><i class="fa fa-eye" style="font-size:15px"></i></a></td>
                                                        <?php if($row->status == 'cancelled'): ?>
                                                            <td class="text-center" style="font-size: 15px;"><a href="<?php echo e(url('cancel_order/'.$row->orderid)); ?>" class="btn btn-danger btn-md" >Cancel Order</a></td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                    </table>
							    </div>
							    <div role="tabpanel" class="tab-pane" id="profile">
							    	<table class="table" id="tableone">
                                                <thead>
                                                    <tr>
                                                        <th class="text-center" style="font-size: 12px">Order Id</th>
                                                        <th class="text-center" style="font-size: 12px">Product</th>
                                                        <th class="text-center" style="font-size: 12px">SKU</th>
                                                        <th class="text-center" style="font-size: 12px">Date & Time</th>
                                                        <th class="text-center" style="font-size: 12px">Cancel Date</th>
                                                        <th class="text-center" style="font-size: 12px">Qty</th>
                                                        <th class="text-center" style="font-size: 12px">MRP</th>
                                                        <th class="text-center" style="font-size: 12px">Seller</th>
                                                        <th class="text-center" style="font-size: 12px">View</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $vendorordercancel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->orderid); ?></td>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->product_title); ?></td>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->product_sku); ?></td>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->created_at); ?></td>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->canceled_date); ?></td>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->quantity); ?></td>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->cost); ?></td>
                                                         <?php if($row->vendorname == ''): ?>
                                                        <td class="text-center" style="font-size: 15px;">Reach</td>
                                                        <?php else: ?>
                                                        <td class="text-center" style="font-size: 15px;"><?php echo e($row->vendorname); ?></td>
                                                        <?php endif; ?>
                                                        <td class="text-center" style="font-size: 15px;"><a href="<?php echo e(url('admin/cancel/order/view/')); ?>/<?php echo e($row->id); ?>"><i class="fa fa-eye" style="font-size:15px"></i></a></td>
                                                        <?php if($row->status == 'cancelled'): ?>
                                                            <td class="text-center" style="font-size: 15px;"><a href="<?php echo e(url('cancel_order/'.$row->orderid)); ?>" class="btn btn-danger btn-md" >Cancel Order</a></td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                    </table>
							    </div>
							  </div>
							 </div>
							</div>
                        </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>




<?php $__env->stopSection(); ?>

<script type="text/javascript">
	$('.nav-tabs-dropdown')
    .on("click", "li:not('.active') a", function(event)) {  $(this).closest('ul').removeClass("open");
    })
    .on("click", "li.active a", function(event)) {        $(this).closest('ul').toggleClass("open");
    });

</script>

<script type="text/javascript">
    
    $(document).ready(function() {
    $('table.table').DataTable();
} );

</script>	

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.includes.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>