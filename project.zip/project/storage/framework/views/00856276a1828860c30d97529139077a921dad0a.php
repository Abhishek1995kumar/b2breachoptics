<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/assets/css/pres.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/dataTables.bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/font-awesome.min.css')); ?>">
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>

    <link style="height : 10px;" rel="icon" type="image/png" href="<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->favicon); ?>" />
    <title><?php echo e($settings[0]->title); ?> > Prescription</title>
    
</head>
<body>
	<header class="header">
		<img alt="" src="<?php echo e(URL::asset('assets/images/logo')); ?>/<?php echo e($settings[0]->logo); ?>">
	</header>
    <div class="section">
		<div class="grid-column-two">
			<div class="form_image">
				<div class="card-image">
					<?php if($main == $productdata->lenscolor): ?>
						<div class="img-div-data">
							<img src="<?php echo e(URL::asset('assets/images/products/'.$productdata->feature_image)); ?>" alt="">
						</div>
					<?php else: ?>
						<div class="img-div-data">
							<img src="<?php echo e(URL::asset('assets/images/product_attr/'.$attrgallery->attr_imgs)); ?>" alt="">
						</div>
					<?php endif; ?>
				</div>
			</div>
			<form action="" class="addtocart-form" id="PrescriptionForm" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

				<div class="title">
					<h2>Get Your Contacts</h2>
				</div>

				<!-- Progressive bar -->

				<div class="progressbar">
					<div class="progress-step progress-step-active" data-title="Add Prescritons"></div>
					<div class="progress-step" data-title="Fill in right eye <?php echo "(OD)" ?>"></div>
					<div class="progress-step" data-title="Fill in Both Eye <?php echo "(OD & OS)" ?>"></div>
					<div class="progress-step" data-title="Fill in left eye <?php echo "(OD)" ?>"></div>
					<div class="progress-step" data-title="select-quantity"></div>
					<div class="progress-step" data-title="Great!<span>Let's finish up"></div>
				</div>
				<hr>

				<input type="hidden" name="cartcolor" value="<?php echo e($main); ?>">
				<input type="hidden" name="maincolor" value="<?php echo e($productdata->lenscolor); ?>">
				<div class="form-step form-step-active" id="form-1">
					<div class="back">
						<a href="<?php echo e(url('product/'.$productdata->id.'/'.$productdata->title)); ?>" class="backbtn">Back</a>
					</div>
					<div class="form-data" id="form-model">
						<div class="title"><h2>Add Prescritons</h2></div>
						<div class="main_box">
							<div class="input-group">
								<label for="uploadFile" class="uploadImage">
								    <p class="showImageData">file type - png, jpg, gif and jpeg required</p>
								    Upload File
								    <i class="fa fa-camera"></i>
								</label>
								<input  id="uploadFile" accept="image/png, image/jpg, image/gif, image/jpeg"  class="upload" name="presc_image" type="file">
							</div>
							<div class="input-group">
								<div class="fill-manual">
								    Fill in manually
								    <i class="fa fa-hand-paper-o"></i>
								</div>
							</div>
							<div>
								<a href="javascript:void(0)" class="btn next-1">Skip and send leter</a>
							</div>
						</div>
					</div>

					<div class="form-data" id="img-model">
						<div class="title"><h2>Add Prescritons</h2></div>
						<div class="main_box">
							<div class="input-group img-div">
								<img  id="showFile" src="" style="width:180px; height:160px;">
							</div>
							<div class="input-group img-name">
								<label for="" id="showLabel"></label>
							</div>
							<div>
								<a href="javascript:void(0)" class="btn img-next">Select Your Quantity</a>
							</div>
						</div>
					</div>
				</div>

				<div class="form-step" id="form-2">
					<div class="back">
						<a href="javascript:void(0)" class="backbtn back-1">Back</a>
					</div>
					<div class="form-data">
						<div class="title"><h2>Fill in right eye <?php echo "(OD)" ?></h2></div>
						<div class="main_box">
							<div class="option-input-group">
								<?php if($productdata->lenstype == "MultiFocal"): ?>
									<div class="right button-div">
										<button role="button" type="button" class="power-button" aria-haspopup="listbox">
											<span type="text" class="sphere-data">Power</span>
											<input name="rsphere" type="text" class="getPowerRight" readonly>
											<span class="massage">This field is required</span>
										</button>
										<div class="data-table">
											<div class="range-list">
												<svg width="100%" xmlns="http://www.w3.org/2000/svg">
													<path d="M14 2H2" fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round"></path>
												</svg>
												<svg width="100%" xmlns="http://www.w3.org/2000/svg">
													<g fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round">
														<path d="M13.7 7.85H2M7.85 13.7V2"></path>
													</g>
												</svg>
											</div>
											<div class="value">
												<li class="power-data-right" value="0.00">0.00</li>
											</div>
											<div class="sphare-data">
												<div class="min-data">
													<ul>
														<?php $__currentLoopData = explode(',',$productdata->powermin); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li class="power-data-right" value="<?php echo e($mi); ?>"><?php echo e($mi); ?></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
												<div class="max-data">
													<ul>
														<?php $__currentLoopData = explode(',',$productdata->powermax); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li class="power-data-right" value="<?php echo e($ma); ?>"><?php echo e($ma); ?></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="right" style="display: flex; align-items:center;">
    							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">ADD</p>
										<select name="rpower" id="multi_rpower" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->addpower); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addpowerr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($addpowerr); ?>"><?php echo e($addpowerr); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<span class="massage">This field is required</span>
									</div>
									<div class="right" style="display: flex; align-items:center;">
    							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">BC</p>
										<select name="rbc" id="multi_rbc" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->basecurve); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basecurvee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($basecurvee); ?>"><?php echo e($basecurvee); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<span class="massage">This field is required</span>
									</div>
									<div class="right" style="display: flex; align-items:center; margin-top: 4px;">
    							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">Dia</p>
										<select name="rdia" id="multi_rdia" class="sphare" style="position: realative; text-align: center;">
											<?php $__currentLoopData = explode(',',$productdata->diameter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diameterr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($diameterr); ?>" selected>DIA <?php echo e($diameterr); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<span class="massage">This field is required</span>
									</div>
								<?php elseif($productdata->lenstype == "toric & Astigmatism"): ?>
									<div class="right button-div">
										<button role="button" type="button" class="power-button" aria-haspopup="listbox">
											<span type="text" class="sphere-data">Power</span>
											<input name="rsphere" type="text" class="getPowerRight" readonly>
											<span class="massage">This field is required</span>
										</button>
										<div class="data-table">
											<div class="range-list">
												<svg width="100%" xmlns="http://www.w3.org/2000/svg">
													<path d="M14 2H2" fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round"></path>
												</svg>
												<svg width="100%" xmlns="http://www.w3.org/2000/svg">
													<g fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round">
														<path d="M13.7 7.85H2M7.85 13.7V2"></path>
													</g>
												</svg>
											</div>
											<div class="value">
												<li class="power-data-right" value="0.00">0.00</li>
											</div>
											<div class="sphare-data">
												<div class="min-data">
													<ul>
														<?php $__currentLoopData = explode(',',$productdata->powermin); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li class="power-data-right" value="<?php echo e($mi); ?>"><?php echo e($mi); ?></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
												<div class="max-data">
													<ul>
														<?php $__currentLoopData = explode(',',$productdata->powermax); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li class="power-data-right" value="<?php echo e($ma); ?>"><?php echo e($ma); ?></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="right" style="display: flex; align-items:center;">
    							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">Axis</p>
										<select name="Raxis" id="toric_raxis" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->axisnew); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $axisn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($axisn); ?>"><?php echo e($axisn); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<span class="massage">This field is required</span>
									</div>
									<div class="right" style="display: flex; align-items:center;">
    							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">DIA</p>
										<select name="rdia" id="toric_rdia" class="sphare" style="position: realative; text-align: center;" readonly>
											<?php $__currentLoopData = explode(',',$productdata->diameter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $di): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($di); ?>" selected><?php echo e($di); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<span class="massage">This field is required</span>
									</div>
									<div class="right" style="display: flex; align-items:center; margin-top: 4px;">
    							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">BC</p>
										<select name="rbc" id="toric_rbc" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->basecurve); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basecu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($basecu); ?>"><?php echo e($basecu); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<span class="massage">This field is required</span>
									</div>
									<div class="right" style="display: flex; align-items:center; margin-top: 4px;">
    							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">CYL</p>
									    <select name="rcyl" id="toric_rcyl" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->cylindernew); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cylinder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($cylinder); ?>"><?php echo e($cylinder); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<span class="massage">This field is required</span>
									</div>
								<?php elseif($productdata->lenstype == "Spherical"): ?>
									<div class="right button-div">
										<button role="button" type="button" class="power-button" aria-haspopup="listbox">
											<span type="text" class="sphere-data">Power</span>
											<input name="rsphere" type="text" class="getPowerRight" readonly>
											<span class="massage">This field is required</span>
										</button>
										<div class="data-table">
											<div class="range-list">
												<svg width="100%" xmlns="http://www.w3.org/2000/svg">
													<path d="M14 2H2" fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round"></path>
												</svg>
												<svg width="100%" xmlns="http://www.w3.org/2000/svg">
													<g fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round">
														<path d="M13.7 7.85H2M7.85 13.7V2"></path>
													</g>
												</svg>
											</div>
											<div class="value">
												<li class="power-data-right" value="0.00">0.00</li>
											</div>
											<div class="sphare-data">
												<div class="min-data">
													<ul>
														<?php $__currentLoopData = explode(',',$productdata->powermin); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li class="power-data-right" value="<?php echo e($mi); ?>"><?php echo e($mi); ?></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
												<div class="max-data">
													<ul>
														<?php $__currentLoopData = explode(',',$productdata->powermax); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li class="power-data-right" value="<?php echo e($ma); ?>"><?php echo e($ma); ?></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="right" style="display: flex; align-items:center;">
							            <p style="position: absolute; font-size: 14px; margin-left: 13px;">Dia</p>
										<select name="rdia" id="toric_rdia" class="sphare" style="position: realative; text-align: center;" readonly>
											<?php $__currentLoopData = explode(',',$productdata->diameter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($diam); ?>" selected><?php echo e($diam); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<span class="massage">This field is required</span>
									</div>
									<div class="right" style="display: flex; align-items:center;">
							            <p style="position: absolute; font-size: 14px; margin-left: 13px;">BC</p>
										<select name="rbc" id="toric_rbc" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->basecurve); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $base): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($base); ?>"><?php echo e($base); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<span class="massage">This field is required</span>
									</div>
								<?php else: ?>
									<select name="" id="" class="sphare">
										<option value=""></option>
									</select>
								<?php endif; ?>
							</div>
							<div class="show-prescription">
								<button class="showPrescription" type="button">How to read my prescriptions ?</button>
							</div>
							<div class="input-group">
								<input type="checkbox" name="same_rx_both" id="both_eyes" class="both_eyes"><p>Same Rx for both eyes</p>
							</div>
							<div>
								<a href="javascript:void(0)" class="btn next-2">Continue ot Left Eye</a>
							</div>
						</div>
					</div>
				</div>

				<div class="form-step" id="form-3">
					<div class="back">
						<a href="javascript:void(0)" class="backbtn back-2">Back</a>
					</div>
					<div class="form-data">
						<div class="title"><h2>Fill in Both Eye <?php echo "(OD & OS)" ?></h2></div>
						<div class="main_box">
							<div class="option-input-group">
							<?php if($productdata->lenstype == "MultiFocal" || $productdata->lenstype == "toric & Astigmatism" || $productdata->lenstype == "Spherical"): ?>
								<div class="right button-div">
									<button role="button" type="button" class="power-button" aria-haspopup="listbox">
										<span type="text" class="sphere-data">Power</span>
										<input name="bsphere" type="text" class="getPowerBoth" readonly>
									</button>
									<div class="data-table">
										<div class="range-list">
											<svg width="100%" xmlns="http://www.w3.org/2000/svg">
												<path d="M14 2H2" fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round"></path>
											</svg>
											<svg width="100%" xmlns="http://www.w3.org/2000/svg">
												<g fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round">
													<path d="M13.7 7.85H2M7.85 13.7V2"></path>
												</g>
											</svg>
										</div>
										<div class="value">
											<li class="power-data-both" value="0.00">0.00</li>
										</div>
										<div class="sphare-data">
											<div class="min-data">
												<ul>
													<?php $__currentLoopData = explode(',',$productdata->powermin); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<li class="power-data-both" value="<?php echo e($mi); ?>"><?php echo e($mi); ?></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
											</div>
											<div class="max-data">
												<ul>
													<?php $__currentLoopData = explode(',',$productdata->powermax); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<li class="power-data-both" value="<?php echo e($ma); ?>"><?php echo e($ma); ?></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
											</div>
										</div>
									</div>
								</div>
							<?php endif; ?>
							<?php if($productdata->lenstype == "MultiFocal"): ?>
							    <div class="right" style="display: flex; align-items:center;">
							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">ADD</p>
									<select name="bpower" id="multi_bpower" class="sphare" style="position: realative; text-align: center;">
										<?php $__currentLoopData = explode(',',$productdata->addpower); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addpowerr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($addpowerr); ?>"><?php echo e($addpowerr); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="right" style="display: flex; align-items:center;">
							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">BC</p>
									<select name="Bbc" id="multi_bbc" style="position: realative; text-align: center;">
									    <option value=""></option>
										<?php $__currentLoopData = explode(',',$productdata->basecurve); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basecu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value=""></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="right" style="display: flex; align-items:center; margin-top: 4px;">
							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">DIA</p>
									<select name="Bdia" id="multi_bdia">
										<?php $__currentLoopData = explode(',',$productdata->diameter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diameterr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($diameterr); ?>" selected><?php echo e($diameterr); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							<?php elseif($productdata->lenstype == "toric & Astigmatism"): ?>
							    <div class="right" style="display: flex; align-items:center;">
							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">Axis</p>
									<select name="Baxis" id="toric_baxis" class="sphare" style="position: realative; text-align: center;">
										<option value=""></option>
										<?php $__currentLoopData = explode(',',$productdata->axisnew); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $axisn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($axisn); ?>"><?php echo e($axisn); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="right" style="display: flex; align-items:center;">
							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">DIA</p>
									<select name="Bdia" id="toric_bdia" class="sphare" style="position: realative; text-align: center;">
										<?php $__currentLoopData = explode(',',$productdata->diameter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $di): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($di); ?>" selected><?php echo e($di); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="right" style="display: flex; align-items:center; margin-top: 4px;">
							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">BC</p>
									<select name="Bbc" id="toric_bbc" class="sphare" style="position: realative; text-align: center;">
										<option value=""></option>
										<?php $__currentLoopData = explode(',',$productdata->basecurve); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basecu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($basecu); ?>"><?php echo e($basecu); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="right" style="display: flex; align-items:center; margin-top: 4px;">
							        <p style="position: absolute; font-size: 14px; margin-left: 13px;">CYL</p>
									<select name="Bcyle" id="toric_bcyle" class="sphare" style="position: realative; text-align: center;">
										<option value=""></option>
										<?php $__currentLoopData = explode(',',$productdata->cylindernew); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cylinder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($cylinder); ?>"><?php echo e($cylinder); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							<?php elseif($productdata->lenstype == "Spherical"): ?>
							    <div class="right">
									<select name="Bbc" id="sph_bbc" disabled>
										<option value=""><h3>BC </h3>8.6</option>
									</select>
								</div>
								<div class="right" style="display: flex; align-items:center;">
								    <p style="position: absolute; font-size: 14px; margin-left: 13px;">DIA</p>
									<select name="Bdia" id="sph_bdia" style="position: realative; text-align: center;">
									    <?php $__currentLoopData = explode(',',$productdata->diameter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $di): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										    <option value="<?php echo e($di); ?>" selected><?php echo e($di); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							<?php else: ?>
								<div class="right">
									<select name="" id="both-eye" class="left-select">
										<div class="category">
											<div class="minus">
												<option value="">Power</option>
											</div>
										</div>
									</select>
								</div>
							<?php endif; ?>
							</div>
							<div class="show-prescription">
								<button class="showPrescription2" type="button">How to read my prescriptions ?</button>
							</div>
							<div class="input-group">
								<input type="checkbox" name="same_rx_both" id="both_eyes-2" class="both_eyes-2"><p>Same Rx for both eyes</p>
							</div>
							<div>
								<a href="javascript:void(0)" class="btn next-3">Select Quantity</a>
							</div>
						</div>
					</div>
				</div>

				<div class="form-step" id="form-4">
					<div class="back">
						<a href="javascript:void(0)" class="backbtn back-3">Back</a>
					</div>
					<div class="form-data">
						<div class="title"><h2>Fill in left eye <?php echo "(OD)" ?></h2></div>
						<div class="main_box">
							<div class="option-input-group">
								<?php if($productdata->lenstype == "MultiFocal"): ?>
									<div class="right button-div">
										<button role="button" type="button" class="power-button" aria-haspopup="listbox">
											<span type="text" class="sphere-data">Power</span>
											<input name="Lsphere" type="text" class="getPowerLeft" readonly>
										</button>
										<div class="data-table">
											<div class="range-list">
												<svg width="100%" xmlns="http://www.w3.org/2000/svg">
													<path d="M14 2H2" fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round"></path>
												</svg>
												<svg width="100%" xmlns="http://www.w3.org/2000/svg">
													<g fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round">
														<path d="M13.7 7.85H2M7.85 13.7V2"></path>
													</g>
												</svg>
											</div>
											<div class="value">
												<li class="power-data-left" value="0.00">0.00</li>
											</div>
											<div class="sphare-data">
												<div class="min-data">
													<ul>
														<?php $__currentLoopData = explode(',',$productdata->powermin); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li class="power-data-left" value="<?php echo e($mi); ?>"><?php echo e($mi); ?></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
												<div class="max-data">
													<ul>
														<?php $__currentLoopData = explode(',',$productdata->powermax); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li class="power-data-left" value="<?php echo e($ma); ?>"><?php echo e($ma); ?></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="right" style="display: flex; align-items:center;">
								        <p style="position: absolute; font-size: 14px; margin-left: 13px;">ADD</p>
										<select name="Lpower" id="multi_lopwer" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->addpower); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addpowerr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($addpowerr); ?>"><?php echo e($addpowerr); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
									<div class="right" style="display: flex; align-items:center;">
								        <p style="position: absolute; font-size: 14px; margin-left: 13px;">BC</p>
										<select name="LBc" id="multi_lbc" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->basecurve); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basecurvee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($basecurvee); ?>"><?php echo e($basecurvee); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
									<div class="right" style="display: flex; align-items:center; margin-top: 4px;">
								        <p style="position: absolute; font-size: 14px; margin-left: 13px;">DIA</p>
										<select name="LDia" id="multi_ldia" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->diameter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diameterr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($diameterr); ?>" selected><?php echo e($diameterr); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								<?php elseif($productdata->lenstype == "toric & Astigmatism"): ?>
									<div class="right button-div">
										<button role="button" type="button" class="power-button" aria-haspopup="listbox">
											<span type="text" class="sphere-data">Power</span>
											<input name="Lsphere" type="text" class="getPowerLeft" readonly>
										</button>
										<div class="data-table">
											<div class="range-list">
												<svg width="100%" xmlns="http://www.w3.org/2000/svg">
													<path d="M14 2H2" fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round"></path>
												</svg>
												<svg width="100%" xmlns="http://www.w3.org/2000/svg">
													<g fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round">
														<path d="M13.7 7.85H2M7.85 13.7V2"></path>
													</g>
												</svg>
											</div>
											<div class="value">
												<li class="power-data-left" value="0.00">0.00</li>
											</div>
											<div class="sphare-data">
												<div class="min-data">
													<ul>
														<?php $__currentLoopData = explode(',',$productdata->powermin); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li class="power-data-left" value="<?php echo e($mi); ?>"><?php echo e($mi); ?></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
												<div class="max-data">
													<ul>
														<?php $__currentLoopData = explode(',',$productdata->powermax); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li class="power-data-left" value="<?php echo e($ma); ?>"><?php echo e($ma); ?></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="right" style="display: flex; align-items:center;">
								        <p style="position: absolute; font-size: 14px; margin-left: 13px;">Axis</p>
										<select name="Laxis" id="toric_laxis" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->axisnew); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $axisn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($axisn); ?>"><?php echo e($axisn); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
									<div class="right" style="display: flex; align-items:center;">
								        <p style="position: absolute; font-size: 14px; margin-left: 13px;">DIA</p>
										<select name="LDia" id="toric_ldia" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->diameter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $di): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($di); ?>" selected><?php echo e($di); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
									<div class="right" style="display: flex; align-items:center; margin-top: 4px;">
								        <p style="position: absolute; font-size: 14px; margin-left: 13px;">BC</p>
										<select name="LBc" id="toric_lbc" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->basecurve); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basecu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($basecu); ?>"><?php echo e($basecu); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
									<div class="right" style="display: flex; align-items:center; margin-top: 4px;">
								        <p style="position: absolute; font-size: 14px; margin-left: 13px;">CYL</p>
										<select name="Lcyle" id="toric_lcyle" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->cylindernew); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cylinder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($cylinder); ?>"><?php echo e($cylinder); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								<?php elseif($productdata->lenstype == "Spherical"): ?>
									<div class="right button-div">
										<button role="button" type="button" class="power-button" aria-haspopup="listbox">
											<span type="text" class="sphere-data">Power</span>
											<input name="Lsphere" type="text" class="getPowerLeft" readonly>
										</button>
										<div class="data-table">
											<div class="range-list">
												<svg width="100%" xmlns="http://www.w3.org/2000/svg">
													<path d="M14 2H2" fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round"></path>
												</svg>
												<svg width="100%" xmlns="http://www.w3.org/2000/svg">
													<g fill-rule="nonzero" stroke="currentColor" stroke-width="3" fill="none" strok-linecap="round" stroke-linejoin="round">
														<path d="M13.7 7.85H2M7.85 13.7V2"></path>
													</g>
												</svg>
											</div>
											<div class="value">
												<li class="power-data-left" value="0.00">0.00</li>
											</div>
											<div class="sphare-data">
												<div class="min-data">
													<ul>
														<?php $__currentLoopData = explode(',',$productdata->powermin); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li class="power-data-left" value="<?php echo e($mi); ?>"><?php echo e($mi); ?></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
												<div class="max-data">
													<ul>
														<?php $__currentLoopData = explode(',',$productdata->powermax); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li class="power-data-left" value="<?php echo e($ma); ?>"><?php echo e($ma); ?></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="right" style="display: flex; align-items:center;">
								        <p style="position: absolute; font-size: 14px; margin-left: 13px;">DIA</p>
										<select name="LDia" id="sph_ldia" class="sphare" style="position: realative; text-align: center;">
											<option value="LDia"></option>
											<?php $__currentLoopData = explode(',',$productdata->diameter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($diam); ?>" selected><?php echo e($diam); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
									<div class="right" style="display: flex; align-items:center;">
								        <p style="position: absolute; font-size: 14px; margin-left: 13px;">BC</p>
										<select name="LBc" id="sph_lbc" class="sphare" style="position: realative; text-align: center;">
											<option value=""></option>
											<?php $__currentLoopData = explode(',',$productdata->basecurve); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $base): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($base); ?>"><?php echo e($base); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								<?php else: ?>
									<div class="right">
										<select name="" id="" class="sphare">
											<option value=""></option>
										</select>
									</div>
								<?php endif; ?>
							</div>
							<div class="show-prescription">
								<button class="showPrescription3" type="button">How to read my prescriptions ?</button>
							</div>
							<div class="input-group">
								<input type="checkbox" name="same_rx_both" id="both_eyes-3" class="both_eyes-3"><p>Same Rx for both eyes</p>
							</div>
							<div>
								<a href="javascript:void(0)" class="btn next-4">Select Quantity</a>
							</div>
						</div>
					</div>
				</div>

				<div class="form-step" id="form-5">
					<div class="back">
						<a href="javascript:void(0)" class="backbtn back-4">Back</a>
					</div>
					<div class="form-data">
						<div class="title"><h2>Select Your Quantity</h2></div>
						<div class="main_box">
							<div class="box-input-group">
								<div class="qty_box">
									<select class="left-quantity" name="lefteyequantity" id="select">
										<option value="">Boxes <small> Left Eye <?php echo "(OS)"?></small></option>
										<option value="1">1 Boxes <small> Left Eye <?php echo "(OS)"?></small></option>
										<option value="2">2 Boxes <small> Left Eye <?php echo "(OS)"?></small></option>
										<option value="3">3 Boxes <small> Left Eye <?php echo "(OS)"?></small></option>
										<option value="4">4 Boxes <small> Left Eye <?php echo "(OS)"?></small></option>
										<option value="5">5 Boxes <small> Left Eye <?php echo "(OS)"?></small></option>
										<option value="6">6 Boxes <small> Left Eye <?php echo "(OS)"?></small></option>	
										<option value="7">7 Boxes <small> Left Eye <?php echo "(OS)"?></small></option>
										<option value="8">8 Boxes <small> Left Eye <?php echo "(OS)"?></small></option>
										<option value="9">9 Boxes <small> Left Eye <?php echo "(OS)"?></small></option>
										<option value="10">10 Boxes <small> Left Eye <?php echo "(OS)"?></small></option>
										<option value="11">11 Boxes <small> Left Eye <?php echo "(OS)"?></small></option>
										<option value="12">12 Boxes <small> Left Eye <?php echo "(OS)"?></small></option>		
									</select>
								</div>
							</div>
							<div class="box-input-group">
								<div class="qty_box">
									<select class="right-quantity" name="righeyequantity" id="select2">
										<option value="">Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
										<option value="1">1 Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
										<option value="2">2 Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
										<option value="3">3 Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
										<option value="4">4 Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
										<option value="5"> 5Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
										<option value="6">6 Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
										<option value="7">7 Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
										<option value="8">8 Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
										<option value="9">9 Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
										<option value="10">10 Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
										<option value="11">11 Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
										<option value="12">12 Boxes <small> Right Eye <?php echo "(OD)"?></small></option>
									</select>
								</div>
							</div>
							<div>
								<a href="javascript:void(0)" type="button" class="btn next-5">Continue</a>
							</div>
						</div>
					</div>
				</div>

				<div class="form-step" id="form-6">
					<div class="back">
						<a href="javascript:void(0)" class="backbtn back-5">Back</a>
					</div>
					<div class="form-data">
						<div class="title"><h3><i class="fa fa-check"></i>Great!<span>Let's finish up</span></h3></div>
						<div class="main_box">
							<div class="data-input-group">
								<div class="right">
									<div class="per-box">
										<p>Per Box :</p>
										<p><?php echo e($settings[0]->currency_sign); ?> <?php echo e($productdata->price); ?></p>
									</div>
									<div class="per-box">
										<p >Total Price : <?php echo "(" ?> <input class="boxQty" type="text" style="border: none; width: 15px; font-size: 16px; background-color: rgb(242, 234, 234); outline:none;" readonly> <?php echo ")" ?></p>
										<span style="display:flex; text-decoration: line-through;"><?php echo e($settings[0]->currency_sign); ?><input class="previous" type="text" style="border: none; width: 60px; font-size: 16px; background-color: rgb(242, 234, 234); outline:none;" readonly></span>
										<p style="display:flex; color:red;"><?php echo e($settings[0]->currency_sign); ?><input class="selling" name="cost" type="text" style="border: none; width: 60px; font-size: 16px; background-color: rgb(242, 234, 234); outline:none; color:red;" readonly></p>
									</div>
									<div class="per-box">
										<p><?php echo e($productdata->usagesduration); ?></p>
									</div>
								</div>
								<div class="right">
									<label for="">
									    <p></p>
									</label>
									<label for="">
										<p></p>
									</label>
								</div>
								<div>
									<?php echo e(csrf_field()); ?>

									<?php if(Session::has('uniqueid')): ?>
										<input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
									<?php else: ?>
										<input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
									<?php endif; ?>
									
									 <input type="hidden" id="price" name="price" value="<?php echo e(\App\Product::Cost($productdata->id)); ?>">

									 <input type="hidden" id="price_1" name="price_1" value="<?php echo e(\App\Product::Costtwopis($productdata->id)); ?>">
									 <input type="hidden" id="price_2" name="price_2" value="<?php echo e(\App\Product::Costfiftypis($productdata->id)); ?>">
									 <input type="hidden" id="price_3" name="price_3" value="<?php echo e(\App\Product::Costfivethousandpis($productdata->id)); ?>">

									<input type="hidden" name="title" value="<?php echo e($productdata->title); ?>">
									<input type="hidden" name="product" value="<?php echo e($productdata->id); ?>">
									<input type="hidden" id="quantity" name="quantity" value="1">
									<input type="hidden" id="size" name="size" value="">
									<input type="hidden" id="prev-price" name="size" value="<?php echo e($productdata->previous_price); ?>">
									<input type="hidden" id="sell-price" name="size" value="<?php echo e($productdata->price); ?>">

									<?php if($productdata->stock != 0 || $productdata->stock === null): ?>
										 <button type="submit" id="cart-button" class="btn to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?> </span></button>                                                        
			 
									<?php else: ?>

										<button type="button" class="addTo-cart to-cart" disabled><i class="fa fa-cart-plus "></i></button>

									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>

    <div class="modelShaddow"></div>

	<div class="prescriptionModel" tabindex="-1" role="dialog">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="model-content">
				<div class="model-header">
					<h3 class="model-title">Read Your Prescription</h3>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="model-body">
					<div class="select-prescription">
						<table>
							<thead>
								<tr>
									<th>Where can I find my contacts prescription?</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>
										<ul>
											<li>On your written prescription</li>
											<li>On your box of contacts / on each contact</li>
											<li>Ask for a copy from your optician</li>
										</ul>
									</td>
								</tr>
							</tbody>
						</table>
						<table>
							<thead>
								<tr>
									<th>See example of contacts prescription:</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>
										<ul>
											<li><input class="contact-lens-button" type="radio">Written prescription</li>
											<li><input class="right-left-button" type="radio">On box of contacts</li>
										</ul>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="contact-lens-data">
						<table class="table table-bordered" style="width:100%">
							<thead>
								<tr>
									<th style="width:2%"scope="col"></th>
									<th style="width:2%" scope="col"><center>POWER</center></th>
									<th style="width:2%"scope="col"><center>BC</center></th>
									<th style="width:2%"scope="col"><center>DIA</center></th>
									<th style="width:2%"scope="col"><center>CYL</center></th>
									<th style="width:2%"scope="col"><center>AXIS</center></th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<th style="width:2%" scope="row">OD</th>
									<td><center>-2.50</center></td>
									<td><center>8.5</center></td>
									<td><center>14.2</center></td>
									<td><center></center></td>
									<td><center></center></td>
								</tr>
								<tr>
									<th scope="row">OS</th>
									<td><center>-3.00</center></td>
									<td><center>8.5</center></td>
									<td><center>14.2</center></td>
									<td><center></center></td>
									<td><center></center></td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="right-left-data">
						<div class="data-content">
							<table class="table table-bordered" style="width:100%">
								<thead>
									<tr>
										<th style="width:2%" scope="col"><center>O.D.</center></th>
										<th style="width:2%"scope="col"><center>O.S.</center></th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td><center><input type="checkbox" disabled>R</center></td>
										<td><center><input type="checkbox" disabled>L</center></td>
									</tr>
								</tbody>
							</table>
							<table class="table table-bordered" style="width:100%">
								<thead>
									<tr>
										<th style="width:2%" scope="col"><center>PWR</center></th>
										<th style="width:2%"scope="col"><center>BC</center></th>
										<th style="width:2%"scope="col"><center>DIA</center></th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td><center>-3.00</center></td>
										<td><center>8.5</center></td>
										<td><center>14.2</center></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
					<div class="detail">
						<div class="row">
							<table class="detail-table">
								<thead>
									<tr>
										<th style="width:2%" scope="col"><center>Eye</center></th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td><center>
											<p>The right eye (O.D) will always be</p>
											<span>listed before left eye (O.S).</span>
										</center></td>
									</tr>
								</tbody>
							</table>
							<table class="detail-table">
								<thead>
									<tr>
										<th style="width:2%" scope="col"><center>Power</center></th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>
											<center>
												Can displayed as PWR / SPH / D, shows whether you are far or near-sighted and how much correction your eyes require.
											</center>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="row">
							<table class="detail-table">
								<thead>
									<tr>
										<th style="width:2%" scope="col"><center>BC</center></th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>
											<center>
												The base curve, usually a number between 8 and 10, measures the curve of the lens.
											</center>
										</td>
									</tr>
								</tbody>
							</table>
							<table class="detail-table">
								<thead>
									<tr>
										<th style="width:2%" scope="col"><center>Dia</center></th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>
											<center>
												The diameter of the contact lens, usually between 13 and 15, determines the width that best fits your eye.
											</center>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script>
		var showPresButton = document.querySelector('.showPrescription');
		var showPresButton2 = document.querySelector('.showPrescription2');
		var showPresButton3 = document.querySelector('.showPrescription3');
		
		var closeModelButton = document.querySelector('.close');

		var modelWindow = document.querySelector('.prescriptionModel');
		var overLayWindow = document.querySelector('.modelShaddow');

		var contactLensButton = document.querySelector('.contact-lens-button');
		var contactLensData = document.querySelector('.contact-lens-data');
		var powerLensButton = document.querySelector('.right-left-button');
		var powerLensData = document.querySelector('.right-left-data');

		showPresButton.addEventListener('click', function() {
			overLayWindow.style.display = 'block';
			modelWindow.style.display = 'block';
		});
		
		showPresButton2.addEventListener('click', function() {
			overLayWindow.style.display = 'block';
			modelWindow.style.display = 'block';
		});
		
		showPresButton3.addEventListener('click', function() {
			overLayWindow.style.display = 'block';
			modelWindow.style.display = 'block';
		});

		closeModelButton.addEventListener('click', function() {
			overLayWindow.style.display = 'none';
			modelWindow.style.display = 'none';
		});

		contactLensButton.checked = true;

		contactLensButton.addEventListener('click', function() {
			contactLensData.style.display = 'block';
			powerLensData.style.display = 'none';
			powerLensButton.checked = false;
		});

		powerLensButton.addEventListener('click', function() {
			contactLensData.style.display = 'none';
			powerLensData.style.display = 'block';
			contactLensButton.checked = false;
		});
	</script>


<script type="text/javascript">

	// Forwarrd process ----------------------------------------
	const nextFirst = document.querySelector('.next-1');
	const nextSecond = document.querySelector('.next-2');
	const nextThird = document.querySelector('.next-3');
	const nextFourth = document.querySelector('.next-4');
	const nextFifth = document.querySelector('.next-5');
	const nextSixth = document.querySelector('.next-6');

	const imgNext = document.querySelector('.img-next');

	const fillManual = document.querySelector('.fill-manual');

	const firstCheck = document.querySelector('#both_eyes');
	const secondCheck = document.querySelector('#both_eyes-2');
	const thirdCheck = document.querySelector('#both_eyes-3');

	const firstForm = document.querySelector('#form-1');
	const secondForm = document.querySelector('#form-2');
	const thirdForm = document.querySelector('#form-3');
	const fourthForm = document.querySelector('#form-4');
	const fifthForm = document.querySelector('#form-5');
	const sixthForm = document.querySelector('#form-6');

	const formModel = document.querySelector('#form-model');
	const imgModel = document.querySelector('#img-model');
''
	var fileTag = document.getElementById("uploadFile"),
		preview = document.getElementById("showFile");
		labelData = document.getElementById("showLabel")

	fileTag.addEventListener("change", function() {
		changeImage(this);
		formModel.style.display = "none";
		imgModel.style.display = "block";
	});

	function changeImage(input) {
		var reader;

		if (input.files && input.files[0]) {
			reader = new FileReader();

			reader.onload = function(e) {
				preview.setAttribute('src', e.target.result);

				var filename = input.files[0].name;
				
				if(filename != '') {
					$('#showLabel').html(filename);
				}
			}

			reader.readAsDataURL(input.files[0]);
		}
		
	}

	imgNext.addEventListener('click', function() {
		if(fileTag != null) {
			fifthForm.style.display = 'block';
			firstForm.style.display = 'none';
			// imgModel.style.display = 'none';
		}else {
			fifthForm.style.display = 'none';
			imgModel.style.display = 'none';
			formModel.style.display = "block";
			firstForm.style.display = 'block';
		}
		// fifthForm.style.display = 'block';
		// firstForm.style.display = 'none';
	});

	nextFirst.addEventListener('click', function() {
		fifthForm.style.display = 'block';
		firstForm.style.display = 'none';
	});

	fillManual.addEventListener('click', function() {
	    if(firstCheck.checked){
	        thirdForm.style.display = 'block';
		    firstForm.style.display = 'none';
	    }else{
	        secondForm.style.display = 'block';
		    firstForm.style.display = 'none';
	    }
	});

	firstCheck.addEventListener('click', function() {
	    if($('.getPowerRight').val() != '' && $('#toric_raxis').val() != '' && $('#toric_rbc').val() != '' && $('#toric_rcyl').val() != '') {
    		if(firstCheck.checked) {
    			thirdForm.style.display = 'block';
    			secondForm.style.display = 'none';
    			secondCheck.checked = true;
    			thirdCheck.checked = true;
                
    			var rightPower = $('.getPowerRight').val();
    			var rightAxis = $('#toric_raxis').val();
    			var rightBase = $('#toric_rbc').val();
    			var rightCycle = $('#toric_rcyl').val();
    			
    			$('.getPowerBoth').val(rightPower);
    			$('#toric_baxis').val(rightAxis);
    			$('#toric_bbc').val(rightBase);
    			$('#toric_bcyle').val(rightCycle);
    		}
    		
    		if(firstCheck.unchecked) {
        		$('.getPowerBoth').val();
        		$('#toric_baxis').val();
        		$('#toric_bbc').val();
        		$('#toric_bcyle').val();
    		}
	    }
	    else{
	        alert('Please fill all right eye field');
	        firstCheck.checked = false;
	    }
	});

	secondCheck.addEventListener('click', function() {
		if(secondCheck.checked == false) {
			thirdForm.style.display = 'none';
			secondForm.style.display = 'block';
			firstCheck.checked = false;
			thirdCheck.checked = false;
		}
	});

	thirdCheck.addEventListener('click', function() {
		if(thirdCheck.checked) {
			thirdForm.style.display = 'block';
			fourthForm.style.display = 'none';
			secondCheck.checked = true;
			thirdCheck.checked = true;
			
			var rightPower = $('.getPowerRight').val();
			var rightAxis = $('#toric_raxis').val();
			var rightBase = $('#toric_rbc').val();
			var rightCycle = $('#toric_rcyl').val();
			
			$('.getPowerBoth').val(rightPower);
			$('#toric_baxis').val(rightAxis);
			$('#toric_bbc').val(rightBase);
			$('#toric_bcyle').val(rightCycle);
		}
			
	});

	nextSecond.addEventListener('click', function() {
	    if($('.getPowerRight').val() != '' && $('#toric_raxis').val() != '' && $('#toric_rbc').val() != '' && $('#toric_rcyl').val() != '') {
    		fourthForm.style.display = 'block';
    		secondForm.style.display = 'none';
	    }
	    else {
	        alert('Please fill all right eye field');
	    }
	})

	nextThird.addEventListener('click', function() {
		fifthForm.style.display = 'block';
		thirdForm.style.display = 'none';
	})

	nextFourth.addEventListener('click', function() {
	    if($('.getPowerLeft').val() != '' && $('#multi_lopwer').val() != '' && $('#multi_lbc').val() != '' && $('#multi_ldia').val() != '') {
    		fifthForm.style.display = 'block';
    		fourthForm.style.display = 'none';
	    }
	    else{
	        alert('Please fill all left eye field');
	    }
	})

	nextFifth.addEventListener('click', function() {
	    if($('.left-quantity').val() != '' && $('right-quantity').val() != ''){
    		sixthForm.style.display = 'block';
    		fifthForm.style.display = 'none';
    		
    		var quantity = parseInt($('.left-quantity').val());
    		var quantity2 = parseInt($('.right-quantity').val());
    		var prePrice = parseInt($('#prev-price').val());
    		var price = parseInt($('#sell-price').val());
    		
    		var mrpPrice = (quantity + quantity2) * prePrice;
    		
    		var sellPrice = (quantity + quantity2) * price;
    		
    		$('.boxQty').val(quantity + quantity2);
    		
    		$(".previous").val(mrpPrice);
    		
    		$(".selling").val(sellPrice);
	    }
	    else{
	        alert('Please select left and right boxes');
	    }
		
	})

	// back process ----------------------------------------

	// const firstForm = document.querySelector('#form-1');
	// const secondForm = document.querySelector('#form-2');
	// const thirdForm = document.querySelector('#form-3');
	// const fourthForm = document.querySelector('#form-4');
	// const fifthForm = document.querySelector('#form-5');
	// const sixthForm = document.querySelector('#form-6');

	const firstBack = document.querySelector('.back-1');
	const secondBack = document.querySelector('.back-2');
	const thirdBack = document.querySelector('.back-3');
	const fourthBack = document.querySelector('.back-4');
	const fifthBack = document.querySelector('.back-5');

	firstBack.addEventListener('click', function() {
		firstForm.style.display = 'block';
		secondForm.style.display = 'none';
	});

	secondBack.addEventListener('click', function() {
		firstForm.style.display = 'block';
		thirdForm.style.display = 'none';
	});

	thirdBack.addEventListener('click', function() {
		secondForm.style.display = 'block';
		fourthForm.style.display = 'none';
	});

	fourthBack.addEventListener('click', function() {
		if(secondCheck.checked == true){
		    thirdForm.style.display = 'block';
		    fifthForm.style.display = 'none';
		}else {
		    fourthForm.style.display = 'block';
		    fifthForm.style.display = 'none';
		}
	});

	fifthBack.addEventListener('click', function() {
		fifthForm.style.display = 'block';
		sixthForm.style.display = 'none';
	});
</script>

<script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>
<script type="text/javascript">
	$(document).ready(()=>{
		$("#select option[value=0]").attr('selected', 'selected');
		$("#select2 option[value=0]").attr('selected', 'selected');
	});
	
	// right eye power ajax function -------------------------

	$(".power-data-right").click(function() {
		var data = $(this).attr('value');
		// console.log(data);
		insertDataRight(data);
	});

	function insertDataRight(data) {
		$('.getPowerRight').val(data);
	}
	
	// both eye ajax function ----------------------------------
	
	$(".power-data-both").click(function() {
		var data = $(this).attr('value');
		// console.log(data);
		insertDataBoth(data);
	});

	function insertDataBoth(data) {
		$('.getPowerBoth').val(data);
	}
	
	// left eye ajax function ---------------------------------
	
	$(".power-data-left").click(function() {
		var data = $(this).attr('value');
		// console.log(data);
		insertDataLeft(data);
	});

	function insertDataLeft(data) {
		$('.getPowerLeft').val(data);
	}

</script>

<script type="text/javascript">    
    var save_method;

$(document).ready(function(){
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });
   
    $('#PrescriptionForm').submit(function(e){
        var formData = new FormData(this);
        e.preventDefault();

        $.ajax({
            url: "<?php echo e(url('/cartupdate')); ?>",
            method:'POST',
            data : formData,
            processData: false,
            contentType: false,
            cache : false,
            dataType: 'JSON',
            success:function(data){
			    if (data.status == 200) {
					window.location.href = "<?php echo e(url('/cart')); ?>";
				}
			},
		});
	}); 
});

function validate() {
// var emp_name = $('#emp_name').val();



var msg = new Array();


//     if(upload_document == ''){
//         msg.push('Please Field  Upload Document'); 
//     }    


if( !jQuery.isEmptyObject(msg)) {
$('.error').text(msg[0]);
}
else return true;
console.log(msg);   
}
</script>

</body>
</html>