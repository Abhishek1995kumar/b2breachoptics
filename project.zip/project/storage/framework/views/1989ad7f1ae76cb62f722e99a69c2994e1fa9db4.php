<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row" id="main">
                <!-- Page Heading -->
                <div class="go-title">
                    <div class="pull-right">
                        <a href="<?php echo url('admin/products'); ?>" class="btn btn-primary btn-add"><i class="fa fa-arrow-circle-o-left"></i> Back</a>
                    </div>
                    <h3>Pending Products</h3>
                    <div class="go-line"></div>
                </div>
                <!-- Page Content -->
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div id="response">
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                            <tr>
                                <th width="10%">ID#</th>
                                <th>Product Title</th>
                                <th>Price</th>
                                <th>Category</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->id); ?></td>
                                <td><?php echo e($product->title); ?></td>
                                <td><?php echo e($product->price); ?></td>
                                <td>
                                    <?php echo e(\App\Category::where('id',$product->category[0])->first()->name); ?><br>
                                    <?php if($product->category[1] != ""): ?>
                                    <?php echo e(\App\Category::where('id',$product->category[1])->first()->name); ?><br>
                                    <?php endif; ?>
                                    <?php if($product->category[2] != ""): ?>
                                        <?php echo e(\App\Category::where('id',$product->category[2])->first()->name); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($product->status == 1): ?>
                                        Active
                                    <?php elseif($product->status == 2): ?>
                                        Pending
                                          <?php elseif($product->status == 3): ?>
                                        Rejected
                                    <?php else: ?>
                                        Inactive
                                    <?php endif; ?>
                                </td>
                                <td>

                                        <a href="<?php echo url('admin/products'); ?>/<?php echo e($product->id); ?>/edit" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> View </a>
                                        <?php if($product->status==3): ?>

                                        <a  data-toggle="modal" data-target="#exampleModal" class="btn btn-danger btn-xs"><i class="fa fa-times"></i> Send Rejection Note </a>

                                        <?php else: ?>

                                        <a href="<?php echo url('admin/products/accept'); ?>/<?php echo e($product->id); ?>" class="btn btn-success btn-xs"><i class="fa fa-check"></i> Accept </a>

                                        <a  href="<?php echo url('admin/products/reject'); ?>/<?php echo e($product->id); ?>" class="btn btn-danger btn-xs"><i class="fa fa-times"></i> Reject </a>

                                        <?php endif; ?>

                                    <!--     <a  data-toggle="modal" data-target="#exampleModal" class="btn btn-danger btn-xs"><i class="fa fa-times"></i> Rejection Note </a> -->

                                                                                               
                                                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                          <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <form method="get" action="<?php echo url('admin/products/rejectnote'); ?>/<?php echo e($product->id); ?>">
                                                              <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Rejection Note</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                  <span aria-hidden="true">&times;</span>
                                                                </button>
                                                              </div>
                                                              <div class="modal-body">
                                                                      <div class="form-group">
                                                                        <label for="exampleFormControlTextarea1">Rejection Note:-   </label>
                                                                       <textarea name="note" class="form-control" rows="3" cols="50"></textarea>
                                                                      </div>
                                                            
                                                              </div>
                                                              <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                 <button type="submit" class="btn btn-primary">Save changes</button>
                                                              </div>
                                                               </form>
                                                            </div>
                                                          </div>
                                                        </div>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>