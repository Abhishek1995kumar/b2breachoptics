<?php $__env->startSection('content'); ?>

    <div class="home-wrapper">
        <!-- Starting of add to cart table -->
        <div class="section-padding product-shoppingCart-wrapper wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12">

                        <div class="table-responsive">
                            <div class="breadcrumb-box">
                                <a href="<?php echo e(url('/home')); ?>">Home</a>
                                <a href="<?php echo e(url('/cart')); ?>">My Cart</a>
                            </div>
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                            
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Remove</th>
                                    <th>Image</th>
                                    <th width="25%"><?php echo e($language->product_name); ?></th>
                                    <th>Product Size</th>
                                    <th>Prescription</th>
                                    
                                    <?php if(isset($carts[0])): ?>
                                    <th width="25%">
                                            <th><?php echo e($language->quantity); ?></th>
                                            <th>Left Eye</th>
                                            <th>Right Eye</th>
                                    </th>
                                    <?php endif; ?>
                                    
                                    <th><?php echo e($language->unit_price); ?></th>
                                    <th><?php echo e($language->subtotal); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                
                                <?php if(isset($carts)): ?>
                                <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr id="item<?php echo e($cart->product); ?>">
                                    <td><a onclick="getDelete(<?php echo e($cart->product); ?>)"><i class="fa fa-trash-o" aria-hidden="true"></i></a></td>
                                        <?php if($cart->cartcolor == $cart->maincolor): ?>
                                            <td><img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e(\App\Product::findOrFail($cart->product)->feature_image); ?>" alt=""></td>
                                        <?php else: ?>
                                            <td><img src="<?php echo e(url('/assets/images/product_attr')); ?>/<?php echo e($data->attr_imgs); ?>" alt=""></td>
                                        <?php endif; ?>
                                    <td>
                                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($cart->product); ?>/<?php echo e(str_replace(' ','-',strtolower(\App\Product::findOrFail($cart->product)->title))); ?>" class="product-name-header"><?php echo e($cart->title); ?></a>
                                        <!--<p class="table-product-review">-->
                                        <!--    <i class="fa fa-star"></i>-->
                                        <!--    <span>(06 Reviews)</span>-->
                                        <!--</p>-->
                                    </td>
                                    <td><?php echo e($cart->size); ?></td>
                                    
                                    <td>
                                       <?php if($cart->priscriptionohoto === null): ?>
                                       
                                      <a data-toggle="modal" data-target="#view_<?php echo e($cart->product); ?>" > <i class="fa fa-eye" aria-hidden="true"></i> </a></td>
                                      
                                       <?php else: ?>
                                       
                                    
                                      <a data-toggle="modal" data-target="#exampleModal<?php echo e($cart->product); ?>" > <i class="fa fa-eye" aria-hidden="true"></i> </a></td>
                                     
                                      <?php endif; ?>
                                    <td>
                                        <?php if($cart->lefteyequantity === null): ?>
                                            <p class="cart-btn">
                                                <span class="quantity-cart-minus" id="minus<?php echo e($cart->product); ?>"><i class="fa fa-minus"></i></span>
                                                <span class="qty_1" id="number<?php echo e($cart->product); ?>"><?php echo e($cart->quantity); ?></span>
                                                <span class="quantity-cart-plus" id="plus<?php echo e($cart->product); ?>"><i class="fa fa-plus"></i></span>
                                            </p>
                                        <?php else: ?>
                                            <p class="cart-btn">
                                                <td class="left-qty"><?php echo e($cart->lefteyequantity); ?></td>
                                                <td class="right-qty"><?php echo e($cart->righeyequantity); ?></td>
                                            </p>
                                        <?php endif; ?>
                                    </td>
                                    <form id="citem<?php echo e($cart->product); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <?php if(Session::has('uniqueid')): ?>
                                            <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                        <?php else: ?>
                                            <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                        <?php endif; ?>
                                        <input type="hidden" name="title" value="<?php echo e($cart->title); ?>">

                                        <input type="hidden" id="price" name="price" value="<?php echo e($cart->price); ?>">
                                        <input type="hidden" id="price_1" name="price_1" value="<?php echo e(\App\Product::Costtwopis($cart->product)); ?>">
                                        <input type="hidden" id="price_2" name="price_2" value="<?php echo e(\App\Product::Costfiftypis($cart->product)); ?>">
                                        <input type="hidden" id="price_3" name="price_3" value="<?php echo e(\App\Product::Costfivethousandpis($cart->product)); ?>">


                                        <input type="hidden" name="product" value="<?php echo e($cart->product); ?>">
                                        <input type="hidden" id="cost<?php echo e($cart->product); ?>" name="cost" value="<?php echo e($cart->cost); ?>" autocomplete="off">
                                        <input type="hidden" id="quantity<?php echo e($cart->product); ?>" name="quantity" value="<?php echo e($cart->quantity); ?>">
                                        <input type="hidden" id="size<?php echo e($cart->product); ?>" name="size" value="<?php echo e($cart->size); ?>">
                                    </form>
                                    <?php if($cart->quantity >= 2 && $cart->quantity <= 49): ?>
                                    <td><?php echo e($settings[0]->currency_sign); ?><span id="price<?php echo e($cart->product); ?>"><?php echo e(\App\Product::Costtwopis($cart->product)); ?></span></td>
                                    <?php elseif($cart->quantity >= 50 && $cart->quantity <= 4999): ?>
                                    <td><?php echo e($settings[0]->currency_sign); ?><span id="price<?php echo e($cart->product); ?>"><?php echo e(\App\Product::Costfiftypis($cart->product)); ?></span></td>
                                    <?php elseif($cart->quantity >= 5000): ?>
                                    <td><?php echo e($settings[0]->currency_sign); ?><span id="price<?php echo e($cart->product); ?>"><?php echo e(\App\Product::Costfivethousandpis($cart->product)); ?></span></td>
                                    <?php else: ?>
                                    <td><?php echo e($settings[0]->currency_sign); ?><span id="price<?php echo e($cart->product); ?>"><?php echo e(\App\Product::Cost($cart->product)); ?></span></td>
                                    <?php endif; ?>
                                    <!-- <td><?php echo e($settings[0]->currency_sign); ?><span id="price<?php echo e($cart->product); ?>"><?php echo e(\App\Product::Cost($cart->product,$cart->quantity)); ?></span></td> -->
                                    <!-- <td><?php echo e($settings[0]->currency_sign); ?><span id="price<?php echo e($cart->product); ?>"><?php echo e(\App\Product::Cost($cart->product)); ?></span></td> -->
                                    <td><?php echo e($settings[0]->currency_sign); ?><span id="subtotal<?php echo e($cart->product); ?>" class="subtotal"><?php echo e($cart->cost); ?></span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6">
                                            <h3><?php echo e($language->empty_cart); ?></h3>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php endif; ?>
                                <tr style="border-top: 1px solid black;">
                                    <td colspan="5" style="text-align: right;">
                                        <h3><?php echo e($language->total); ?></h3>
                                    </td>
                                    <td colspan="2" style="text-align: right;">
                                        <h3><?php echo e($settings[0]->currency_sign); ?><span id="grandtotal"><?php echo e(round($sum,2)); ?></span></h3>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <a href="<?php echo e(url('/home')); ?>" class="shopping-btn"><?php echo e($language->continue_shopping); ?></a>
                                    </td>
                                    <td colspan="4">
                                        <a href="<?php echo e(route('user.checkout')); ?>" class="update-shopping-btn"><?php echo e($language->proceed_to_checkout); ?></a>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ending of add to cart table -->
    </div>


<?php if(isset($carts)): ?>
<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="view_<?php echo e($cart->product); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Priscription</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table class="table table-bordered" style="width:100%">
          <thead>
            <?php if($cart->presc_image === null): ?>
                <?php if($cart->rpower != null || $cart->Lpower != null || $cart->bpower != null): ?>
                    <tr>
                    <th style="width:2%"scope="col"></th>
                    <th style="width:2%" scope="col"><center>SPH</center></th>
                    <th style="width:2%"scope="col"><center>BC</center></th>
                    <th style="width:2%"scope="col"><center>DIA</center></th>
                    <th style="width:2%"scope="col"><center>Add Power</center></th>
                    </tr>
                <?php elseif($cart->Raxis != null || $cart->Laxis != null || $cart->Baxis != null): ?>
                    <tr>
                    <th style="width:2%"scope="col"></th>
                    <th style="width:2%" scope="col"><center>SPH</center></th>
                    <th style="width:2%"scope="col"><center>BC</center></th>
                    <th style="width:2%"scope="col"><center>DIA</center></th>
                    <th style="width:2%"scope="col"><center>CYL</center></th>
                    <th style="width:2%"scope="col"><center>AXIS</center></th>
                    </tr>
                <?php else: ?>
                    <tr>
                    <th style="width:2%"scope="col"></th>
                    <th style="width:2%" scope="col"><center>SPH</center></th>
                    <th style="width:2%"scope="col"><center>BC</center></th>
                    <th style="width:2%"scope="col"><center>DIA</center></th>
                    </tr>
                <?php endif; ?>
            <?php else: ?>
                <tr>
                    <th style="width:2%" scope="col"><center>IMAGE</center></th>
                </tr>
            <?php endif; ?>
          </thead>
          <tbody>
            <?php if($cart->presc_image === null): ?>
                <?php if($cart->same_rx_both != null): ?>
                    <?php if($cart->rpower != null || $cart->Lpower != null || $cart->bpower != null): ?>
                        <tr>
                            <th style="width:2%" scope="row">Right(OD)</th>
                            <td><center><?php echo e($cart->rsphere); ?></center></td>
                            <td><center><?php echo e($cart->rbc); ?></center></td>
                            <td><center><?php echo e($cart->rdia); ?></center></td>
                            <td><center><?php echo e($cart->rpower); ?></center></td>
                        </tr>
                    
                        <tr>
                            <th scope="row">Left(OS)</th>
                            <td><center><?php echo e($cart->rsphere); ?></center></td>
                            <td><center><?php echo e($cart->rbc); ?></center></td>
                            <td><center><?php echo e($cart->rdia); ?></center></td>
                            <td><center><?php echo e($cart->rpower); ?></center></td>
                        </tr>
                    <?php elseif($cart->Raxis != null || $cart->Laxis != null || $cart->Baxis != null): ?>
                        <tr>
                            <th style="width:2%" scope="row">Right(OD)</th>
                            <td><center><?php echo e($cart->rsphere); ?></center></td>
                            <td><center><?php echo e($cart->rbc); ?></center></td>
                            <td><center><?php echo e($cart->rdia); ?></center></td>
                            <td><center><?php echo e($cart->rcyl); ?></center></td>
                            <td><center><?php echo e($cart->Raxis); ?></center></td>
                        </tr>
                    
                        <tr>
                            <th scope="row">Left(OS)</th>
                            <td><center><?php echo e($cart->rsphere); ?></center></td>
                            <td><center><?php echo e($cart->rbc); ?></center></td>
                            <td><center><?php echo e($cart->rdia); ?></center></td>
                            <td><center><?php echo e($cart->rcyl); ?></center></td>
                            <td><center><?php echo e($cart->Raxis); ?></center></td>
                        </tr>
                    <?php else: ?>
                        <tr>
                            <th style="width:2%" scope="row">Right(OD)</th>
                            <td><center><?php echo e($cart->rsphere); ?></center></td>
                            <td><center><?php echo e($cart->rbc); ?></center></td>
                            <td><center><?php echo e($cart->rdia); ?></center></td>
                        </tr>
                    
                        <tr>
                            <th scope="row">Left(OS)</th>
                            <td><center><?php echo e($cart->rsphere); ?></center></td>
                            <td><center><?php echo e($cart->rbc); ?></center></td>
                            <td><center><?php echo e($cart->rdia); ?></center></td>
                        </tr>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if($cart->rpower != null || $cart->Lpower != null || $cart->bpower != null): ?>
                        <tr>
                            <th style="width:2%" scope="row">Right(OD)</th>
                            <td><center><?php echo e($cart->rsphere); ?></center></td>
                            <td><center><?php echo e($cart->rbc); ?></center></td>
                            <td><center><?php echo e($cart->rdia); ?></center></td>
                            <td><center><?php echo e($cart->rpower); ?></center></td>
                        </tr>
                    
                        <tr>
                            <th scope="row">Left(OS)</th>
                            <td><center><?php echo e($cart->Lsphere); ?></center></td>
                            <td><center><?php echo e($cart->LBc); ?></center></td>
                            <td><center><?php echo e($cart->LDia); ?></center></td>
                            <td><center><?php echo e($cart->Lpower); ?></center></td>
                        </tr>
                    <?php elseif($cart->Raxis != null || $cart->Laxis != null || $cart->Baxis != null): ?>
                        <tr>
                            <th style="width:2%" scope="row">Right(OD)</th>
                            <td><center><?php echo e($cart->rsphere); ?></center></td>
                            <td><center><?php echo e($cart->rbc); ?></center></td>
                            <td><center><?php echo e($cart->rdia); ?></center></td>
                            <td><center><?php echo e($cart->rcyl); ?></center></td>
                            <td><center><?php echo e($cart->Raxis); ?></center></td>
                        </tr>
                    
                        <tr>
                            <th scope="row">Left(OS)</th>
                            <td><center><?php echo e($cart->Lsphere); ?></center></td>
                            <td><center><?php echo e($cart->LBc); ?></center></td>
                            <td><center><?php echo e($cart->LDia); ?></center></td>
                            <td><center><?php echo e($cart->Lcyle); ?></center></td>
                            <td><center><?php echo e($cart->Laxis); ?></center></td>
                        </tr>
                    <?php else: ?>
                        <tr>
                            <th style="width:2%" scope="row">Right(OD)</th>
                            <td><center><?php echo e($cart->rsphere); ?></center></td>
                            <td><center><?php echo e($cart->rbc); ?></center></td>
                            <td><center><?php echo e($cart->rdia); ?></center></td>
                        </tr>
                    
                        <tr>
                            <th scope="row">Left(OS)</th>
                            <td><center><?php echo e($cart->Lsphere); ?></center></td>
                            <td><center><?php echo e($cart->LBc); ?></center></td>
                            <td><center><?php echo e($cart->LDia); ?></center></td>
                        </tr>
                    <?php endif; ?>
                <?php endif; ?>
            <?php else: ?>
                <tr>
                    <td><center><a href="<?php echo e(url('assets/prescription/'.$cart->presc_image)); ?>" target="_blank"><img src="<?php echo e(url('assets/prescription/'.$cart->presc_image)); ?>" alt=""></a></center></td>
                </tr>
            <?php endif; ?>
          </tbody>
        </table>                                                           
      </div>
      <div class="modal-footer text-center">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>






 <div class="modal fade" id="exampleModal<?php echo e($cart->product); ?>" tabindex="-1"
        role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <!-- Modal heading -->
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">
                       Priscription
                    </h5>
                    <button type="button" class="close"
                        data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">
                            ×
                        </span>
                    </button>
                </div>
                <!-- Modal body with image -->
                <div class="modal-body">
                  <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($cart->priscriptionohoto); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.newmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>