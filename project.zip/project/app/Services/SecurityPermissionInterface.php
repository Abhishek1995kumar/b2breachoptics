<?php

namespace App\Services;

interface SecurityPermissionInterface
{
    public function loginPermission($id);
}