<?php

namespace App\View\Components;

use Illuminate\View\Component;

class Lensprescription extends Component
{
    public function __cunstruct()
    {
        //
    }
    
    public function render()
    {
        return view('components.lensprescription');
    }
}